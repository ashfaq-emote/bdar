#!/bin/sh
# Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
# BROADRIDGE PROPRIETARY AND CONFIDENTIAL. Broadridge Digital Asset Registry (BDAR) Registry API.
# Fail if a source file lacks the Broadridge proprietary header.
set -eu
cd "$(dirname "$0")/.."
missing=0
for f in $(find src scripts test db config -type f \( -name '*.js' -o -name '*.sql' -o -name '*.sh' \) 2>/dev/null) eslint.config.js Dockerfile docker-compose.yml .env.example; do
  if ! head -n 12 "$f" | grep -q "BROADRIDGE PROPRIETARY AND CONFIDENTIAL"; then
    echo "missing Broadridge header: $f"
    missing=1
  fi
done
[ "$missing" -eq 0 ] && echo "all headers present"
exit "$missing"
