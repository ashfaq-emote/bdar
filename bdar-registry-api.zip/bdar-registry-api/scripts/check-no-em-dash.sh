#!/bin/sh
# Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
# BROADRIDGE PROPRIETARY AND CONFIDENTIAL. Broadridge Digital Asset Registry (BDAR) Registry API.
# House rule: the em dash character (U+2014) is not allowed anywhere in the repository.
set -eu
cd "$(dirname "$0")/.."
EM_DASH="$(printf '\342\200\224')"
if grep -rnF "$EM_DASH" --exclude-dir=node_modules --exclude-dir=.git . ; then
  echo "em dash found" >&2
  exit 1
fi
echo "no em dash found"
