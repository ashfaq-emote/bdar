<!--
Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
BROADRIDGE PROPRIETARY AND CONFIDENTIAL. Broadridge Digital Asset Registry (BDAR) Registry API.
-->

# BDAR Registry API

The HTTP API of the Broadridge Digital Asset Registry (BDAR). It serves every off-ledger
endpoint that CIP-56 (token standard V1) and CIP-112 (token standard V2) wallets, issuers and
settlement apps need, plus Broadridge extensions for issuance, party queries, account requests,
external signing and registry operations.

Built with Node.js 22 and Express 5. It reads and writes the ledger through the Canton JSON
Ledger API v2 and talks to the Workstream 1 Daml packages.

| Document | Where |
| --- | --- |
| Technical Implementation Guide (how it is built, security, operations) | `../WS2_Technical_Implementation_Guide.docx` |
| API Implementation Guide (how to integrate, with examples) | `../WS2_API_Implementation_Guide.docx` |
| Functional and Capability Document | `../WS2_Functional_Capability_Document.docx` |
| Copilot Build Brief | `../WS2_Copilot_Build_Brief.md` |
| OpenAPI 3.0.3 | `openapi/bdar-registry-api.yaml` and `.json` |

## Quick start (local)

```bash
nvm use                         # Node 22 (.nvmrc)
npm install                     # creates package-lock.json; commit it
cp .env.example .env            # then edit: BDAR_ADMIN_PARTY, LEDGER_*, API_KEY_PEPPER
docker compose up -d            # PostgreSQL 16 and Redis 7
npm run migrate                 # creates the three API tables
npm run keys -- create --client "Local admin" \
  --scopes keys:manage,operator:write,operator:read,audit:read --parties "*"
npm run dev                     # http://localhost:8080
curl -s localhost:8080/ping
```

Bootstrap the registry contracts once (needs the Workstream 1 DARs on the ledger):

```bash
curl -s -X POST localhost:8080/registry/bdar/v1/admin/bootstrap \
  -H "X-API-Key: $BDAR_ADMIN_KEY" -H "Idempotency-Key: bootstrap-0001"
```

## Scripts

| Command | What it does |
| --- | --- |
| `npm start` | Run the server (production) |
| `npm run dev` | Run with `--watch` and `.env` |
| `npm test` | Unit tests (`node --test`) |
| `npm run test:integration` | HTTP tests with supertest |
| `npm run migrate` | Apply `db/migrations` (uses `MIGRATION_DATABASE_URL`) |
| `npm run keys -- <create/list/show/rotate/revoke>` | API key administration from the command line |
| `npm run openapi` | Regenerate the OpenAPI YAML and JSON from the route table |
| `npm run check` | Headers, em dash rule, OpenAPI up to date, lint, unit tests (CI gate) |

## Layout

```text
src/
  server.js                 process: listen, TLS, graceful shutdown
  app.js                    Express app: helmet, CORS, body limit, router, errors
  container.js              composition root: builds every dependency from config
  config/index.js           environment and rate limit configuration, validated at start
  lib/                      errors (catalogue), small utilities
  security/                 API key format, scopes, rate limiter, middleware
  ledger/ledgerClient.js    JSON Ledger API v2 client and OAuth2 token provider
  registry/                 Daml identifiers, contract reader, context builder, mappers
  repositories/             PostgreSQL and in-memory stores (keys, audit, idempotency)
  services/                 token standard, BDAR extensions, submissions, operator, health, keys
  http/                     route table, JSON schemas, validation, router, error handler
  openapi/generate.js       OpenAPI document from the route table
  cli/apiKeys.js            key administration CLI
db/migrations/              SQL migrations
config/rate-limits.json     rate limit policies and tiers
openapi/                    generated OpenAPI YAML and JSON
test/unit, test/integration, test/fakes
```

## Rules of the code base

1. Services never import Express, pg or ioredis. They take their dependencies as arguments.
2. The route table (`src/http/routes.js`) is the single source of truth for paths, scopes,
   rate limit policies, schemas and the OpenAPI document.
3. Every state changing operator call needs an `Idempotency-Key` and is audited.
4. Every party scoped read or context checks that the API key may act for the party.
5. No em dash characters anywhere. Every source file carries the Broadridge header.

## Build status in the authoring sandbox

The npm registry was not reachable where this reference build was written, so `npm install`
could not run there. What was verified there: all 121 unit tests (with local stand-ins for
Ajv formats), every route schema compiled in Ajv 8 strict mode, the OpenAPI document validated
against the OpenAPI 3.0 JSON schema, the SQL migrations and repository statements run on
PostgreSQL 16, the rate limit Lua script run on Redis 7, and an HTTP smoke test of the full
middleware pipeline using a minimal Express stand-in. Run `npm install && npm run check && npm run test:integration`
as the first step on a normal workstation.
