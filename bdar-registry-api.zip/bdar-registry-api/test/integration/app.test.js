/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * End to end tests of the HTTP layer: Express, middleware order, validation, errors,
 * rate limits, idempotency and audit, with the fake ledger behind the services.
 *
 * Needs the npm dependencies (express, supertest, pino, ajv). Run with: npm run test:integration
 */

import { before, test } from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import pino from 'pino';
import { createApp } from '../../src/app.js';
import { createDependencies } from '../../src/container.js';
import { createFakeLedger } from '../fakes/fakeLedger.js';
import { INSTRUMENT_ID, PARTIES, custodial, basic, standardLedgerContracts, testConfig } from '../fakes/fixtures.js';

const logger = pino({ level: 'silent' });
let app;
let deps;
let keys;

async function buildApp(configOverrides = {}) {
  const config = testConfig(configOverrides);
  const dependencies = await createDependencies({
    config, logger, version: '1.0.0-test',
    overrides: { ledger: createFakeLedger(Object.values(standardLedgerContracts())), now: () => new Date('2026-09-14T12:00:00Z') },
  });
  return { app: createApp({ config, logger, dependencies, version: '1.0.0-test' }), dependencies };
}

before(async () => {
  ({ app, dependencies: deps } = await buildApp());
  const create = (input) => deps.apiKeyService.create(input, 'test').then((r) => r.apiKey);
  keys = {
    admin: await create({ clientName: 'Ops', scopes: ['keys:manage', 'operator:write', 'operator:read', 'audit:read', 'wallet'], allowedParties: ['*'] }),
    walletA: await create({ clientName: 'BitGo wallet', scopes: ['wallet'], allowedParties: [PARTIES.partyA, PARTIES.custodian] }),
    reader: await create({ clientName: 'Explorer', scopes: ['registry:read'] }),
  };
});

const transferBody = () => ({
  choiceArguments: {
    transfer: {
      sender: custodial(PARTIES.partyA, PARTIES.custodian, 'A-0001'), receiver: basic(PARTIES.partyB), amount: '10000000',
      instrumentId: { admin: PARTIES.admin, id: INSTRUMENT_ID }, requestedAt: '2026-09-14T11:00:00Z', executeBefore: '2026-09-15T11:00:00Z',
      inputHoldingCids: [], meta: { values: {} },
    },
    actors: [PARTIES.partyA, PARTIES.custodian],
    extraArgs: { context: { values: {} }, meta: { values: {} } },
  },
});

test('GET /ping and health probes need no key and carry security headers', async () => {
  const ping = await request(app).get('/ping').expect(200);
  assert.equal(ping.body.status, 'ok');
  assert.equal(ping.headers['x-powered-by'], undefined);
  assert.equal(ping.headers['cache-control'], 'no-store');
  assert.match(ping.headers['content-security-policy'], /default-src 'none'/);
  assert.equal(ping.headers['x-content-type-options'], 'nosniff');
  assert.ok(ping.headers['x-request-id']);
  await request(app).get('/health/live').expect(200);
  const ready = await request(app).get('/health/ready').expect(200);
  assert.equal(ready.body.status, 'ready');
});

test('authentication: 401 without a key, 401 for a bad key, 403 for a missing scope', async () => {
  const missing = await request(app).get('/registry/metadata/v1/info').expect(401);
  assert.equal(missing.body.code, 'AUTH_MISSING_API_KEY');
  assert.ok(missing.body.requestId);
  await request(app).get('/registry/metadata/v1/info').set('X-API-Key', 'bdar_test_nope').expect(401);
  const forbidden = await request(app).get('/health').set('X-API-Key', keys.reader).expect(403);
  assert.equal(forbidden.body.code, 'FORBIDDEN_SCOPE');
  const info = await request(app).get('/registry/metadata/v1/info').set('X-API-Key', keys.reader).expect(200);
  assert.equal(info.body.adminId, PARTIES.admin);
  assert.ok(info.headers['ratelimit-limit']);
});

test('transfer factory end to end, and party binding over HTTP', async () => {
  const ok = await request(app).post('/registry/transfer-instruction/v2/transfer-factory').set('X-API-Key', keys.walletA).send(transferBody()).expect(200);
  assert.equal(ok.body.transferKind, 'offer');
  assert.ok(ok.body.choiceContext.disclosedContracts.length > 5);
  const body = transferBody();
  body.choiceArguments.transfer.sender = basic(PARTIES.partyB);
  const denied = await request(app).post('/registry/transfer-instruction/v2/transfer-factory').set('X-API-Key', keys.walletA).send(body).expect(403);
  assert.equal(denied.body.code, 'FORBIDDEN_PARTY');
});

test('bad input: invalid JSON, wrong media type, unknown route, wrong method, too large', async () => {
  const invalid = await request(app).post('/registry/transfer-instruction/v2/transfer-factory').set('X-API-Key', keys.walletA)
    .set('Content-Type', 'application/json').send('{"choiceArguments":').expect(400);
  assert.equal(invalid.body.code, 'INVALID_JSON');
  await request(app).post('/registry/transfer-instruction/v2/transfer-factory').set('X-API-Key', keys.walletA)
    .set('Content-Type', 'text/plain').send('hello').expect(415);
  assert.equal((await request(app).get('/nope').expect(404)).body.code, 'ROUTE_NOT_FOUND');
  const wrongMethod = await request(app).delete('/ping').expect(405);
  assert.equal(wrongMethod.headers.allow, 'GET');
  const huge = { choiceArguments: { padding: 'x'.repeat(600 * 1024) } };
  assert.equal((await request(app).post('/registry/transfer-instruction/v2/transfer-factory').set('X-API-Key', keys.walletA).send(huge).expect(413)).body.code, 'PAYLOAD_TOO_LARGE');
});

test('operator command: Idempotency-Key required, replayed on retry, audited', async () => {
  const path = '/registry/bdar/v1/admin/accounts/freeze';
  const body = { account: custodial(PARTIES.partyA, PARTIES.custodian, 'A-0001'), reason: 'Sanctions screening hit' };
  assert.equal((await request(app).post(path).set('X-API-Key', keys.admin).send(body).expect(400)).body.code, 'IDEMPOTENCY_KEY_REQUIRED');
  const first = await request(app).post(path).set('X-API-Key', keys.admin).set('Idempotency-Key', 'freeze-A-0001-001').send(body).expect(200);
  const retry = await request(app).post(path).set('X-API-Key', keys.admin).set('Idempotency-Key', 'freeze-A-0001-001').send(body).expect(200);
  assert.equal(retry.headers['idempotent-replayed'], 'true');
  assert.deepEqual(retry.body, first.body);
  assert.equal(deps.ledger.submissions.length, 1, 'the ledger saw one command');
  await request(app).post(path).set('X-API-Key', keys.admin).set('Idempotency-Key', 'freeze-A-0001-001').send({ ...body, reason: 'other' }).expect(409);
  const audit = await request(app).get('/registry/bdar/v1/admin/audit-events?action=account.freeze').set('X-API-Key', keys.admin).expect(200);
  assert.ok(audit.body.items.some((event) => event.outcome === 'success'));
  const walletTry = await request(app).post(path).set('X-API-Key', keys.walletA).set('Idempotency-Key', 'freeze-by-wallet-1').send(body).expect(403);
  assert.equal(walletTry.body.code, 'FORBIDDEN_SCOPE');
});

test('API key lifecycle over HTTP: create, use, rotate, revoke', async () => {
  const created = await request(app).post('/admin/v1/api-keys').set('X-API-Key', keys.admin).set('Idempotency-Key', 'create-key-bitgo-2')
    .send({ clientName: 'BitGo wallet 2', scopes: ['wallet'], allowedParties: [PARTIES.partyB] }).expect(201);
  const newKey = created.body.apiKey;
  const whoami = await request(app).get('/auth/v1/whoami').set('X-API-Key', newKey).expect(200);
  assert.deepEqual(whoami.body.allowedParties, [PARTIES.partyB]);
  const rotated = await request(app).post(`/admin/v1/api-keys/${created.body.key.keyId}/rotate`).set('X-API-Key', keys.admin)
    .set('Idempotency-Key', 'rotate-bitgo-2-001').send({ overlapHours: 1 }).expect(200);
  await request(app).get('/auth/v1/whoami').set('X-API-Key', newKey).expect(200);
  await request(app).get('/auth/v1/whoami').set('X-API-Key', rotated.body.apiKey).expect(200);
  await request(app).post(`/admin/v1/api-keys/${created.body.key.keyId}/revoke`).set('X-API-Key', keys.admin).send({ reason: 'test' }).expect(200);
  await request(app).get('/auth/v1/whoami').set('X-API-Key', rotated.body.apiKey).expect(401);
  const escalation = await request(app).post('/admin/v1/api-keys').set('X-API-Key', keys.admin).set('Idempotency-Key', 'create-key-escalate')
    .send({ clientName: 'Escalate', scopes: ['submit'], allowedParties: [PARTIES.partyB] }).expect(403);
  assert.equal(escalation.body.code, 'FORBIDDEN_SCOPE');
});

test('rate limits answer 429 with Retry-After and can be switched off', async () => {
  const limited = await buildApp();
  const config = testConfig();
  for (let i = 0; i < config.rateLimit.policies.public.points; i += 1) await request(limited.app).get('/ping').expect(200);
  const refused = await request(limited.app).get('/ping').expect(429);
  assert.equal(refused.body.code, 'RATE_LIMITED');
  assert.ok(Number(refused.headers['retry-after']) >= 1);

  const off = await buildApp({ rateLimit: { ...config.rateLimit, enabled: false } });
  for (let i = 0; i < 70; i += 1) await request(off.app).get('/ping').expect(200);
});

test('bootstrap without a body is accepted (all fields optional)', async () => {
  const result = await request(app).post('/registry/bdar/v1/admin/bootstrap').set('X-API-Key', keys.admin).set('Idempotency-Key', 'bootstrap-0001').expect(200);
  assert.equal(result.body.alreadyBootstrapped, true);
});

test('OpenAPI documents are served as JSON and YAML', async () => {
  const json = await request(app).get('/openapi.json').expect(200);
  assert.equal(json.body.openapi, '3.0.3');
  const yaml = await request(app).get('/openapi.yaml').expect(200);
  assert.match(yaml.text, /^openapi: 3\.0\.3/m);
});
