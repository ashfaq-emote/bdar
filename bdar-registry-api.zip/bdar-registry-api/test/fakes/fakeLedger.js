/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * An in-memory stand in for the ledger client (src/ledger/ledgerClient.js).
 *
 * It keeps a map of active contracts, answers template and interface queries the
 * way the JSON Ledger API does, and records every submitted command so tests can
 * assert on exactly what the API sent to the ledger.
 */

import { LedgerError } from '../../src/ledger/ledgerClient.js';
import { qualifiedName } from '../../src/registry/daml.js';

export function createFakeLedger(initialContracts = []) {
  const contracts = new Map(initialContracts.map((entry) => [entry.createdEvent.contractId, entry]));
  const submissions = [];
  const prepared = [];
  const executed = [];
  let offset = 100;
  let failNext;

  const matches = (entry, templateIds = [], interfaceIds = []) => {
    const templateOk = templateIds.some((id) => qualifiedName(id) === qualifiedName(entry.createdEvent.templateId));
    const interfaceOk = interfaceIds.some((id) => (entry.createdEvent.interfaceViews ?? [])
      .some((view) => qualifiedName(view.interfaceId) === qualifiedName(id)));
    return templateOk || interfaceOk;
  };

  const maybeFail = () => {
    if (failNext) {
      const error = failNext;
      failNext = undefined;
      throw error;
    }
  };

  return {
    contracts,
    submissions,
    prepared,
    executed,

    /** Make the next ledger call fail with this error. */
    failNextWith(error) {
      failNext = error;
    },

    /** Helper for tests: a Canton style error. */
    cantonError(httpStatus, code, cause) {
      return new LedgerError({ httpStatus, cantonError: { code, cause, errorCategory: 1, context: {}, correlationId: 'corr-1' } });
    },

    add(entry) {
      contracts.set(entry.createdEvent.contractId, entry);
    },

    archive(contractId) {
      contracts.delete(contractId);
    },

    eventFormat: () => ({}),

    async version() {
      maybeFail();
      return { version: '3.4.0-fake' };
    },

    async ledgerEnd() {
      maybeFail();
      return offset;
    },

    async activeContracts({ templateIds, interfaceIds }) {
      maybeFail();
      return { offset, contracts: [...contracts.values()].filter((entry) => matches(entry, templateIds, interfaceIds)) };
    },

    async activeContractById(contractId) {
      maybeFail();
      return contracts.get(contractId);
    },

    async submitAndWaitForTransaction(request) {
      maybeFail();
      submissions.push(structuredClone(request));
      offset += 1;
      const events = request.commands.map((command, index) => (command.CreateCommand
        ? { CreatedEvent: { contractId: `00created${offset}${index}`, templateId: command.CreateCommand.templateId, createArgument: command.CreateCommand.createArguments } }
        : { ExercisedEvent: { contractId: command.ExerciseCommand.contractId, templateId: command.ExerciseCommand.templateId, choice: command.ExerciseCommand.choice, consuming: true, exerciseResult: { tag: 'FakeResult', value: {} } } }));
      return { updateId: `update-${offset}`, offset, events };
    },

    async prepare(request) {
      maybeFail();
      prepared.push(structuredClone(request));
      return { preparedTransaction: Buffer.from('prepared').toString('base64'), preparedTransactionHash: Buffer.from('hash').toString('base64'), hashingSchemeVersion: 'HASHING_SCHEME_VERSION_V2' };
    },

    async executeAndWait(request) {
      maybeFail();
      executed.push(structuredClone(request));
      offset += 1;
      return { updateId: `update-${offset}`, completionOffset: offset };
    },
  };
}
