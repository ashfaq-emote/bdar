/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Test fixtures: parties, configuration and registry contracts that look exactly like
 * what the JSON Ledger API returns for the Workstream 1 Daml model.
 *
 * The scenario is the worked example of the documentation: a tokenized US Treasury
 * note (instrument 912828CN5) issued by BR-Issuer-UST, held by Party A in a
 * custodial account at BitGo-Custody, traded against USDCX with Party B.
 */

import { createIdentifiers } from '../../src/registry/daml.js';

const fingerprint = (seed) => `1220${seed.repeat(64).slice(0, 64)}`;

export const PARTIES = Object.freeze({
  admin: `Broadridge-BDAR::${fingerprint('a')}`,
  issuer: `BR-Issuer-UST::${fingerprint('b')}`,
  partyA: `BitGo-PartyA::${fingerprint('c')}`,
  partyB: `BitGo-PartyB::${fingerprint('d')}`,
  custodian: `BitGo-Custody::${fingerprint('e')}`,
  executor: `Broadridge-DLR::${fingerprint('f')}`,
  credentialIssuer: `KYC-Provider::${fingerprint('1')}`,
  stranger: `Stranger::${fingerprint('2')}`,
});

export const INSTRUMENT_ID = '912828CN5';
export const PACKAGE_ID = 'f00d'.repeat(16);
export const API_PACKAGE_ID = 'beef'.repeat(16);
export const SYNCHRONIZER = `global-domain::${fingerprint('9')}`;

export const registryConfig = Object.freeze({
  adminParty: PARTIES.admin,
  registryName: 'Broadridge Digital Asset Registry',
  packageName: 'broadridge-digital-asset-registry',
  apiPackageName: 'broadridge-digital-asset-registry-api-v1',
  credentialReadParties: [PARTIES.credentialIssuer],
  contextCacheTtlMs: 0,
  maxSettlementAllocations: 100,
});

export const identifiers = createIdentifiers(registryConfig);

/** A full, frozen configuration object like loadConfig returns. */
export function testConfig(overrides = {}) {
  return {
    nodeEnv: 'test',
    isProduction: false,
    server: { host: '127.0.0.1', port: 0, trustProxyHops: 0, requestBodyLimit: '512kb', corsAllowedOrigins: [], openApiPublic: true, shutdownGraceMs: 0 },
    logLevel: 'silent',
    apiEnvironment: 'test',
    registry: registryConfig,
    ledger: { baseUrl: 'http://ledger.invalid', userId: 'bdar-registry-api', authMode: 'none', oauth: {}, timeoutMs: 5000, acsLimit: 1000 },
    database: { url: undefined, ssl: false, poolMax: 1 },
    apiKeys: { pepper: 'test-pepper-with-more-than-thirty-two-bytes-0123456789', cacheTtlMs: 0, rotationOverlapHours: 24, header: 'x-api-key' },
    idempotency: { ttlHours: 24 },
    rateLimit: {
      enabled: true,
      tiers: { standard: 1, elevated: 5, internal: 20 },
      policies: {
        public: { enabled: true, points: 60, durationSeconds: 60, blockSeconds: 0, keyBy: 'ip' },
        authFailure: { enabled: true, points: 3, durationSeconds: 900, blockSeconds: 900, keyBy: 'ip' },
        metadata: { enabled: true, points: 600, durationSeconds: 60, blockSeconds: 0, keyBy: 'apiKey' },
        context: { enabled: true, points: 300, durationSeconds: 60, blockSeconds: 0, keyBy: 'apiKey' },
        query: { enabled: true, points: 300, durationSeconds: 60, blockSeconds: 0, keyBy: 'apiKey' },
        submission: { enabled: true, points: 60, durationSeconds: 60, blockSeconds: 0, keyBy: 'apiKey' },
        operator: { enabled: true, points: 60, durationSeconds: 60, blockSeconds: 0, keyBy: 'apiKey' },
        keys: { enabled: true, points: 20, durationSeconds: 60, blockSeconds: 0, keyBy: 'apiKey' },
      },
    },
    redis: { url: undefined, keyPrefix: 'bdar:rl:', commandTimeoutMs: 200 },
    ...overrides,
  };
}

let counter = 0;
/** A unique hex contract id. */
export const cid = (label = '') => `00${Buffer.from(`${label}:${(counter += 1)}`).toString('hex').padEnd(64, '0')}`;

/** A JSON Ledger API active contract entry: { createdEvent, synchronizerId }. */
export function activeContract(templateName, payload, { contractId = cid(templateName), interfaceViews, packageId = PACKAGE_ID, packageName = registryConfig.packageName, createdAt = '2026-09-14T09:00:00Z' } = {}) {
  const qualified = templateName.includes(':') ? templateName : identifiers.templates[templateName].split(':').slice(1).join(':');
  return {
    createdEvent: {
      offset: 10,
      nodeId: 0,
      contractId,
      templateId: `${packageId}:${qualified}`,
      createArgument: payload,
      createdEventBlob: Buffer.from(`blob-of-${contractId}`).toString('base64'),
      interfaceViews,
      witnessParties: [PARTIES.admin],
      signatories: [PARTIES.admin],
      observers: [],
      createdAt,
      packageName,
    },
    synchronizerId: SYNCHRONIZER,
  };
}

export const basic = (party) => ({ owner: party, provider: null, id: '' });
export const custodial = (owner, provider, id) => ({ owner, provider, id });
export const meta = (values = {}) => ({ values });
export const relTime = (seconds) => ({ microseconds: String(seconds * 1000000) });

export function instrumentPayload(overrides = {}) {
  return {
    admin: PARTIES.admin,
    instrumentId: INSTRUMENT_ID,
    name: 'US Treasury Note 2.75% 2027',
    symbol: 'UST27',
    decimals: '2',
    issuers: [PARTIES.issuer],
    standards: 'BdarSupportsV1AndV2',
    accountPolicy: 'BdarExplicitAccounts',
    eligibilityPolicy: {
      allowlist: { appliesTo: ['BdarHold', 'BdarSend'] },
      credential: {
        enabled: true,
        trustedIssuers: [PARTIES.credentialIssuer],
        subject: 'BdarCredentialOwner',
        requirements: [{ registryAction: 'BdarHold', credentialAction: 'hold' }],
      },
    },
    supplyPolicy: { maxOutstandingSupply: '500000000.0000000000', maxMintPerRequest: '200000000.0000000000', mintApprovalRequired: false },
    redemptionPolicy: 'BdarRedeemWithIssuerApproval',
    settlementPolicy: {
      maxTransferTtl: relTime(7 * 86400),
      maxAllocationTtl: relTime(2 * 86400),
      allowCommittedAllocations: true,
      allowIteratedSettlement: false,
      allowMintAndBurnAllocations: false,
    },
    controlPolicy: { clawbackEnabled: true },
    pause: null,
    status: 'BdarInstrumentActive',
    meta: meta(),
    ...overrides,
  };
}

export const openRules = { owner: { canInitiate: true, mustApprove: true }, provider: null };
export const custodialRules = { owner: { canInitiate: true, mustApprove: false }, provider: { canInitiate: true, mustApprove: true } };

/** The standard registry: every singleton, the Treasury instrument, accounts, holdings and proofs. */
export function standardLedgerContracts() {
  const accountA = custodial(PARTIES.partyA, PARTIES.custodian, 'A-0001');
  const accountB = basic(PARTIES.partyB);
  const contracts = {
    registryConfig: activeContract('registryConfig', { admin: PARTIES.admin, registryName: 'Broadridge Digital Asset Registry', credentialChecksEnabled: true, meta: meta() }),
    eventLog: activeContract('eventLog', { admin: PARTIES.admin }),
    transferFactory: activeContract('transferFactory', { admin: PARTIES.admin }),
    allocationFactory: activeContract('allocationFactory', { admin: PARTIES.admin }),
    settlementFactory: activeContract('settlementFactory', { admin: PARTIES.admin }),
    issuanceFactory: activeContract('issuanceFactory', { admin: PARTIES.admin }),
    instrument: activeContract('instrument', instrumentPayload()),
    supply: activeContract('supply', { admin: PARTIES.admin, instrumentId: INSTRUMENT_ID, outstanding: '100000000.0000000000', totalMinted: '100000000.0000000000', totalBurned: '0.0000000000' }),
    accountA: activeContract('account', {
      admin: PARTIES.admin, account: accountA, rules: custodialRules, status: { tag: 'BdarAccountActive', value: {} },
      purpose: 'BdarClientAccount', termsReference: 'BitGo-Custody-Terms-v3', meta: meta(),
    }),
    accountB: activeContract('account', {
      admin: PARTIES.admin, account: accountB, rules: openRules, status: { tag: 'BdarAccountActive', value: {} },
      purpose: 'BdarClientAccount', termsReference: 'BDAR-Terms-v1', meta: meta(),
    }),
    allowlistA: activeContract('allowlistEntry', { admin: PARTIES.admin, party: PARTIES.partyA, instrumentId: INSTRUMENT_ID, validUntil: null, reference: 'KYC-A' }),
    allowlistB: activeContract('allowlistEntry', { admin: PARTIES.admin, party: PARTIES.partyB, instrumentId: INSTRUMENT_ID, validUntil: null, reference: 'KYC-B' }),
    holdingA1: activeContract('holding', { admin: PARTIES.admin, account: accountA, instrumentId: INSTRUMENT_ID, amount: '60000000.0000000000', lock: null, meta: meta() }),
    holdingA2: activeContract('holding', { admin: PARTIES.admin, account: accountA, instrumentId: INSTRUMENT_ID, amount: '30000000.0000000000', lock: null, meta: meta() }),
    lockedA: activeContract('holding', {
      admin: PARTIES.admin, account: accountA, instrumentId: INSTRUMENT_ID, amount: '10000000.0000000000',
      lock: { holders: [PARTIES.admin, PARTIES.custodian, PARTIES.partyA], expiresAt: '2099-01-01T00:00:00Z', expiresAfter: null, context: 'transfer' }, meta: meta(),
    }),
    credentialB: activeContract('Broadridge.DigitalAssetRegistry.Test.Credential:KycCredential', {}, {
      packageName: 'kyc-provider-credentials',
      interfaceViews: [{
        interfaceId: `${API_PACKAGE_ID}:Broadridge.DigitalAssetRegistry.Api.CredentialV1:BdarCredential`,
        viewStatus: { code: 0 },
        viewValue: { issuer: PARTIES.credentialIssuer, holder: PARTIES.partyB, status: 'BdarCredentialActive', entitlements: [], meta: meta() },
      }],
    }),
  };
  contracts.offerToB = activeContract('transferInstruction', {
    admin: PARTIES.admin,
    transfer: {
      sender: accountA, receiver: accountB, amount: '10000000.0000000000',
      instrumentId: { admin: PARTIES.admin, id: INSTRUMENT_ID }, requestedAt: '2026-09-14T10:00:00Z', executeBefore: '2026-09-15T10:00:00Z',
      inputHoldingCids: [], meta: meta(),
    },
    state: { tag: 'BdarAwaitingReceiver', value: { lockedHoldingCids: [contracts.lockedA.createdEvent.contractId], senderAuthorizers: [PARTIES.partyA, PARTIES.custodian], receiverApprovals: [] } },
    senderRules: custodialRules, receiverRules: openRules, issuers: [], originalInstructionCid: null,
  });
  return contracts;
}
