/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Builds the registry services on top of the fake ledger, the same way src/container.js
 * does, so service tests exercise the real reader and context builder.
 */

import { createFakeLedger } from './fakeLedger.js';
import { PARTIES, identifiers, standardLedgerContracts, testConfig } from './fixtures.js';
import { createLedgerContractReader } from '../../src/registry/contractReader.js';
import { createContextBuilder } from '../../src/registry/contextBuilder.js';
import { createTokenStandardService } from '../../src/services/tokenStandardService.js';
import { createBdarService } from '../../src/services/bdarService.js';
import { createSubmissionService } from '../../src/services/submissionService.js';
import { createOperatorService } from '../../src/services/operatorService.js';

export const FIXED_NOW = new Date('2026-09-14T12:00:00Z');

/** An authenticated key as req.auth holds it. */
export const authFor = (parties, scopes = ['wallet'], keyId = 'k000000000000001') => Object.freeze({
  keyId, clientName: 'test client', scopes, allowedParties: parties, rateLimitTier: 'standard', usingPreviousSecret: false,
});

export function createHarness({ contracts = standardLedgerContracts(), now = () => FIXED_NOW } = {}) {
  const config = testConfig();
  const ledger = createFakeLedger(Object.values(contracts));
  const reader = createLedgerContractReader({
    ledger, adminParty: PARTIES.admin, identifiers, cacheTtlMs: 0, credentialReadParties: config.registry.credentialReadParties,
  });
  const contextBuilder = createContextBuilder({ reader, adminParty: PARTIES.admin, now });
  return {
    config,
    contracts,
    ledger,
    reader,
    contextBuilder,
    tokenStandard: createTokenStandardService({ reader, contextBuilder, adminParty: PARTIES.admin, maxSettlementAllocations: 100, now }),
    bdar: createBdarService({ reader, contextBuilder, identifiers, adminParty: PARTIES.admin, now }),
    submissions: createSubmissionService({ ledger, reader, adminParty: PARTIES.admin, packageName: config.registry.packageName }),
    operator: createOperatorService({ ledger, reader, contextBuilder, identifiers, config, now }),
  };
}

/** Assert that a promise rejects with an ApiError of the given code. */
export async function rejectsWithCode(assert, promise, code) {
  await assert.rejects(promise, (error) => {
    assert.equal(error.code, code, `expected ${code} but got ${error.code}: ${error.message}`);
    return true;
  });
}
