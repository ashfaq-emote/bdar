/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * A tiny HTTP server that imitates the Canton JSON Ledger API v2 endpoints the
 * ledger client uses. It lets the client be tested over real HTTP, with real
 * status codes, headers and bodies.
 */

import http from 'node:http';

export async function startFakeJsonApi({ contracts = [], token } = {}) {
  const requests = [];
  const behaviour = { failWith: undefined, delayMs: 0 };
  const server = http.createServer((req, res) => {
    let text = '';
    req.on('data', (chunk) => { text += chunk; });
    req.on('end', async () => {
      const body = text ? JSON.parse(text) : undefined;
      requests.push({ method: req.method, url: req.url, headers: req.headers, body });
      const send = (status, payload) => {
        res.writeHead(status, { 'content-type': 'application/json' });
        res.end(JSON.stringify(payload));
      };
      if (behaviour.delayMs) await new Promise((resolve) => setTimeout(resolve, behaviour.delayMs));
      if (token && req.headers.authorization !== `Bearer ${token}`) return send(401, { code: 'UNAUTHENTICATED', cause: 'bad token' });
      if (behaviour.failWith) {
        const { status, error } = behaviour.failWith;
        behaviour.failWith = undefined;
        return send(status, error);
      }
      const path = req.url.split('?')[0];
      if (path === '/v2/version') return send(200, { version: '3.4.0' });
      if (path === '/v2/state/ledger-end') return send(200, { offset: 42 });
      if (path === '/v2/state/active-contracts') {
        return send(200, contracts.map((entry) => ({ workflowId: '', contractEntry: { JsActiveContract: { ...entry, reassignmentCounter: 0 } } })));
      }
      if (path === '/v2/events/events-by-contract-id') {
        const found = contracts.find((entry) => entry.createdEvent.contractId === body.contractId);
        if (!found) return send(404, { code: 'CONTRACT_EVENTS_NOT_FOUND', cause: 'Contract events not found, or not visible.' });
        return send(200, { created: { createdEvent: found.createdEvent, synchronizerId: found.synchronizerId } });
      }
      if (path === '/v2/commands/submit-and-wait-for-transaction') {
        return send(200, { transaction: { updateId: 'upd-1', offset: 43, events: [] } });
      }
      if (path === '/v2/interactive-submission/prepare') {
        return send(200, { preparedTransaction: 'cHJlcGFyZWQ=', preparedTransactionHash: 'aGFzaA==', hashingSchemeVersion: 'HASHING_SCHEME_VERSION_V2' });
      }
      if (path === '/v2/interactive-submission/executeAndWait') return send(200, { updateId: 'upd-2', completionOffset: 44 });
      return send(404, { code: 'NOT_FOUND', cause: path });
    });
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  return {
    baseUrl: `http://127.0.0.1:${port}`,
    requests,
    behaviour,
    close: () => new Promise((resolve) => server.close(resolve)),
  };
}
