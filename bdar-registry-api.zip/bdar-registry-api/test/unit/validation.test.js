/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createValidator, toJsonSchema } from '../../src/http/validation.js';
import { buildRoutes } from '../../src/http/routes.js';
import { PARTIES } from '../fakes/fixtures.js';

const validator = createValidator();
const routes = Object.fromEntries(buildRoutes().map((route) => [route.operationId, route]));
/** Validate a request context in place, as the router does. */
const check = (operationId, ctx) => {
  ctx.params ??= {};
  ctx.query ??= {};
  validator.compileRoute(routes[operationId])(ctx);
  return ctx;
};

test('every route schema compiles in Ajv strict mode', () => {
  for (const route of Object.values(routes)) assert.doesNotThrow(() => validator.compileRoute(route), route.operationId);
});

test('nullable OpenAPI schemas become JSON Schema unions', () => {
  assert.deepEqual(toJsonSchema({ type: 'string', nullable: true, example: 'x' }), { type: ['string', 'null'] });
  assert.deepEqual(toJsonSchema({ allOf: [{ $ref: '#/components/schemas/Account' }], nullable: true }), {
    anyOf: [{ allOf: [{ $ref: 'bdar-components.json#/definitions/Account' }] }, { type: 'null' }],
  });
  assert.deepEqual(toJsonSchema({ type: 'string', enum: ['A'], nullable: true }), { type: ['string', 'null'], enum: ['A', null] });
});

test('Broadridge bodies refuse unknown fields (mass assignment)', () => {
  const body = { account: { owner: PARTIES.partyA }, reason: 'Sanctions hit', status: 'ACTIVE' };
  assert.throws(() => check('freezeAccount', { body }), (error) => {
    assert.equal(error.code, 'VALIDATION_FAILED');
    assert.equal(error.details[0].unexpected, 'status');
    return true;
  });
  assert.doesNotThrow(() => check('freezeAccount', { body: { account: { owner: PARTIES.partyA }, reason: 'Sanctions hit' } }));
});

test('token standard bodies allow extra fields but check the ones they use', () => {
  const body = {
    choiceArguments: {
      transfer: {
        sender: { owner: PARTIES.partyA, provider: null, id: '' }, receiver: { owner: PARTIES.partyB, provider: null, id: '' },
        amount: '10.5', instrumentId: { admin: PARTIES.admin, id: '912828CN5' }, requestedAt: '2026-09-14T10:00:00Z',
        executeBefore: '2026-09-15T10:00:00Z', inputHoldingCids: [], meta: { values: {} },
      },
      actors: [PARTIES.partyA], extraArgs: { context: { values: {} }, meta: { values: {} } }, futureField: true,
    },
  };
  assert.doesNotThrow(() => check('getTransferFactoryV2', { body }));
  const badAmount = structuredClone(body);
  badAmount.choiceArguments.transfer.amount = '1e6';
  assert.throws(() => check('getTransferFactoryV2', { body: badAmount }), { code: 'VALIDATION_FAILED' });
  const badTime = structuredClone(body);
  badTime.choiceArguments.transfer.executeBefore = 'tomorrow';
  assert.throws(() => check('getTransferFactoryV2', { body: badTime }), { code: 'VALIDATION_FAILED' });
});

test('query parameters are coerced, bounded and unknown ones refused', () => {
  const ctx = { params: { party: PARTIES.partyA }, query: { pageSize: '50' } };
  check('listPartyHoldings', ctx);
  assert.equal(ctx.query.pageSize, 50);
  assert.throws(() => check('listPartyHoldings', { params: { party: PARTIES.partyA }, query: { pageSize: '100000' } }), { code: 'VALIDATION_FAILED' });
  assert.throws(() => check('listPartyHoldings', { params: { party: PARTIES.partyA }, query: { debug: 'true' } }), { code: 'VALIDATION_FAILED' });
  assert.throws(() => check('listPartyHoldings', { params: { party: 'not-a-party' }, query: {} }), { code: 'VALIDATION_FAILED' });
});

test('optional bodies default to an empty object; body-less routes refuse a body', () => {
  const ctx = { params: { instrumentId: '912828CN5' }, body: undefined };
  check('resumeInstrument', ctx);
  assert.deepEqual(ctx.body, {});
  assert.throws(() => check('createInstrument', { body: undefined }), { code: 'VALIDATION_FAILED' });
  assert.throws(() => check('getRegistryInfo', { body: { x: 1 } }), { code: 'VALIDATION_FAILED' });
});

test('account change is one of the four documented shapes', () => {
  const base = { account: { owner: PARTIES.partyB, provider: PARTIES.custodian, id: 'B-1' }, reference: 'ONB-1' };
  const rules = { owner: { canInitiate: true, mustApprove: false }, provider: { canInitiate: true, mustApprove: true } };
  assert.doesNotThrow(() => check('validateAccountRequest', { body: { ...base, change: { type: 'OPEN', rules, termsReference: 'T' } } }));
  assert.doesNotThrow(() => check('validateAccountRequest', { body: { ...base, change: { type: 'CLOSE' } } }));
  assert.throws(() => check('validateAccountRequest', { body: { ...base, change: { type: 'CLOSE', rules } } }), { code: 'VALIDATION_FAILED' });
  assert.throws(() => check('validateAccountRequest', { body: { ...base, change: { type: 'DELETE' } } }), { code: 'VALIDATION_FAILED' });
});

test('API key creation refuses unknown scopes and malformed parties', () => {
  assert.doesNotThrow(() => check('createApiKey', { body: { clientName: 'BitGo wallet', scopes: ['wallet'], allowedParties: [PARTIES.partyA] } }));
  assert.doesNotThrow(() => check('createApiKey', { body: { clientName: 'Ops', scopes: ['operator:read'], allowedParties: ['*'] } }));
  assert.throws(() => check('createApiKey', { body: { clientName: 'x', scopes: ['admin'] } }), { code: 'VALIDATION_FAILED' });
  assert.throws(() => check('createApiKey', { body: { clientName: 'x', scopes: ['wallet'], allowedParties: ['Robert"); DROP TABLE'] } }), { code: 'VALIDATION_FAILED' });
});
