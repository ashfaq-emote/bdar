/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ContextKeys } from '../../src/registry/daml.js';
import {
  INSTRUMENT_ID, PARTIES, activeContract, basic, custodial, instrumentPayload, meta, standardLedgerContracts,
} from '../fakes/fixtures.js';
import { authFor, createHarness, rejectsWithCode } from '../fakes/harness.js';

const accountA = custodial(PARTIES.partyA, PARTIES.custodian, 'A-0001');
const accountB = basic(PARTIES.partyB);
const walletA = authFor([PARTIES.partyA]);
const walletB = authFor([PARTIES.partyB]);
const instrumentRef = { admin: PARTIES.admin, id: INSTRUMENT_ID };

const transferV2 = (overrides = {}) => ({
  choiceArguments: {
    transfer: {
      sender: accountA, receiver: accountB, amount: '10000000', instrumentId: instrumentRef,
      requestedAt: '2026-09-14T11:59:00Z', executeBefore: '2026-09-15T12:00:00Z', inputHoldingCids: [], meta: meta(),
      ...overrides,
    },
    actors: [PARTIES.partyA, PARTIES.custodian],
    extraArgs: { context: { values: {} }, meta: meta() },
  },
});

test('registry info and instrument metadata follow the token standard schema', async () => {
  const h = createHarness();
  const info = await h.tokenStandard.getRegistryInfo();
  assert.equal(info.adminId, PARTIES.admin);
  assert.equal(info.supportedApis['splice-api-token-transfer-instruction-v2'], 1);
  const instrument = await h.tokenStandard.getInstrument(INSTRUMENT_ID);
  assert.deepEqual({ ...instrument, totalSupplyAsOf: undefined }, {
    id: INSTRUMENT_ID, name: 'US Treasury Note 2.75% 2027', symbol: 'UST27', decimals: 2, paused: false,
    supportedApis: info.supportedApis, showAccountInputFields: true, accountInputFieldsToShow: ['provider', 'accountId'],
    totalSupply: '100000000', totalSupplyAsOf: undefined,
  });
  await rejectsWithCode(assert, h.tokenStandard.getInstrument('NOPE'), 'INSTRUMENT_NOT_FOUND');
});

test('a V2 only instrument leaves V1 APIs out, and a paused one shows pauseInfo', async () => {
  const contracts = standardLedgerContracts();
  contracts.instrument = activeContract('instrument', instrumentPayload({ standards: 'BdarSupportsV2Only', pause: { reason: 'Corporate action', pausedUntil: '2026-09-16T00:00:00Z' } }));
  const h = createHarness({ contracts });
  const instrument = await h.tokenStandard.getInstrument(INSTRUMENT_ID);
  assert.equal(instrument.supportedApis['splice-api-token-transfer-instruction-v1'], undefined);
  assert.equal(instrument.supportedApis['splice-api-token-transfer-instruction-v2'], 1);
  assert.deepEqual(instrument.pauseInfo, { reason: 'Corporate action', until: '2026-09-16T00:00:00Z' });
  assert.equal(instrument.paused, true);
});

test('instrument listing pages with an opaque token', async () => {
  const contracts = standardLedgerContracts();
  for (const id of ['AAA1', 'BBB2', 'CCC3']) contracts[id] = activeContract('instrument', instrumentPayload({ instrumentId: id }));
  const h = createHarness({ contracts });
  const first = await h.tokenStandard.listInstruments({ pageSize: 2 });
  assert.deepEqual(first.instruments.map((i) => i.id), ['912828CN5', 'AAA1']);
  const second = await h.tokenStandard.listInstruments({ pageSize: 2, pageToken: first.nextPageToken });
  assert.deepEqual(second.instruments.map((i) => i.id), ['BBB2', 'CCC3']);
  assert.equal(second.nextPageToken, undefined);
  await rejectsWithCode(assert, h.tokenStandard.listInstruments({ pageToken: '!!!' }), 'VALIDATION_FAILED');
});

test('transfer factory V2: offer by default, with factory id and context', async () => {
  const h = createHarness();
  const result = await h.tokenStandard.getTransferFactory({ version: 2, body: transferV2(), auth: walletA });
  assert.equal(result.factoryId, h.contracts.transferFactory.createdEvent.contractId);
  assert.equal(result.transferKind, 'offer');
  assert.ok(result.choiceContext.disclosedContracts.some((d) => d.contractId === result.factoryId));
  assert.ok(result.choiceContext.choiceContextData.values[ContextKeys.accounts].value[`${PARTIES.partyB}||`]);
});

test('transferKind: self, direct by preapproval, direct by receiver actors, redemption', async () => {
  const h = createHarness();
  const self = await h.tokenStandard.getTransferFactory({ version: 2, body: transferV2({ receiver: accountA }), auth: walletA });
  assert.equal(self.transferKind, 'self');

  const joint = transferV2();
  joint.choiceArguments.actors.push(PARTIES.partyB);
  assert.equal((await h.tokenStandard.getTransferFactory({ version: 2, body: joint, auth: walletA })).transferKind, 'direct');

  const contracts = standardLedgerContracts();
  contracts.preapprovalB = activeContract('preapproval', { admin: PARTIES.admin, account: accountB, instrumentIds: null, expiresAt: null });
  const withPreapproval = createHarness({ contracts });
  assert.equal((await withPreapproval.tokenStandard.getTransferFactory({ version: 2, body: transferV2(), auth: walletA })).transferKind, 'direct');

  const burn = { owner: null, provider: null, id: 'cip-112/burn' };
  assert.equal((await h.tokenStandard.getTransferFactory({ version: 2, body: transferV2({ receiver: burn }), auth: walletA })).transferKind, 'offer', 'issuer approval needed');
  const immediate = standardLedgerContracts();
  immediate.instrument = activeContract('instrument', instrumentPayload({ redemptionPolicy: 'BdarRedeemImmediately' }));
  assert.equal((await createHarness({ contracts: immediate }).tokenStandard.getTransferFactory({ version: 2, body: transferV2({ receiver: burn }), auth: walletA })).transferKind, 'direct');
});

test('party binding: only a sender party may fetch a transfer factory context', async () => {
  const h = createHarness();
  await rejectsWithCode(assert, h.tokenStandard.getTransferFactory({ version: 2, body: transferV2(), auth: walletB }), 'FORBIDDEN_PARTY');
  const custodian = authFor([PARTIES.custodian]);
  assert.equal((await h.tokenStandard.getTransferFactory({ version: 2, body: transferV2(), auth: custodian })).transferKind, 'offer');
});

test('wrong admin, mint sender and unknown instrument are refused before any context is built', async () => {
  const h = createHarness();
  await rejectsWithCode(assert, h.tokenStandard.getTransferFactory({ version: 2, body: transferV2({ instrumentId: { admin: PARTIES.stranger, id: INSTRUMENT_ID } }), auth: walletA }), 'WRONG_ADMIN');
  await rejectsWithCode(assert, h.tokenStandard.getTransferFactory({ version: 2, body: transferV2({ sender: { owner: null, provider: null, id: 'cip-112/mint' } }), auth: walletA }), 'VALIDATION_FAILED');
  await rejectsWithCode(assert, h.tokenStandard.getTransferFactory({ version: 2, body: transferV2({ instrumentId: { admin: PARTIES.admin, id: 'NOPE' } }), auth: walletA }), 'INSTRUMENT_NOT_FOUND');
});

test('transfer factory V1 uses basic accounts and refuses V2 only instruments', async () => {
  const h = createHarness();
  const body = {
    choiceArguments: {
      expectedAdmin: PARTIES.admin,
      transfer: { sender: PARTIES.partyB, receiver: PARTIES.partyA, amount: '5', instrumentId: instrumentRef, requestedAt: '2026-09-14T11:00:00Z', executeBefore: '2026-09-15T11:00:00Z', inputHoldingCids: [], meta: meta() },
      extraArgs: {},
    },
  };
  const result = await h.tokenStandard.getTransferFactory({ version: 1, body, auth: walletB });
  assert.equal(result.transferKind, 'offer');
  await rejectsWithCode(assert, h.tokenStandard.getTransferFactory({ version: 1, body: { choiceArguments: { ...body.choiceArguments, expectedAdmin: PARTIES.stranger } }, auth: walletB }), 'WRONG_ADMIN');

  const contracts = standardLedgerContracts();
  contracts.instrument = activeContract('instrument', instrumentPayload({ standards: 'BdarSupportsV2Only' }));
  await rejectsWithCode(assert, createHarness({ contracts }).tokenStandard.getTransferFactory({ version: 1, body, auth: walletB }), 'VALIDATION_FAILED');
});

test('accepting an offer discloses the sender locked holdings to the receiver', async () => {
  const h = createHarness();
  const offer = h.contracts.offerToB.createdEvent.contractId;
  const context = await h.tokenStandard.getTransferInstructionContext({ version: 2, action: 'accept', contractId: offer, body: {}, auth: walletB });
  assert.ok(context.disclosedContracts.some((d) => d.contractId === h.contracts.lockedA.createdEvent.contractId));
  await rejectsWithCode(assert, h.tokenStandard.getTransferInstructionContext({ version: 2, action: 'accept', contractId: offer, body: {}, auth: authFor([PARTIES.stranger]) }), 'FORBIDDEN_PARTY');
  await rejectsWithCode(assert, h.tokenStandard.getTransferInstructionContext({ version: 2, action: 'accept', contractId: h.contracts.instrument.createdEvent.contractId, body: {}, auth: walletB }), 'CONTRACT_NOT_FOUND');
  await rejectsWithCode(assert, h.tokenStandard.getTransferInstructionContext({ version: 2, action: 'accept', contractId: '00dead', body: {}, auth: walletB }), 'CONTRACT_NOT_FOUND');
});

function allocationFixture({ v1 = false } = {}) {
  const contracts = standardLedgerContracts();
  const core = {
    settlement: { executors: [PARTIES.executor], id: 'DVP-2026-0915-001', cid: null, meta: meta() },
    allocation: {
      admin: PARTIES.admin, authorizer: custodial(PARTIES.partyA, PARTIES.custodian, 'A-0001'),
      transferLegSides: [{ transferLegId: 'leg-ust', side: 'SenderSide', otherside: basic(PARTIES.partyB), amount: '50000000', instrumentId: INSTRUMENT_ID, meta: meta() }],
      settlementDeadline: '2026-09-15T20:00:00Z', nextIterationFunding: null, committed: false, meta: meta(),
    },
    lockedHoldingCids: [contracts.lockedA.createdEvent.contractId],
    authorizers: [PARTIES.partyA, PARTIES.custodian], withdrawers: [PARTIES.partyA, PARTIES.custodian],
    createdAt: '2026-09-14T11:00:00Z', expiresAt: '2026-09-15T20:00:00Z', allocateBefore: null, numIterations: '0', originalAllocationCid: null,
  };
  contracts.allocation = v1 ? activeContract('allocationV1', { core }) : activeContract('allocation', core);
  return contracts;
}

test('allocation factory V2 builds the authorizer proofs; party binding on the authorizer', async () => {
  const h = createHarness({ contracts: allocationFixture() });
  const body = {
    choiceArguments: {
      settlement: { executors: [PARTIES.executor], id: 'DVP-1', cid: null, meta: meta() },
      allocation: allocationFixture().allocation.createdEvent.createArgument.allocation,
      requestedAt: '2026-09-14T11:00:00Z', inputHoldingCids: [], extraArgs: {}, actors: [PARTIES.partyA, PARTIES.custodian],
    },
  };
  const result = await h.tokenStandard.getAllocationFactory({ version: 2, body, auth: walletA });
  assert.equal(result.factoryId, h.contracts.allocationFactory.createdEvent.contractId);
  await rejectsWithCode(assert, h.tokenStandard.getAllocationFactory({ version: 2, body, auth: walletB }), 'FORBIDDEN_PARTY');
});

test('settlement factory: executor only, discloses every allocation locked holding, checks executors match', async () => {
  const h = createHarness({ contracts: allocationFixture() });
  const allocationCid = h.contracts.allocation.createdEvent.contractId;
  const body = {
    choiceArguments: {
      settlement: { executors: [PARTIES.executor], id: 'DVP-2026-0915-001', cid: null, meta: meta() },
      transferLegs: [{ transferLegId: 'leg-ust', sender: accountA, receiver: accountB, amount: '50000000', instrumentId: INSTRUMENT_ID, meta: meta() }],
      allocations: [{ allocationCid, extraTransferLegSides: [], nextIterationFunding: null }],
      actors: [PARTIES.executor], extraArgs: {},
    },
  };
  const executor = authFor([PARTIES.executor], ['executor']);
  const result = await h.tokenStandard.getSettlementFactory({ body, auth: executor });
  assert.equal(result.factoryId, h.contracts.settlementFactory.createdEvent.contractId);
  assert.ok(result.choiceContext.disclosedContracts.some((d) => d.contractId === h.contracts.lockedA.createdEvent.contractId));
  await rejectsWithCode(assert, h.tokenStandard.getSettlementFactory({ body, auth: walletA }), 'FORBIDDEN_PARTY');

  const otherExecutor = structuredClone(body);
  otherExecutor.choiceArguments.settlement.executors = [PARTIES.stranger];
  await rejectsWithCode(assert, h.tokenStandard.getSettlementFactory({ body: otherExecutor, auth: authFor([PARTIES.stranger], ['executor']) }), 'FORBIDDEN_PARTY');

  const tooMany = structuredClone(body);
  tooMany.choiceArguments.allocations = Array.from({ length: 101 }, () => ({ allocationCid }));
  await rejectsWithCode(assert, h.tokenStandard.getSettlementFactory({ body: tooMany, auth: executor }), 'VALIDATION_FAILED');
});

test('V1 execute-transfer includes the V1 factories; V1 endpoints refuse V2 only allocations', async () => {
  const v1 = createHarness({ contracts: allocationFixture({ v1: true }) });
  const executor = authFor([PARTIES.executor], ['executor']);
  const context = await v1.tokenStandard.getAllocationContext({ version: 1, action: 'execute-transfer', contractId: v1.contracts.allocation.createdEvent.contractId, body: {}, auth: executor });
  const values = context.choiceContextData.values;
  assert.equal(values[ContextKeys.allocationFactory].value, v1.contracts.allocationFactory.createdEvent.contractId);
  assert.equal(values[ContextKeys.settlementFactory].value, v1.contracts.settlementFactory.createdEvent.contractId);

  const v2 = createHarness({ contracts: allocationFixture() });
  await rejectsWithCode(assert, v2.tokenStandard.getAllocationContext({ version: 1, action: 'cancel', contractId: v2.contracts.allocation.createdEvent.contractId, body: {}, auth: executor }), 'CONTRACT_NOT_FOUND');
  const withdraw = await v2.tokenStandard.getAllocationContext({ version: 2, action: 'withdraw', contractId: v2.contracts.allocation.createdEvent.contractId, body: { excludeDebugFields: true }, auth: walletA });
  assert.equal(withdraw.choiceContextData.values[ContextKeys.allocationFactory], undefined);
  await rejectsWithCode(assert, v2.tokenStandard.getAllocationContext({ version: 2, action: 'withdraw', contractId: v2.contracts.allocation.createdEvent.contractId, body: {}, auth: executor }), 'FORBIDDEN_PARTY');
});
