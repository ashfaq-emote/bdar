/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { ConfigError, loadConfig } from '../../src/config/index.js';
import { PARTIES } from '../fakes/fixtures.js';

const rateLimits = readFileSync(new URL('../../config/rate-limits.json', import.meta.url), 'utf8');
const readFile = () => rateLimits;
const base = {
  BDAR_ADMIN_PARTY: PARTIES.admin,
  LEDGER_JSON_API_URL: 'http://localhost:7575',
  API_KEY_PEPPER: 'a-pepper-that-is-longer-than-thirty-two-bytes-000',
};

test('a minimal development configuration loads with safe defaults', () => {
  const config = loadConfig(base, { readFile });
  assert.equal(config.server.port, 8080);
  assert.equal(config.apiEnvironment, 'dev');
  assert.equal(config.rateLimit.enabled, true);
  assert.equal(config.rateLimit.policies.context.points, 300);
  assert.equal(config.registry.contextCacheTtlMs, 1000);
  assert.ok(Object.isFrozen(config.rateLimit.policies.context), 'configuration is deeply frozen');
});

test('rate limits can be switched off and tuned from the environment', () => {
  const config = loadConfig({
    ...base, RATE_LIMIT_ENABLED: 'false', RATE_LIMIT_CONTEXT_POINTS: '1000', RATE_LIMIT_AUTH_FAILURE_BLOCK_SECONDS: '60', RATE_LIMIT_OPERATOR_ENABLED: 'false',
  }, { readFile });
  assert.equal(config.rateLimit.enabled, false);
  assert.equal(config.rateLimit.policies.context.points, 1000);
  assert.equal(config.rateLimit.policies.authFailure.blockSeconds, 60);
  assert.equal(config.rateLimit.policies.operator.enabled, false);
});

test('every problem is reported at once', () => {
  try {
    loadConfig({ PORT: 'eighty', LEDGER_AUTH_MODE: 'oauth2' }, { readFile });
    assert.fail('expected ConfigError');
  } catch (error) {
    assert.ok(error instanceof ConfigError);
    const text = error.problems.join('\n');
    for (const expected of ['BDAR_ADMIN_PARTY', 'LEDGER_JSON_API_URL', 'PORT', 'OAUTH_TOKEN_URL', 'API_KEY_PEPPER']) {
      assert.match(text, new RegExp(expected));
    }
  }
});

test('production refuses unsafe settings', () => {
  assert.throws(() => loadConfig({ ...base, NODE_ENV: 'production', CORS_ALLOWED_ORIGINS: '*' }, { readFile }), (error) => {
    const text = error.problems.join('\n');
    assert.match(text, /DATABASE_URL is required/);
    assert.match(text, /LEDGER_AUTH_MODE=none is not allowed/);
    assert.match(text, /must use https/);
    assert.match(text, /CORS_ALLOWED_ORIGINS/);
    return true;
  });
});

test('a short pepper and a missing rate limit policy are refused', () => {
  const missingPolicy = JSON.stringify({ enabled: true, tiers: { standard: 1 }, policies: {} });
  assert.throws(() => loadConfig({ ...base, API_KEY_PEPPER: 'short' }, { readFile: () => missingPolicy }), (error) => {
    const text = error.problems.join('\n');
    assert.match(text, /API_KEY_PEPPER/);
    assert.match(text, /rate limit policy context is missing/);
    return true;
  });
});
