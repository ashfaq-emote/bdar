/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ContextKeys } from '../../src/registry/daml.js';
import { INSTRUMENT_ID, PARTIES, activeContract, basic, custodial, instrumentPayload, standardLedgerContracts } from '../fakes/fixtures.js';
import { createHarness, rejectsWithCode } from '../fakes/harness.js';

const accountA = custodial(PARTIES.partyA, PARTIES.custodian, 'A-0001');
const accountB = basic(PARTIES.partyB);
const values = (context) => context.choiceContext.choiceContextData.values;
const disclosedIds = (context) => context.choiceContext.disclosedContracts.map((d) => d.contractId);

test('a transfer context holds exactly the proofs of the instrument and both accounts', async () => {
  const h = createHarness();
  const c = h.contracts;
  const context = await h.contextBuilder.build({ instrumentIds: [INSTRUMENT_ID], accounts: [accountA, accountB] });
  const v = values(context);

  assert.deepEqual(v[ContextKeys.registryConfig], { tag: 'AV_ContractId', value: c.registryConfig.createdEvent.contractId });
  assert.deepEqual(v[ContextKeys.eventLog], { tag: 'AV_ContractId', value: c.eventLog.createdEvent.contractId });
  assert.deepEqual(v[ContextKeys.instruments], { tag: 'AV_Map', value: { [INSTRUMENT_ID]: { tag: 'AV_ContractId', value: c.instrument.createdEvent.contractId } } });
  assert.deepEqual(v[ContextKeys.supplies].value[INSTRUMENT_ID].value, c.supply.createdEvent.contractId);
  assert.deepEqual(Object.keys(v[ContextKeys.accounts].value).sort(), [
    `${PARTIES.partyA}|${PARTIES.custodian}|A-0001`, `${PARTIES.partyB}||`,
  ].sort());
  assert.deepEqual(Object.keys(v[ContextKeys.allowlist].value).sort(), [`${PARTIES.partyA}|${INSTRUMENT_ID}`, `${PARTIES.partyB}|${INSTRUMENT_ID}`].sort());
  assert.deepEqual(v[ContextKeys.credentials].value[PARTIES.partyB], { tag: 'AV_List', value: [{ tag: 'AV_ContractId', value: c.credentialB.createdEvent.contractId }] });
  assert.equal(v[ContextKeys.allocationFactory], undefined, 'V1 factories only for execute-transfer');

  const ids = disclosedIds(context);
  for (const name of ['registryConfig', 'eventLog', 'instrument', 'supply', 'accountA', 'accountB', 'allowlistA', 'allowlistB', 'credentialB']) {
    assert.ok(ids.includes(c[name].createdEvent.contractId), `${name} is disclosed`);
  }
  assert.ok(!ids.includes(c.holdingA1.createdEvent.contractId), 'holdings are not disclosed unless asked');
  assert.equal(new Set(ids).size, ids.length, 'no duplicates');
  const disclosed = context.choiceContext.disclosedContracts[0];
  assert.ok(disclosed.createdEventBlob && disclosed.synchronizerId && disclosed.templateId);
  assert.ok('debugPayload' in disclosed);
});

test('debug fields can be excluded', async () => {
  const h = createHarness();
  const context = await h.contextBuilder.build({ instrumentIds: [INSTRUMENT_ID], excludeDebugFields: true });
  for (const d of context.choiceContext.disclosedContracts) {
    assert.deepEqual(Object.keys(d).sort(), ['contractId', 'createdEventBlob', 'synchronizerId', 'templateId']);
  }
});

test('allowlist and credential proofs are left out when no policy needs them', async () => {
  const contracts = standardLedgerContracts();
  contracts.instrument = activeContract('instrument', instrumentPayload({ eligibilityPolicy: { allowlist: null, credential: null } }));
  const h = createHarness({ contracts });
  const context = await h.contextBuilder.build({ instrumentIds: [INSTRUMENT_ID], accounts: [accountA, accountB] });
  assert.deepEqual(values(context)[ContextKeys.allowlist].value, {});
  assert.deepEqual(values(context)[ContextKeys.credentials].value, {});
});

test('credential proofs are left out when the registry switch is off, and untrusted or inactive credentials never appear', async () => {
  const contracts = standardLedgerContracts();
  contracts.registryConfig.createdEvent.createArgument.credentialChecksEnabled = false;
  let h = createHarness({ contracts });
  assert.deepEqual(values(await h.contextBuilder.build({ instrumentIds: [INSTRUMENT_ID], accounts: [accountB] }))[ContextKeys.credentials].value, {});

  const other = standardLedgerContracts();
  other.credentialB.createdEvent.interfaceViews[0].viewValue.issuer = PARTIES.stranger;
  h = createHarness({ contracts: other });
  assert.deepEqual(values(await h.contextBuilder.build({ instrumentIds: [INSTRUMENT_ID], accounts: [accountB] }))[ContextKeys.credentials].value, {});
});

test('an expired preapproval or allowlist entry is not offered', async () => {
  const contracts = standardLedgerContracts();
  contracts.preapprovalB = activeContract('preapproval', { admin: PARTIES.admin, account: accountB, instrumentIds: null, expiresAt: '2026-01-01T00:00:00Z' });
  contracts.allowlistB.createdEvent.createArgument.validUntil = '2026-01-01T00:00:00Z';
  const h = createHarness({ contracts });
  const v = values(await h.contextBuilder.build({ instrumentIds: [INSTRUMENT_ID], accounts: [accountB] }));
  assert.deepEqual(v[ContextKeys.preapprovals].value, {});
  assert.deepEqual(v[ContextKeys.allowlist].value, {});
});

test('a preapproval for other instruments is not offered; a covering one is', async () => {
  const contracts = standardLedgerContracts();
  contracts.otherPreapproval = activeContract('preapproval', { admin: PARTIES.admin, account: accountB, instrumentIds: ['USDCX'], expiresAt: null });
  let h = createHarness({ contracts });
  assert.deepEqual(values(await h.contextBuilder.build({ instrumentIds: [INSTRUMENT_ID], accounts: [accountB] }))[ContextKeys.preapprovals].value, {});
  contracts.covering = activeContract('preapproval', { admin: PARTIES.admin, account: accountB, instrumentIds: [INSTRUMENT_ID], expiresAt: '2027-01-01T00:00:00Z' });
  h = createHarness({ contracts });
  const v = values(await h.contextBuilder.build({ instrumentIds: [INSTRUMENT_ID], accounts: [accountB] }));
  assert.equal(v[ContextKeys.preapprovals].value[`${PARTIES.partyB}||`].value, contracts.covering.createdEvent.contractId);
});

test('holdings to disclose must be active holdings of this registry', async () => {
  const h = createHarness();
  const locked = h.contracts.lockedA.createdEvent.contractId;
  const context = await h.contextBuilder.build({ instrumentIds: [INSTRUMENT_ID], holdingCids: [locked] });
  assert.ok(disclosedIds(context).includes(locked));
  await rejectsWithCode(assert, h.contextBuilder.build({ instrumentIds: [INSTRUMENT_ID], holdingCids: ['00feed'] }), 'STALE_CONTRACT');
  await rejectsWithCode(assert, h.contextBuilder.build({ instrumentIds: [INSTRUMENT_ID], holdingCids: [h.contracts.instrument.createdEvent.contractId] }), 'VALIDATION_FAILED');
});

test('unknown instruments are 404, an unbootstrapped registry is 503, and oversized requests are 400', async () => {
  const h = createHarness();
  await rejectsWithCode(assert, h.contextBuilder.build({ instrumentIds: ['NOPE'] }), 'INSTRUMENT_NOT_FOUND');
  const empty = standardLedgerContracts();
  delete empty.registryConfig;
  await rejectsWithCode(assert, createHarness({ contracts: empty }).contextBuilder.build({ instrumentIds: [INSTRUMENT_ID] }), 'REGISTRY_NOT_BOOTSTRAPPED');
  const many = Array.from({ length: 101 }, (_, i) => basic(`P${i}::1220ab`));
  await rejectsWithCode(assert, h.contextBuilder.build({ instrumentIds: [INSTRUMENT_ID], accounts: many }), 'VALIDATION_FAILED');
});

test('mint and burn accounts never produce account proofs', async () => {
  const h = createHarness();
  const v = values(await h.contextBuilder.build({
    instrumentIds: [INSTRUMENT_ID], accounts: [{ owner: null, provider: null, id: 'cip-112/mint' }, { owner: null, provider: null, id: 'cip-112/burn' }],
  }));
  assert.deepEqual(v[ContextKeys.accounts].value, {});
});
