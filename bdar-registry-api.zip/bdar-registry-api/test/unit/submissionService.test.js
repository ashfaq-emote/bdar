/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PARTIES, custodialRules, custodial, identifiers } from '../fakes/fixtures.js';
import { authFor, createHarness, rejectsWithCode } from '../fakes/harness.js';

const submitA = authFor([PARTIES.partyB], ['submit']);
const acceptOffer = (h) => ({
  ExerciseCommand: {
    templateId: identifiers.interfaces.transferInstructionV2,
    contractId: h.contracts.offerToB.createdEvent.contractId,
    choice: 'TransferInstruction_Accept',
    choiceArgument: { actors: [PARTIES.partyB], extraArgs: { context: { values: {} }, meta: { values: {} } } },
  },
});

test('prepare relays an allow listed choice for the key parties', async () => {
  const h = createHarness();
  const result = await h.submissions.prepare({ body: { actAs: [PARTIES.partyB], commands: [acceptOffer(h)], disclosedContracts: [] }, auth: submitA });
  assert.match(result.commandId, /^bdar-api-/);
  assert.ok(result.preparedTransactionHash);
  assert.deepEqual(h.ledger.prepared[0].actAs, [PARTIES.partyB]);
});

test('prepare refuses the admin party, other parties, unknown choices and foreign contracts', async () => {
  const h = createHarness();
  await rejectsWithCode(assert, h.submissions.prepare({ body: { actAs: [PARTIES.admin], commands: [acceptOffer(h)] }, auth: authFor(['*'], ['submit']) }), 'FORBIDDEN_PARTY');
  await rejectsWithCode(assert, h.submissions.prepare({ body: { actAs: [PARTIES.partyA], commands: [acceptOffer(h)] }, auth: submitA }), 'FORBIDDEN_PARTY');
  const archive = { ExerciseCommand: { ...acceptOffer(h).ExerciseCommand, choice: 'Archive' } };
  await rejectsWithCode(assert, h.submissions.prepare({ body: { actAs: [PARTIES.partyB], commands: [archive] }, auth: submitA }), 'TEMPLATE_NOT_ALLOWED');
  const freeze = { ExerciseCommand: { templateId: identifiers.templates.account, contractId: h.contracts.accountB.createdEvent.contractId, choice: 'BdarAccount_Freeze', choiceArgument: { reason: 'x' } } };
  await rejectsWithCode(assert, h.submissions.prepare({ body: { actAs: [PARTIES.partyB], commands: [freeze] }, auth: submitA }), 'TEMPLATE_NOT_ALLOWED');
  const foreign = { ExerciseCommand: { ...acceptOffer(h).ExerciseCommand, contractId: '00abcdef' } };
  await rejectsWithCode(assert, h.submissions.prepare({ body: { actAs: [PARTIES.partyB], commands: [foreign] }, auth: submitA }), 'CONTRACT_NOT_FOUND');
  const otherPackage = { ExerciseCommand: { ...acceptOffer(h).ExerciseCommand, templateId: '#evil-package:Splice.Api.Token.TransferInstructionV2:TransferInstruction' } };
  await rejectsWithCode(assert, h.submissions.prepare({ body: { actAs: [PARTIES.partyB], commands: [otherPackage] }, auth: submitA }), 'TEMPLATE_NOT_ALLOWED');
  assert.equal(h.ledger.prepared.length, 0, 'nothing reached the ledger');
});

test('prepare allows creating an account request only for this admin and signed by actAs', async () => {
  const h = createHarness();
  const request = (overrides = {}) => ({
    CreateCommand: {
      templateId: identifiers.templates.accountRequest,
      createArguments: {
        admin: PARTIES.admin, account: custodial(PARTIES.partyB, PARTIES.custodian, 'B-1'),
        change: { tag: 'BdarOpenAccount', value: { rules: custodialRules, purpose: 'BdarClientAccount', termsReference: 't' } },
        approvals: [PARTIES.partyB], reference: 'ONB-B-1', ...overrides,
      },
    },
  });
  await h.submissions.prepare({ body: { actAs: [PARTIES.partyB], commands: [request()] }, auth: submitA });
  await rejectsWithCode(assert, h.submissions.prepare({ body: { actAs: [PARTIES.partyB], commands: [request({ admin: PARTIES.stranger })] }, auth: submitA }), 'WRONG_ADMIN');
  await rejectsWithCode(assert, h.submissions.prepare({ body: { actAs: [PARTIES.partyB], commands: [request({ approvals: [PARTIES.partyB, PARTIES.custodian] })] }, auth: submitA }), 'FORBIDDEN_PARTY');
  const allowlist = { CreateCommand: { templateId: identifiers.templates.allowlistEntry, createArguments: { admin: PARTIES.admin } } };
  await rejectsWithCode(assert, h.submissions.prepare({ body: { actAs: [PARTIES.partyB], commands: [allowlist] }, auth: submitA }), 'TEMPLATE_NOT_ALLOWED');
});

test('execute derives the submission id from the idempotency key and checks signers', async () => {
  const h = createHarness();
  const body = {
    preparedTransaction: 'cHJlcGFyZWQ=', hashingSchemeVersion: 'HASHING_SCHEME_VERSION_V2',
    partySignatures: { signatures: [{ party: PARTIES.partyB, signatures: [{ format: 'SIGNATURE_FORMAT_RAW', signature: 'c2ln', signedBy: '1220dd', signingAlgorithmSpec: 'SIGNING_ALGORITHM_SPEC_ED25519' }] }] },
  };
  const first = await h.submissions.execute({ body, auth: submitA, idempotencyKey: 'accept-offer-0001' });
  const again = await h.submissions.execute({ body, auth: submitA, idempotencyKey: 'accept-offer-0001' });
  assert.equal(first.submissionId, again.submissionId);
  assert.equal(h.ledger.executed[0].submissionId, first.submissionId);
  const other = structuredClone(body);
  other.partySignatures.signatures[0].party = PARTIES.partyA;
  await rejectsWithCode(assert, h.submissions.execute({ body: other, auth: submitA, idempotencyKey: 'accept-offer-0002' }), 'FORBIDDEN_PARTY');
});

test('ledger failures during prepare are mapped', async () => {
  const h = createHarness();
  h.ledger.prepare = async () => { throw h.ledger.cantonError(400, 'DAML_FAILURE', 'broadridge.com/bdar/not-allowlisted'); };
  await assert.rejects(h.submissions.prepare({ body: { actAs: [PARTIES.partyB], commands: [acceptOffer(h)] }, auth: submitA }), (error) => {
    assert.equal(error.code, 'LEDGER_REJECTED');
    assert.equal(error.extra.ledgerError.errorId, 'broadridge.com/bdar/not-allowlisted');
    return true;
  });
});
