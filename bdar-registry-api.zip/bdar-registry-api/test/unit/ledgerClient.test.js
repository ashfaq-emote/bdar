/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { LedgerError, createLedgerClient, createTokenProvider, extractBdarErrorId, toApiError } from '../../src/ledger/ledgerClient.js';
import { startFakeJsonApi } from '../fakes/fakeJsonApiServer.js';
import { PARTIES, identifiers, standardLedgerContracts } from '../fakes/fixtures.js';

let api;
let client;
const contracts = standardLedgerContracts();

before(async () => {
  api = await startFakeJsonApi({ contracts: Object.values(contracts), token: 'secret-token' });
  client = createLedgerClient({
    baseUrl: api.baseUrl, userId: 'bdar-registry-api', timeoutMs: 1000, acsLimit: 1000,
    tokenProvider: { getToken: async () => 'secret-token' },
  });
});
after(() => api.close());

test('reads the ACS at ledger end with a template filter as the admin party', async () => {
  const result = await client.activeContracts({ parties: [PARTIES.admin], templateIds: [identifiers.templates.instrument] });
  assert.equal(result.offset, 42);
  assert.equal(result.contracts.length, Object.keys(contracts).length);
  const request = api.requests.findLast((r) => r.url.startsWith('/v2/state/active-contracts'));
  assert.equal(request.headers.authorization, 'Bearer secret-token');
  assert.match(request.url, /limit=1000/);
  assert.equal(request.body.activeAtOffset, 42);
  const filter = request.body.eventFormat.filtersByParty[PARTIES.admin].cumulative[0];
  assert.equal(filter.identifierFilter.TemplateFilter.value.templateId, '#broadridge-digital-asset-registry:Broadridge.DigitalAssetRegistry.Config:BdarInstrument');
  assert.equal(filter.identifierFilter.TemplateFilter.value.includeCreatedEventBlob, true);
});

test('an interface filter asks for the interface view', async () => {
  await client.activeContracts({ parties: [PARTIES.credentialIssuer], interfaceIds: [identifiers.interfaces.credential] });
  const request = api.requests.findLast((r) => r.url.startsWith('/v2/state/active-contracts'));
  const filter = request.body.eventFormat.filtersByParty[PARTIES.credentialIssuer].cumulative[0].identifierFilter.InterfaceFilter.value;
  assert.equal(filter.includeInterfaceView, true);
  assert.match(filter.interfaceId, /CredentialV1:BdarCredential$/);
});

test('a contract by id is returned when active and undefined when not found', async () => {
  const found = await client.activeContractById(contracts.instrument.createdEvent.contractId, [PARTIES.admin]);
  assert.equal(found.createdEvent.createArgument.instrumentId, '912828CN5');
  assert.equal(await client.activeContractById('00dead', [PARTIES.admin]), undefined);
});

test('commands are submitted with the configured user id and ledger effects shape', async () => {
  const commands = [{ ExerciseCommand: { templateId: identifiers.templates.instrument, contractId: '00ab', choice: 'BdarInstrument_Resume', choiceArgument: {} } }];
  const tx = await client.submitAndWaitForTransaction({ actAs: [PARTIES.admin], commandId: 'bdar-api-1', commands });
  assert.equal(tx.updateId, 'upd-1');
  const { body } = api.requests.findLast((r) => r.url === '/v2/commands/submit-and-wait-for-transaction');
  assert.equal(body.commands.userId, 'bdar-registry-api');
  assert.equal(body.commands.commandId, 'bdar-api-1');
  assert.deepEqual(body.commands.actAs, [PARTIES.admin]);
  assert.equal(body.transactionFormat.transactionShape, 'TRANSACTION_SHAPE_LEDGER_EFFECTS');
});

test('prepare and executeAndWait send the interactive submission bodies', async () => {
  await client.prepare({ actAs: [PARTIES.partyA], commandId: 'c-1', commands: [] });
  const prepare = api.requests.findLast((r) => r.url === '/v2/interactive-submission/prepare').body;
  assert.equal(prepare.userId, 'bdar-registry-api');
  assert.equal(prepare.verboseHashing, false);
  const result = await client.executeAndWait({ preparedTransaction: 'x', partySignatures: { signatures: [] }, submissionId: 's-1', hashingSchemeVersion: 'HASHING_SCHEME_VERSION_V2' });
  assert.equal(result.updateId, 'upd-2');
  const execute = api.requests.findLast((r) => r.url === '/v2/interactive-submission/executeAndWait').body;
  assert.deepEqual(execute.deduplicationPeriod, { Empty: {} });
});

test('Canton errors keep their code and map to API errors', async () => {
  api.behaviour.failWith = {
    status: 400,
    error: { code: 'DAML_FAILURE', cause: 'Interpretation error: UserError broadridge.com/bdar/account-frozen: account is frozen', correlationId: 'abc', context: {} },
  };
  const error = await client.version().catch((e) => e);
  assert.ok(error instanceof LedgerError);
  assert.equal(error.code, 'DAML_FAILURE');
  const mapped = toApiError(error);
  assert.equal(mapped.code, 'LEDGER_REJECTED');
  assert.equal(mapped.status, 409);
  assert.equal(mapped.extra.ledgerError.errorId, 'broadridge.com/bdar/account-frozen');
});

test('timeouts become 504 and refused connections 503', async () => {
  api.behaviour.delayMs = 1500;
  const slow = await client.version().catch((e) => e);
  api.behaviour.delayMs = 0;
  assert.equal(toApiError(slow).code, 'LEDGER_TIMEOUT');
  const down = createLedgerClient({ baseUrl: 'http://127.0.0.1:1', userId: 'u', timeoutMs: 1000, acsLimit: 1, tokenProvider: { getToken: async () => undefined } });
  assert.equal(toApiError(await down.version().catch((e) => e)).code, 'LEDGER_UNAVAILABLE');
});

test('error mapping table', () => {
  const canton = (httpStatus, code, cause = '') => new LedgerError({ httpStatus, cantonError: { code, cause } });
  assert.equal(toApiError(canton(404, 'CONTRACT_NOT_FOUND')).code, 'STALE_CONTRACT');
  assert.equal(toApiError(canton(409, 'DUPLICATE_COMMAND')).code, 'CONFLICT');
  assert.equal(toApiError(canton(400, 'DAML_FAILURE', 'broadridge.com/bdar/amount-precision')).status, 400);
  assert.equal(toApiError(canton(403, 'PERMISSION_DENIED')).code, 'LEDGER_ERROR');
  assert.equal(toApiError(canton(400, 'INVALID_ARGUMENT')).code, 'VALIDATION_FAILED');
  assert.equal(toApiError(canton(503, 'UNAVAILABLE')).code, 'LEDGER_UNAVAILABLE');
  assert.equal(toApiError(canton(500, 'INTERNAL')).code, 'LEDGER_ERROR');
  assert.equal(extractBdarErrorId({ cause: 'x', context: { detail: 'broadridge.com/bdar/not-allowlisted' } }), 'broadridge.com/bdar/not-allowlisted');
});

test('OAuth2 client credentials tokens are cached, refreshed early and shared by concurrent callers', async () => {
  let calls = 0;
  const clock = { t: 0 };
  const fetchImpl = async (url, options) => {
    calls += 1;
    assert.equal(options.body.get('grant_type'), 'client_credentials');
    return { ok: true, json: async () => ({ access_token: `token-${calls}`, expires_in: 300 }) };
  };
  const provider = createTokenProvider({ authMode: 'oauth2', oauth: { tokenUrl: 'https://idp/token', clientId: 'c', clientSecret: 's', audience: 'a' } }, { fetchImpl, now: () => clock.t });
  const [a, b] = await Promise.all([provider.getToken(), provider.getToken()]);
  assert.equal(a, 'token-1');
  assert.equal(b, 'token-1');
  assert.equal(calls, 1);
  clock.t = 239_000;
  assert.equal(await provider.getToken(), 'token-1');
  clock.t = 241_000;
  assert.equal(await provider.getToken(), 'token-2', 'refreshed 60 seconds before expiry');
  provider.invalidate();
  assert.equal(await provider.getToken(), 'token-3');
});
