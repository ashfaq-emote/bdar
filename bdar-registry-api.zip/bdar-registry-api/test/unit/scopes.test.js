/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  ANY_PARTY, canActFor, requireAllParties, requireAnyParty, requireAnyScope, requireGrantable, validateKeyScopes,
} from '../../src/security/scopes.js';
import { PARTIES } from '../fakes/fixtures.js';
import { authFor } from '../fakes/harness.js';

test('scope checks need at least one of the listed scopes', () => {
  const auth = authFor([PARTIES.partyA], ['wallet']);
  assert.doesNotThrow(() => requireAnyScope(auth, ['issuer', 'wallet']));
  assert.throws(() => requireAnyScope(auth, ['operator:write']), { code: 'FORBIDDEN_SCOPE' });
  assert.throws(() => requireAnyScope(undefined, ['wallet']), { code: 'FORBIDDEN_SCOPE' });
});

test('party binding: any of, all of, and the wildcard', () => {
  const auth = authFor([PARTIES.partyA]);
  assert.equal(canActFor(auth, PARTIES.partyA), true);
  assert.equal(canActFor(auth, PARTIES.partyB), false);
  assert.doesNotThrow(() => requireAnyParty(auth, [PARTIES.partyB, PARTIES.partyA]));
  assert.throws(() => requireAnyParty(auth, [PARTIES.partyB]), { code: 'FORBIDDEN_PARTY' });
  assert.throws(() => requireAnyParty(auth, [null, undefined]), { code: 'FORBIDDEN_PARTY' });
  assert.throws(() => requireAllParties(auth, [PARTIES.partyA, PARTIES.partyB]), { code: 'FORBIDDEN_PARTY' });
  const operator = authFor([ANY_PARTY], ['operator:read']);
  assert.doesNotThrow(() => requireAllParties(operator, [PARTIES.partyA, PARTIES.partyB]));
});

test('key scope validation', () => {
  assert.deepEqual(validateKeyScopes(['registry:read'], []), []);
  assert.equal(validateKeyScopes([], []).length, 1);
  assert.match(validateKeyScopes(['wallet'], [])[0], /allowed party/);
  assert.match(validateKeyScopes(['root'], [])[0], /unknown scope/);
});

test('a key manager can only grant what it holds', () => {
  const manager = authFor([PARTIES.partyA], ['keys:manage', 'wallet']);
  assert.doesNotThrow(() => requireGrantable(manager, { scopes: ['wallet'], allowedParties: [PARTIES.partyA] }));
  assert.throws(() => requireGrantable(manager, { scopes: ['operator:write'] }), { code: 'FORBIDDEN_SCOPE' });
  assert.throws(() => requireGrantable(manager, { scopes: ['wallet'], allowedParties: [PARTIES.partyB] }), { code: 'FORBIDDEN_SCOPE' });
  const superManager = authFor([ANY_PARTY], ['keys:manage', 'wallet']);
  assert.doesNotThrow(() => requireGrantable(superManager, { scopes: ['wallet'], allowedParties: [PARTIES.partyB] }));
});
