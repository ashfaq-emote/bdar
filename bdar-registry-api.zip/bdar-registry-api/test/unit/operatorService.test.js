/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { operatorCommandId, summarizeTransaction } from '../../src/services/operatorService.js';
import {
  INSTRUMENT_ID, PARTIES, activeContract, basic, custodial, custodialRules, identifiers, instrumentPayload, standardLedgerContracts,
} from '../fakes/fixtures.js';
import { authFor, createHarness, rejectsWithCode } from '../fakes/harness.js';

const ops = authFor(['*'], ['operator:write', 'operator:read'], 'opsk000000000001');
const cmd = (body = {}, idempotencyKey = 'ops-change-0001') => ({ body, auth: ops, idempotencyKey });
const lastCommand = (h) => h.ledger.submissions.at(-1).commands[0];

const newInstrument = {
  instrumentId: 'USDCX-T', name: 'Tokenized cash', symbol: 'USDCX', decimals: 6, standards: 'V2_ONLY', meta: {},
  issuers: [PARTIES.issuer], accountPolicy: 'IMPLICIT_BASIC',
  eligibility: { allowlist: null, credential: { enabled: true, trustedIssuers: [PARTIES.credentialIssuer], subject: 'OWNER_AND_PROVIDER', requirements: [{ registryAction: 'HOLD', credentialAction: 'hold' }] } },
  supply: { maxOutstandingSupply: '1000000000', maxMintPerRequest: null, mintApprovalRequired: true },
  redemptionPolicy: 'IMMEDIATE',
  settlement: { maxTransferTtlSeconds: 86400, maxAllocationTtlSeconds: 172800, allowCommittedAllocations: false, allowIteratedSettlement: false, allowMintAndBurnAllocations: true },
  controls: { clawbackEnabled: false },
};

test('command ids are stable for the same key, idempotency key and operation', () => {
  assert.equal(operatorCommandId('k1', 'idem', 'op'), operatorCommandId('k1', 'idem', 'op'));
  assert.notEqual(operatorCommandId('k1', 'idem', 'op'), operatorCommandId('k2', 'idem', 'op'));
  assert.match(operatorCommandId('k1', 'idem', 'op'), /^bdar-api-[0-9a-f]{48}$/);
});

test('bootstrap creates only the missing singletons and is safe to repeat', async () => {
  const contracts = standardLedgerContracts();
  delete contracts.settlementFactory;
  delete contracts.issuanceFactory;
  const h = createHarness({ contracts });
  const result = await h.operator.bootstrap(cmd());
  assert.equal(result.status, 201);
  assert.deepEqual(result.body.missingBefore, ['settlementFactory', 'issuanceFactory']);
  const commands = h.ledger.submissions[0].commands;
  assert.deepEqual(commands.map((c) => c.CreateCommand.templateId), [identifiers.templates.settlementFactory, identifiers.templates.issuanceFactory]);
  assert.deepEqual(h.ledger.submissions[0].actAs, [PARTIES.admin]);

  const full = createHarness();
  assert.deepEqual((await full.operator.bootstrap(cmd())).body, { alreadyBootstrapped: true, created: [] });
  assert.equal(full.ledger.submissions.length, 0);
});

test('create instrument maps API enums to Daml and checks the rules first', async () => {
  const h = createHarness();
  const result = await h.operator.createInstrument(cmd(newInstrument));
  assert.equal(result.status, 201);
  const exercise = lastCommand(h).ExerciseCommand;
  assert.equal(exercise.choice, 'BdarRegistryConfig_CreateInstrument');
  assert.equal(exercise.contractId, h.contracts.registryConfig.createdEvent.contractId);
  const instrument = exercise.choiceArgument.instrument;
  assert.equal(instrument.admin, PARTIES.admin);
  assert.equal(instrument.decimals, '6');
  assert.equal(instrument.standards, 'BdarSupportsV2Only');
  assert.equal(instrument.accountPolicy, 'BdarImplicitBasicAccounts');
  assert.equal(instrument.redemptionPolicy, 'BdarRedeemImmediately');
  assert.deepEqual(instrument.eligibilityPolicy.credential.requirements, [{ registryAction: 'BdarHold', credentialAction: 'hold' }]);
  assert.equal(instrument.eligibilityPolicy.credential.subject, 'BdarCredentialOwnerAndProvider');
  assert.deepEqual(instrument.settlementPolicy.maxTransferTtl, { microseconds: '86400000000' });
  assert.equal(instrument.status, 'BdarInstrumentActive');
  assert.equal(instrument.pause, null);

  await rejectsWithCode(assert, h.operator.createInstrument(cmd({ ...newInstrument, instrumentId: INSTRUMENT_ID })), 'INSTRUMENT_ALREADY_EXISTS');
  await rejectsWithCode(assert, h.operator.createInstrument(cmd({ ...newInstrument, controls: { clawbackEnabled: true } })), 'VALIDATION_FAILED');
});

test('pause, resume and retire check the current state', async () => {
  const h = createHarness();
  await h.operator.pauseInstrument({ instrumentId: INSTRUMENT_ID, ...cmd({ reason: 'Coupon processing', pausedUntil: null }) });
  assert.deepEqual(lastCommand(h).ExerciseCommand.choiceArgument, { pauseInfo: { reason: 'Coupon processing', pausedUntil: null } });
  await rejectsWithCode(assert, h.operator.resumeInstrument({ instrumentId: INSTRUMENT_ID, ...cmd() }), 'CONFLICT');

  const contracts = standardLedgerContracts();
  contracts.instrument = activeContract('instrument', instrumentPayload({ status: 'BdarInstrumentRetired' }));
  const retired = createHarness({ contracts });
  await rejectsWithCode(assert, retired.operator.retireInstrument({ instrumentId: INSTRUMENT_ID, ...cmd() }), 'CONFLICT');
  await rejectsWithCode(assert, retired.operator.pauseInstrument({ instrumentId: INSTRUMENT_ID, ...cmd({ reason: 'x' }) }), 'CONFLICT');
  await rejectsWithCode(assert, h.operator.pauseInstrument({ instrumentId: 'NOPE', ...cmd({ reason: 'x' }) }), 'INSTRUMENT_NOT_FOUND');
});

test('accepting an account request enforces completeness and one account per key', async () => {
  const contracts = standardLedgerContracts();
  const newAccount = custodial(PARTIES.partyB, PARTIES.custodian, 'B-0001');
  const open = (approvals, account = newAccount) => activeContract('accountRequest', {
    admin: PARTIES.admin, account, approvals, reference: 'ONB-B-0001',
    change: { tag: 'BdarOpenAccount', value: { rules: custodialRules, purpose: 'BdarClientAccount', termsReference: 'BitGo-Custody-Terms-v3' } },
  });
  contracts.partial = open([PARTIES.partyB]);
  contracts.complete = open([PARTIES.partyB, PARTIES.custodian]);
  contracts.duplicate = open([PARTIES.partyA, PARTIES.custodian], custodial(PARTIES.partyA, PARTIES.custodian, 'A-0001'));
  contracts.close = activeContract('accountRequest', { admin: PARTIES.admin, account: basic(PARTIES.partyB), approvals: [PARTIES.partyB], reference: 'CLOSE-B', change: { tag: 'BdarCloseAccount', value: {} } });
  const h = createHarness({ contracts });

  await rejectsWithCode(assert, h.operator.acceptAccountRequest({ contractId: contracts.partial.createdEvent.contractId, ...cmd() }), 'ACCOUNT_REQUEST_INCOMPLETE');
  await rejectsWithCode(assert, h.operator.acceptAccountRequest({ contractId: contracts.duplicate.createdEvent.contractId, ...cmd() }), 'ACCOUNT_ALREADY_EXISTS');
  await h.operator.acceptAccountRequest({ contractId: contracts.complete.createdEvent.contractId, ...cmd() });
  assert.deepEqual(lastCommand(h).ExerciseCommand.choiceArgument, { existingAccountCid: null });
  await h.operator.acceptAccountRequest({ contractId: contracts.close.createdEvent.contractId, ...cmd({}, 'close-b-0001') });
  assert.deepEqual(lastCommand(h).ExerciseCommand.choiceArgument, { existingAccountCid: contracts.accountB.createdEvent.contractId });
  await rejectsWithCode(assert, h.operator.acceptAccountRequest({ contractId: h.contracts.instrument.createdEvent.contractId, ...cmd() }), 'CONTRACT_NOT_FOUND');
});

test('freeze, unfreeze and clawback', async () => {
  const h = createHarness();
  const accountA = custodial(PARTIES.partyA, PARTIES.custodian, 'A-0001');
  await h.operator.freezeAccount(cmd({ account: accountA, reason: 'Sanctions screening hit' }));
  assert.equal(lastCommand(h).ExerciseCommand.choice, 'BdarAccount_Freeze');
  await rejectsWithCode(assert, h.operator.unfreezeAccount(cmd({ account: accountA })), 'CONFLICT');
  await rejectsWithCode(assert, h.operator.freezeAccount(cmd({ account: basic(PARTIES.stranger), reason: 'x' })), 'ACCOUNT_NOT_FOUND');

  const result = await h.operator.clawback(cmd({ account: accountA, instrumentId: INSTRUMENT_ID, outcome: 'BURN', reason: 'Court order 2026-117' }));
  const clawback = lastCommand(h).ExerciseCommand;
  assert.equal(clawback.choice, 'BdarAccount_Clawback');
  assert.deepEqual(clawback.choiceArgument.outcome, { tag: 'BdarBurnClawback', value: {} });
  assert.deepEqual(result.body.holdingCids.sort(), [h.contracts.holdingA1.createdEvent.contractId, h.contracts.holdingA2.createdEvent.contractId].sort(), 'locked holdings are not seized');
  assert.ok(clawback.choiceArgument.extraArgs.context.values['broadridge.com/bdar/supplies']);
  await rejectsWithCode(assert, h.operator.clawback(cmd({ account: accountA, instrumentId: INSTRUMENT_ID, outcome: 'REASSIGN', reason: 'x' })), 'VALIDATION_FAILED');
  await rejectsWithCode(assert, h.operator.clawback(cmd({ account: accountA, instrumentId: INSTRUMENT_ID, outcome: 'REASSIGN', recoveryAccount: basic(PARTIES.partyB), reason: 'x' })), 'VALIDATION_FAILED');
});

test('allowlist add refuses duplicates; revoke refuses unknown entries', async () => {
  const h = createHarness();
  await rejectsWithCode(assert, h.operator.addAllowlistEntry(cmd({ party: PARTIES.partyA, instrumentId: INSTRUMENT_ID, reference: 'KYC' })), 'ALLOWLIST_ENTRY_EXISTS');
  await h.operator.addAllowlistEntry(cmd({ party: PARTIES.custodian, instrumentId: INSTRUMENT_ID, validUntil: '2027-09-14T00:00:00Z', reference: 'KYC-BitGo' }));
  assert.deepEqual(lastCommand(h).CreateCommand.createArguments, { admin: PARTIES.admin, party: PARTIES.custodian, instrumentId: INSTRUMENT_ID, validUntil: '2027-09-14T00:00:00Z', reference: 'KYC-BitGo' });
  await rejectsWithCode(assert, h.operator.revokeAllowlistEntry(cmd({ party: PARTIES.stranger, instrumentId: INSTRUMENT_ID, reason: 'x' })), 'NOT_FOUND');
});

test('mint approval passes a full context including the issuer proofs', async () => {
  const contracts = standardLedgerContracts();
  contracts.mintRequest = activeContract('mintRequest', {
    admin: PARTIES.admin, issuer: PARTIES.issuer,
    details: { instrumentId: INSTRUMENT_ID, receiver: basic(PARTIES.partyB), amount: '100000000', reference: 'ISS-1', requestedAt: '2026-09-14T11:00:00Z', executeBefore: '2026-09-15T11:00:00Z' },
  });
  const h = createHarness({ contracts });
  await h.operator.approveMintRequest({ contractId: contracts.mintRequest.createdEvent.contractId, ...cmd() });
  const submission = h.ledger.submissions.at(-1);
  const values = submission.commands[0].ExerciseCommand.choiceArgument.extraArgs.context.values;
  assert.ok(values['broadridge.com/bdar/accounts'].value[`${PARTIES.partyB}||`]);
  assert.ok(submission.disclosedContracts.length > 0);
});

test('housekeeping expires only what is due and reports per contract', async () => {
  const contracts = standardLedgerContracts();
  contracts.oldPreapproval = activeContract('preapproval', { admin: PARTIES.admin, account: basic(PARTIES.partyB), instrumentIds: null, expiresAt: '2026-09-01T00:00:00Z' });
  contracts.livePreapproval = activeContract('preapproval', { admin: PARTIES.admin, account: basic(PARTIES.partyA), instrumentIds: null, expiresAt: '2027-01-01T00:00:00Z' });
  const h = createHarness({ contracts, now: () => new Date('2026-09-16T00:00:00Z') });

  const tiReport = await h.operator.expireTransferInstructions(cmd({ limit: 10 }));
  assert.equal(tiReport.body.candidates, 1);
  assert.equal(tiReport.body.succeeded[0].contractId, contracts.offerToB.createdEvent.contractId);
  assert.equal(lastCommand(h).ExerciseCommand.choice, 'BdarTransferInstruction_Expire');

  const preReport = await h.operator.expirePreapprovals(cmd({}, 'expire-pre-001'));
  assert.equal(preReport.body.candidates, 1);
  assert.equal(lastCommand(h).ExerciseCommand.contractId, contracts.oldPreapproval.createdEvent.contractId);

  h.ledger.submitAndWaitForTransaction = async () => { throw h.ledger.cantonError(400, 'DAML_FAILURE', 'broadridge.com/bdar/deadline-not-reached'); };
  const failed = await h.operator.expireTransferInstructions(cmd({}, 'expire-ti-0002'));
  assert.equal(failed.body.failed[0].code, 'LEDGER_REJECTED');
});

test('summarizeTransaction lists created and archived contracts and the root result', () => {
  const summary = summarizeTransaction({
    updateId: 'u1', offset: 7,
    events: [
      { ExercisedEvent: { contractId: '00a', templateId: 'pkg:M:T', consuming: true, exerciseResult: { tag: 'X', value: {} } } },
      { CreatedEvent: { contractId: '00b', templateId: 'pkg:M:T' } },
      { ExercisedEvent: { contractId: '00c', templateId: 'pkg:M:U', consuming: false, exerciseResult: 1 } },
    ],
  });
  assert.deepEqual(summary, { updateId: 'u1', offset: 7, created: [{ contractId: '00b', template: 'M:T' }], archived: [{ contractId: '00a', template: 'M:T' }], exerciseResult: { tag: 'X', value: {} } });
});
