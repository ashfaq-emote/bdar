/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { FallbackStore, MemoryStore, RedisStore, createRateLimiter } from '../../src/security/rateLimiter.js';
import { testConfig } from '../fakes/fixtures.js';

const clock = () => {
  const state = { t: 1_000_000 };
  return { state, now: () => state.t };
};

test('fixed window: the request after the limit is refused until the window resets', async () => {
  const c = clock();
  const limiter = createRateLimiter({ store: new MemoryStore({ now: c.now }), config: testConfig().rateLimit });
  for (let i = 1; i <= 20; i += 1) {
    const result = await limiter.consume('keys', 'key:a');
    assert.equal(result.limited, false);
    assert.equal(result.remaining, 20 - i);
  }
  const blocked = await limiter.consume('keys', 'key:a');
  assert.equal(blocked.limited, true);
  assert.equal(blocked.remaining, 0);
  assert.ok(blocked.resetSeconds >= 1 && blocked.resetSeconds <= 60);
  assert.equal((await limiter.consume('keys', 'key:b')).limited, false, 'subjects are counted separately');
  c.state.t += 60_001;
  assert.equal((await limiter.consume('keys', 'key:a')).limited, false, 'a new window starts after durationSeconds');
});

test('tiers multiply the points', async () => {
  const limiter = createRateLimiter({ store: new MemoryStore(), config: testConfig().rateLimit });
  assert.equal((await limiter.consume('keys', 'key:x', { tier: 'elevated' })).limit, 100);
  assert.equal((await limiter.consume('keys', 'key:y', { tier: 'internal' })).limit, 400);
  assert.equal((await limiter.consume('keys', 'key:z', { tier: 'unknown' })).limit, 20, 'unknown tiers use standard');
});

test('block period: repeated auth failures block the IP for blockSeconds', async () => {
  const c = clock();
  const limiter = createRateLimiter({ store: new MemoryStore({ now: c.now }), config: testConfig().rateLimit });
  for (let i = 0; i < 3; i += 1) await limiter.consume('authFailure', 'ip:1.2.3.4');
  assert.equal(await limiter.isBlocked('authFailure', 'ip:1.2.3.4'), false);
  const fourth = await limiter.consume('authFailure', 'ip:1.2.3.4');
  assert.equal(fourth.limited, true);
  assert.equal(await limiter.isBlocked('authFailure', 'ip:1.2.3.4'), true);
  c.state.t += 899_000;
  assert.equal(await limiter.isBlocked('authFailure', 'ip:1.2.3.4'), true);
  c.state.t += 2_000;
  assert.equal(await limiter.isBlocked('authFailure', 'ip:1.2.3.4'), false);
});

test('limits can be switched off globally or per policy', async () => {
  const off = testConfig().rateLimit;
  const globalOff = createRateLimiter({ store: new MemoryStore(), config: { ...off, enabled: false } });
  assert.equal(await globalOff.consume('keys', 'key:a'), undefined);
  assert.equal(globalOff.policy('keys'), undefined);
  const policyOff = createRateLimiter({
    store: new MemoryStore(),
    config: { ...off, policies: { ...off.policies, keys: { ...off.policies.keys, enabled: false } } },
  });
  assert.equal(await policyOff.consume('keys', 'key:a'), undefined);
  assert.notEqual(await policyOff.consume('context', 'key:a'), undefined);
});

test('RedisStore sends one atomic script call with the documented keys and arguments', async () => {
  const calls = [];
  const redis = {
    async eval(...args) { calls.push(args); return [3, 59000]; },
    async pttl() { return 5000; },
    async del() { return 1; },
  };
  const store = new RedisStore({ redis, keyPrefix: 'bdar:rl:' });
  const result = await store.consume('context:key:a', { windowMs: 60000, limit: 300, blockMs: 0, cost: 1 });
  assert.deepEqual(result, { count: 3, msBeforeReset: 59000 });
  const [script, numKeys, counterKey, blockKey, ...argv] = calls[0];
  assert.match(script, /INCRBY/);
  assert.equal(numKeys, 2);
  assert.equal(counterKey, 'bdar:rl:context:key:a');
  assert.equal(blockKey, 'bdar:rl:context:key:a:block');
  assert.deepEqual(argv, [60000, 300, 0, 1]);
  assert.equal(await store.isBlocked('authFailure:ip:1'), true);
});

test('FallbackStore switches to memory when Redis fails and back after the cool down', async () => {
  const c = clock();
  let redisUp = false;
  const primary = {
    kind: 'redis',
    async consume() { if (!redisUp) throw new Error('ECONNREFUSED'); return { count: 1, msBeforeReset: 1000 }; },
    async isBlocked() { if (!redisUp) throw new Error('ECONNREFUSED'); return false; },
  };
  const warnings = [];
  const store = new FallbackStore({ primary, fallback: new MemoryStore({ now: c.now }), coolDownMs: 10000, now: c.now, logger: { warn: (...a) => warnings.push(a) } });
  const first = await store.consume('k', { windowMs: 60000, limit: 5, blockMs: 0 });
  assert.equal(first.count, 1, 'the request is still counted, in memory');
  assert.equal(store.kind, 'memory-fallback');
  assert.equal(warnings.length, 1);
  redisUp = true;
  await store.consume('k', { windowMs: 60000, limit: 5, blockMs: 0 });
  assert.equal(store.kind, 'memory-fallback', 'stays on memory during the cool down');
  c.state.t += 10001;
  assert.equal(store.kind, 'redis');
  assert.equal((await store.consume('k', { windowMs: 60000, limit: 5, blockMs: 0 })).count, 1);
});
