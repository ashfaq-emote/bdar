/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  accountChangeToApi, accountChangeToDaml, accountRulesProblems, balancesOf, decimalUnits, instrumentProblems, instrumentToApi,
  instrumentToDaml, unitsToDecimal,
} from '../../src/registry/mappers.js';
import { PARTIES, activeContract, custodialRules, instrumentPayload, openRules } from '../fakes/fixtures.js';

test('decimal arithmetic is exact to 10 places', () => {
  assert.equal(unitsToDecimal(decimalUnits('0.1') + decimalUnits('0.2')), '0.3');
  assert.equal(unitsToDecimal(decimalUnits('99999999999999999999999999.9999999999') + decimalUnits('0.0000000001')), '100000000000000000000000000');
  assert.equal(unitsToDecimal(decimalUnits('10') - decimalUnits('10.5')), '-0.5');
  assert.equal(unitsToDecimal(decimalUnits('1000.0000000000')), '1000');
});

test('instrument API view and Daml payload round trip', () => {
  const contract = { contractId: '00aa', createdAt: '2026-09-14T09:00:00Z', payload: instrumentPayload() };
  const api = instrumentToApi(contract);
  const back = instrumentToDaml(api, PARTIES.admin);
  const original = instrumentPayload();
  for (const field of ['instrumentId', 'name', 'symbol', 'issuers', 'standards', 'accountPolicy', 'redemptionPolicy', 'controlPolicy', 'status']) {
    assert.deepEqual(back[field], original[field], field);
  }
  assert.equal(back.decimals, '2');
  assert.deepEqual(back.eligibilityPolicy, original.eligibilityPolicy);
  assert.deepEqual(back.settlementPolicy, original.settlementPolicy);
  assert.equal(back.supplyPolicy.maxOutstandingSupply, '500000000');
});

test('unknown enum values are a 400, not a crash', () => {
  const contract = { contractId: '00aa', payload: instrumentPayload() };
  const api = instrumentToApi(contract);
  assert.throws(() => instrumentToDaml({ ...api, redemptionPolicy: 'SOMETIMES' }, PARTIES.admin), { code: 'VALIDATION_FAILED' });
});

test('instrument rules mirror isValidInstrument', () => {
  const api = instrumentToApi({ contractId: '00aa', payload: instrumentPayload() });
  assert.deepEqual(instrumentProblems(api), []);
  const problems = instrumentProblems({
    ...api, decimals: 11, issuers: [PARTIES.issuer, PARTIES.issuer], accountPolicy: 'IMPLICIT_BASIC',
    supply: { maxOutstandingSupply: '0', maxMintPerRequest: null, mintApprovalRequired: false },
    settlement: { ...api.settlement, maxTransferTtlSeconds: 0 },
    eligibility: { allowlist: { appliesTo: [] }, credential: { enabled: true, trustedIssuers: [], subject: 'OWNER', requirements: [] } },
  }).map((p) => p.field);
  assert.deepEqual(problems.sort(), [
    'controls.clawbackEnabled', 'decimals', 'eligibility.allowlist.appliesTo', 'eligibility.credential', 'issuers',
    'settlement.maxTransferTtlSeconds', 'supply.maxOutstandingSupply',
  ].sort());
});

test('account rules mirror isValidAccountRules', () => {
  assert.deepEqual(accountRulesProblems({ owner: PARTIES.partyA, provider: null, id: '' }, openRules), []);
  assert.deepEqual(accountRulesProblems({ owner: PARTIES.partyA, provider: PARTIES.custodian, id: 'x' }, custodialRules), []);
  assert.equal(accountRulesProblems({ owner: PARTIES.partyA, provider: null, id: '' }, custodialRules).length, 2, 'provider rules without a provider, and then no approver');
  assert.equal(accountRulesProblems({ owner: PARTIES.partyA, provider: PARTIES.partyA, id: '' }, custodialRules).length, 1);
  assert.equal(accountRulesProblems({ owner: PARTIES.partyA, provider: null, id: '' }, { owner: { canInitiate: false, mustApprove: false }, provider: null }).length, 2);
});

test('account change variants round trip', () => {
  for (const change of [
    { type: 'OPEN', rules: custodialRules, purpose: 'RECOVERY', termsReference: 'T' },
    { type: 'CHANGE_RULES', newRules: openRules },
    { type: 'SET_PREAPPROVAL', instrumentIds: ['912828CN5'], expiresAt: '2027-01-01T00:00:00Z' },
    { type: 'CLOSE' },
  ]) {
    assert.deepEqual(accountChangeToApi(accountChangeToDaml(change)), change);
  }
});

test('expired locks count as available', () => {
  const holding = (amount, lock) => activeContract('holding', { admin: PARTIES.admin, account: { owner: PARTIES.partyA, provider: null, id: '' }, instrumentId: 'X', amount, lock, meta: { values: {} } });
  const rows = balancesOf([
    holding('5.5', null),
    holding('1.25', { holders: [], expiresAt: '2026-01-01T00:00:00Z', expiresAfter: null, context: null }),
    holding('2', { holders: [], expiresAt: null, expiresAfter: null, context: null }),
  ].map((entry) => ({ contractId: entry.createdEvent.contractId, payload: entry.createdEvent.createArgument })), new Date('2026-09-14T00:00:00Z'));
  assert.deepEqual({ total: rows[0].total, locked: rows[0].locked, available: rows[0].available }, { total: '8.75', locked: '2', available: '6.75' });
});
