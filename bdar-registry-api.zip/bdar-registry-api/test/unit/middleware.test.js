/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  authenticate, rateLimit, requestId, requireIdempotencyKey, requireJsonBody, requireScopes,
} from '../../src/security/middleware.js';
import { createApiKeyService } from '../../src/services/apiKeyService.js';
import { createMemoryApiKeyRepository, createMemoryAuditRepository } from '../../src/repositories/memory.js';
import { createAuditService } from '../../src/services/supportServices.js';
import { MemoryStore, createRateLimiter } from '../../src/security/rateLimiter.js';
import { PARTIES, testConfig } from '../fakes/fixtures.js';

function mockReq({ headers = {}, url = '/registry/metadata/v1/info', method = 'GET', ip = '203.0.113.7', auth } = {}) {
  return { headers, originalUrl: url, url, path: url.split('?')[0], method, ip, auth, id: 'req-00000001' };
}
function mockRes() {
  return { headers: {}, setHeader(name, value) { this.headers[name.toLowerCase()] = value; } };
}
/** Run a middleware and resolve with the error passed to next (or undefined). */
const run = (middleware, req, res = mockRes()) => new Promise((resolve) => {
  middleware(req, res, (error) => resolve({ error, req, res }));
});

async function setup() {
  const config = testConfig();
  const auditRepository = createMemoryAuditRepository();
  const audit = createAuditService({ repository: auditRepository });
  const apiKeyService = createApiKeyService({ repository: createMemoryApiKeyRepository(), config, audit });
  const rateLimiter = createRateLimiter({ store: new MemoryStore(), config: config.rateLimit });
  const { apiKey } = await apiKeyService.create({ clientName: 'wallet', scopes: ['wallet'], allowedParties: [PARTIES.partyA] }, 'test');
  return { apiKey, apiKeyService, rateLimiter, audit, auditRepository, auth: authenticate({ apiKeyService, rateLimiter, audit }) };
}

test('requestId keeps a well formed caller id and replaces anything else', async () => {
  const kept = await run(requestId(), mockReq({ headers: { 'x-request-id': 'trace-1234abcd' } }));
  assert.equal(kept.req.id, 'trace-1234abcd');
  assert.equal(kept.res.headers['x-request-id'], 'trace-1234abcd');
  const replaced = await run(requestId(), mockReq({ headers: { 'x-request-id': 'bad id\nwith newline' } }));
  assert.match(replaced.req.id, /^[0-9a-f-]{36}$/);
});

test('a valid key authenticates and sets req.auth', async () => {
  const { apiKey, auth } = await setup();
  const { error, req } = await run(auth, mockReq({ headers: { 'x-api-key': apiKey } }));
  assert.equal(error, undefined);
  assert.equal(req.auth.clientName, 'wallet');
});

test('a missing key is 401 with WWW-Authenticate', async () => {
  const { auth } = await setup();
  const { error } = await run(auth, mockReq());
  assert.equal(error.code, 'AUTH_MISSING_API_KEY');
  assert.equal(error.status, 401);
  assert.match(error.headers['WWW-Authenticate'], /X-API-Key/);
});

test('a key in the query string is refused even if it is valid', async () => {
  const { apiKey, auth } = await setup();
  const { error } = await run(auth, mockReq({ url: `/registry/metadata/v1/info?api_key=${apiKey}`, headers: { 'x-api-key': apiKey } }));
  assert.equal(error.code, 'VALIDATION_FAILED');
});

test('invalid keys are audited, counted per IP, and the IP is blocked after the limit', async () => {
  const { auth, auditRepository } = await setup();
  const bad = { 'x-api-key': 'bdar_test_aaaaaaaaaaaaaaaa_' + '0'.repeat(64) + '_00000000' };
  for (let i = 0; i < 4; i += 1) {
    const { error } = await run(auth, mockReq({ headers: bad }));
    assert.equal(error.code, 'AUTH_INVALID_API_KEY');
  }
  const blocked = await run(auth, mockReq({ headers: bad }));
  assert.equal(blocked.error.code, 'RATE_LIMITED');
  assert.equal(blocked.error.headers['Retry-After'], '900');
  const other = await run(auth, mockReq({ headers: bad, ip: '198.51.100.1' }));
  assert.equal(other.error.code, 'AUTH_INVALID_API_KEY', 'another IP is not blocked');
  assert.equal(auditRepository.events.filter((e) => e.action === 'auth.failure').length, 5);
  assert.equal(auditRepository.events.find((e) => e.action === 'auth.failure').details.reason, 'malformed');
});

test('rateLimit sets the RateLimit headers and refuses with Retry-After', async () => {
  const { rateLimiter } = await setup();
  const limiter = rateLimit({ rateLimiter, policy: 'keys' });
  const auth = { keyId: 'k1', rateLimitTier: 'standard' };
  let last;
  for (let i = 0; i < 21; i += 1) last = await run(limiter, mockReq({ auth }));
  assert.equal(last.error.code, 'RATE_LIMITED');
  assert.ok(Number(last.error.headers['Retry-After']) >= 1);
  assert.equal(last.res.headers['ratelimit-limit'], '20');
  assert.equal(last.res.headers['ratelimit-remaining'], '0');
  assert.match(last.res.headers['ratelimit-policy'], /name="keys"/);
});

test('rateLimit keys by IP for unauthenticated calls and does nothing when the policy is off', async () => {
  const config = testConfig();
  const rateLimiter = createRateLimiter({ store: new MemoryStore(), config: { ...config.rateLimit, enabled: false } });
  const { error, res } = await run(rateLimit({ rateLimiter, policy: 'public' }), mockReq());
  assert.equal(error, undefined);
  assert.equal(res.headers['ratelimit-limit'], undefined);
});

test('requireScopes, requireJsonBody and requireIdempotencyKey', async () => {
  const auth = { scopes: ['wallet'] };
  assert.equal((await run(requireScopes(['wallet', 'issuer']), mockReq({ auth }))).error, undefined);
  assert.equal((await run(requireScopes(['operator:write']), mockReq({ auth }))).error.code, 'FORBIDDEN_SCOPE');

  const textBody = mockReq({ method: 'POST', headers: { 'content-length': '5', 'content-type': 'text/plain' } });
  assert.equal((await run(requireJsonBody(), textBody)).error.code, 'UNSUPPORTED_MEDIA_TYPE');
  const chunked = mockReq({ method: 'POST', headers: { 'transfer-encoding': 'chunked', 'content-type': 'application/x-www-form-urlencoded' } });
  assert.equal((await run(requireJsonBody(), chunked)).error.code, 'UNSUPPORTED_MEDIA_TYPE');
  const jsonBody = mockReq({ method: 'POST', headers: { 'content-length': '2', 'content-type': 'application/json; charset=utf-8' } });
  assert.equal((await run(requireJsonBody(), jsonBody)).error, undefined);

  assert.equal((await run(requireIdempotencyKey(), mockReq({ method: 'POST' }))).error.code, 'IDEMPOTENCY_KEY_REQUIRED');
  assert.equal((await run(requireIdempotencyKey(), mockReq({ method: 'POST', headers: { 'idempotency-key': 'short' } }))).error.code, 'VALIDATION_FAILED');
  const good = await run(requireIdempotencyKey(), mockReq({ method: 'POST', headers: { 'idempotency-key': 'freeze-2026-09-15-0001' } }));
  assert.equal(good.error, undefined);
  assert.equal(good.req.idempotencyKey, 'freeze-2026-09-15-0001');
});
