/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createHealthService } from '../../src/services/healthService.js';
import { createMemoryApiKeyRepository } from '../../src/repositories/memory.js';
import { testConfig } from '../fakes/fixtures.js';
import { createHarness } from '../fakes/harness.js';

function build({ database = createMemoryApiKeyRepository(), store = { kind: 'redis' } } = {}) {
  const h = createHarness();
  const health = createHealthService({ ledger: h.ledger, apiKeyRepository: database, rateLimitStore: store, reader: h.reader, config: testConfig(), version: '1.0.0' });
  return { h, health };
}

test('ping and liveness never touch dependencies', () => {
  const { health } = build();
  assert.equal(health.ping().status, 'ok');
  assert.deepEqual(health.live(), { status: 'ok' });
});

test('readiness is up/down per dependency with no internals', async () => {
  const { health } = build();
  const result = await health.ready();
  assert.equal(result.ready, true);
  assert.deepEqual(result.body, { status: 'ready', checks: { ledger: 'up', database: 'up', rateLimitStore: 'up', registry: 'up' } });
});

test('readiness fails when the database is down, but a degraded rate limit store does not fail it', async () => {
  const down = build({ database: { kind: 'postgres', ping: async () => { throw new Error('connection refused to 10.1.2.3'); } }, store: { kind: 'memory-fallback' } });
  const result = await down.health.ready();
  assert.equal(result.ready, false);
  assert.equal(result.body.checks.database, 'down');
  assert.equal(result.body.checks.rateLimitStore, 'degraded');
  assert.ok(!JSON.stringify(result.body).includes('10.1.2.3'), 'no internal detail leaks from readiness');
});

test('shutting down makes readiness fail at once', async () => {
  const { health } = build();
  health.markShuttingDown();
  assert.deepEqual(await health.ready(), { ready: false, body: { status: 'shutting-down' } });
});

test('detailed health reports latency, versions and settings', async () => {
  const { health } = build();
  const detail = await health.detailed();
  assert.equal(detail.status, 'up');
  assert.equal(detail.version, '1.0.0');
  assert.equal(detail.checks.find((c) => c.name === 'ledger').detail.version, '3.4.0-fake');
  assert.equal(detail.settings.rateLimitEnabled, true);
  assert.ok(!JSON.stringify(detail).includes('pepper'));
});
