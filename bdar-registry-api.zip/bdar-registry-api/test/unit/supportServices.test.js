/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createAuditService, createIdempotencyService } from '../../src/services/supportServices.js';
import { createMemoryAuditRepository, createMemoryIdempotencyRepository } from '../../src/repositories/memory.js';

test('idempotency: the first call runs, a retry replays, a different body is refused', async () => {
  const service = createIdempotencyService({ repository: createMemoryIdempotencyRepository() });
  let runs = 0;
  const work = async () => { runs += 1; return { status: 201, body: { n: runs } }; };
  const scope = { apiKeyId: 'k1', idempotencyKey: 'create-ust-0001', request: { a: 1, b: [1, 2] } };

  const first = await service.run(scope, work);
  assert.deepEqual(first, { status: 201, body: { n: 1 }, replayed: false });
  const retry = await service.run({ ...scope, request: { b: [1, 2], a: 1 } }, work);
  assert.deepEqual(retry, { status: 201, body: { n: 1 }, replayed: true }, 'key order does not matter');
  assert.equal(runs, 1);
  await assert.rejects(service.run({ ...scope, request: { a: 2 } }, work), { code: 'IDEMPOTENCY_KEY_REUSED' });
  const otherKey = await service.run({ ...scope, apiKeyId: 'k2' }, work);
  assert.equal(otherKey.replayed, false, 'keys are scoped to the API key');
});

test('idempotency: a concurrent retry is refused and a failed call can be retried', async () => {
  const service = createIdempotencyService({ repository: createMemoryIdempotencyRepository() });
  const scope = { apiKeyId: 'k1', idempotencyKey: 'slow-0000001', request: {} };
  let release;
  const slow = service.run(scope, () => new Promise((resolve) => { release = () => resolve({ status: 200, body: {} }); }));
  await new Promise((resolve) => setImmediate(resolve));
  await assert.rejects(service.run(scope, async () => ({ status: 200, body: {} })), { code: 'IDEMPOTENCY_IN_PROGRESS' });
  release();
  await slow;

  const failing = { apiKeyId: 'k1', idempotencyKey: 'fail-0000001', request: {} };
  await assert.rejects(service.run(failing, async () => { throw new Error('ledger down'); }), /ledger down/);
  const retried = await service.run(failing, async () => ({ status: 200, body: { ok: true } }));
  assert.equal(retried.replayed, false);
});

test('idempotency records expire', async () => {
  const clock = { now: new Date('2026-09-14T00:00:00Z') };
  const repository = createMemoryIdempotencyRepository({ now: () => clock.now });
  const service = createIdempotencyService({ repository, ttlHours: 1, now: () => clock.now });
  const scope = { apiKeyId: 'k1', idempotencyKey: 'expire-00001', request: {} };
  let runs = 0;
  const work = async () => ({ status: 200, body: { runs: (runs += 1) } });
  await service.run(scope, work);
  clock.now = new Date('2026-09-14T01:00:01Z');
  assert.equal((await service.run(scope, work)).replayed, false);
  assert.equal(runs, 2);
});

test('audit scrubs secrets at any depth and never throws', async () => {
  const repository = createMemoryAuditRepository();
  const errors = [];
  const audit = createAuditService({ repository, logger: { error: (...args) => errors.push(args) } });
  await audit.record({
    action: 'submission.execute', outcome: 'success',
    details: { body: { preparedTransaction: 'AAAA', partySignatures: { signatures: [] }, nested: { apiKey: 'bdar_live_x', token: 't', keep: 'yes' } } },
  });
  const [event] = repository.events;
  assert.equal(event.details.body.preparedTransaction, '[redacted]');
  assert.equal(event.details.body.partySignatures, '[redacted]');
  assert.equal(event.details.body.nested.apiKey, '[redacted]');
  assert.equal(event.details.body.nested.token, '[redacted]');
  assert.equal(event.details.body.nested.keep, 'yes');

  const broken = createAuditService({ repository: { insert: async () => { throw new Error('db down'); } }, logger: { error: (...args) => errors.push(args) } });
  await broken.record({ action: 'x', outcome: 'success' });
  assert.equal(errors.length, 1);
});
