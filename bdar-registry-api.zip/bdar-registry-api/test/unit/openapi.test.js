/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { buildRoutes } from '../../src/http/routes.js';
import { buildOpenApiDocument } from '../../src/openapi/generate.js';
import { ALL_SCOPES } from '../../src/security/scopes.js';

const routes = buildRoutes();
const document = buildOpenApiDocument({ routes, version: '1.0.0' });
const policies = JSON.parse(readFileSync(new URL('../../config/rate-limits.json', import.meta.url), 'utf8')).policies;

test('every route has a unique operation id, a summary, a tag and responses', () => {
  const ids = routes.map((r) => r.operationId);
  assert.equal(new Set(ids).size, ids.length);
  for (const route of routes) {
    assert.ok(route.summary, route.operationId);
    assert.ok(route.tag, route.operationId);
    assert.ok(Object.keys(route.responses).length > 0, route.operationId);
    assert.equal(typeof route.handler, 'function', route.operationId);
  }
});

test('every route names an existing rate limit policy; every authenticated route states its scopes', () => {
  for (const route of routes) {
    assert.ok(policies[route.rateLimit], `${route.operationId} uses unknown policy ${route.rateLimit}`);
    if (route.auth === 'apiKey') {
      assert.ok(Array.isArray(route.scopes), route.operationId);
      for (const scope of route.scopes) assert.ok(ALL_SCOPES.includes(scope), `${route.operationId}: ${scope}`);
    } else {
      assert.ok(['ping', 'getLiveness', 'getReadiness'].includes(route.operationId), `${route.operationId} must not be public`);
    }
  }
});

test('state changing operator and key routes are idempotent and audited', () => {
  for (const route of routes.filter((r) => r.path.includes('/admin/') && r.method !== 'get')) {
    assert.ok(route.audit, `${route.operationId} is audited`);
    if (route.path.startsWith('/registry/bdar/v1/admin/')) assert.equal(route.idempotent, true, `${route.operationId} is idempotent`);
  }
});

test('the token standard paths are exactly the standard ones', () => {
  const standard = [
    'get /registry/metadata/v1/info', 'get /registry/metadata/v1/instruments', 'get /registry/metadata/v1/instruments/{instrumentId}',
    'post /registry/transfer-instruction/v1/transfer-factory', 'post /registry/transfer-instruction/v2/transfer-factory',
    ...['v1', 'v2'].flatMap((v) => ['accept', 'reject', 'withdraw'].map((a) => `post /registry/transfer-instruction/${v}/{transferInstructionId}/choice-contexts/${a}`)),
    'post /registry/allocation-instruction/v1/allocation-factory', 'post /registry/allocation-instruction/v2/allocation-factory',
    'post /registry/allocation-instruction/v2/{allocationInstructionId}/choice-contexts/accept',
    'post /registry/allocation-instruction/v2/{allocationInstructionId}/choice-contexts/withdraw',
    'post /registry/allocations/v1/{allocationId}/choice-contexts/execute-transfer', 'post /registry/allocations/v1/{allocationId}/choice-contexts/withdraw',
    'post /registry/allocations/v1/{allocationId}/choice-contexts/cancel', 'post /registry/allocation/v2/settlement-factory',
    'post /registry/allocations/v2/{allocationId}/choice-contexts/withdraw', 'post /registry/allocations/v2/{allocationId}/choice-contexts/cancel',
  ];
  const present = new Set(routes.map((r) => `${r.method} ${r.path}`));
  for (const operation of standard) assert.ok(present.has(operation), operation);
});

test('ping and health endpoints exist without authentication', () => {
  const publicOps = routes.filter((r) => r.auth === 'none').map((r) => `${r.method} ${r.path}`);
  assert.deepEqual(publicOps.sort(), ['get /health/live', 'get /health/ready', 'get /ping'].sort());
});

test('the document is OpenAPI 3.0.3 with an API key security scheme and resolvable references', () => {
  assert.equal(document.openapi, '3.0.3');
  assert.deepEqual(document.components.securitySchemes.ApiKeyAuth, {
    type: 'apiKey', in: 'header', name: 'X-API-Key', description: document.components.securitySchemes.ApiKeyAuth.description,
  });
  const text = JSON.stringify(document);
  for (const [, kind, name] of text.matchAll(/"#\/components\/(schemas|responses)\/([A-Za-z0-9]+)"/g)) {
    assert.ok(document.components[kind][name], `${kind}/${name} exists`);
  }
  for (const [path, item] of Object.entries(document.paths)) {
    for (const [method, operation] of Object.entries(item)) {
      const names = [...path.matchAll(/\{([^}]+)\}/g)].map((m) => m[1]).sort();
      const declared = (operation.parameters ?? []).filter((p) => p.in === 'path').map((p) => p.name).sort();
      assert.deepEqual(declared, names, `${method} ${path}`);
    }
  }
  assert.ok(!text.includes(String.fromCharCode(0x2014)), 'house style: no em dash');
});

test('the committed OpenAPI files match the route table', () => {
  const committed = JSON.parse(readFileSync(new URL('../../openapi/bdar-registry-api.json', import.meta.url), 'utf8'));
  const { version } = JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8'));
  const fresh = JSON.parse(JSON.stringify(buildOpenApiDocument({ routes, version, rateLimitPolicies: policies })));
  assert.deepEqual(committed, fresh, 'run npm run openapi');
});
