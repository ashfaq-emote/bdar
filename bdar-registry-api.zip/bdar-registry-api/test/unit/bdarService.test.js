/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { INSTRUMENT_ID, PARTIES, activeContract, basic, custodial, custodialRules, instrumentPayload, standardLedgerContracts } from '../fakes/fixtures.js';
import { authFor, createHarness, rejectsWithCode } from '../fakes/harness.js';

const accountA = custodial(PARTIES.partyA, PARTIES.custodian, 'A-0001');
const walletA = authFor([PARTIES.partyA]);
const issuerKey = authFor([PARTIES.issuer], ['issuer']);

const mintBody = (receiver = accountA) => ({
  choiceArguments: {
    issuer: PARTIES.issuer,
    details: { instrumentId: INSTRUMENT_ID, receiver, amount: '100000000', reference: 'ISS-2026-0914-001', requestedAt: '2026-09-14T11:59:00Z', executeBefore: '2026-09-15T12:00:00Z' },
  },
});

test('issuance factory: context for the issuer with the expected outcome', async () => {
  const h = createHarness();
  const result = await h.bdar.getIssuanceFactory({ body: mintBody(), auth: issuerKey });
  assert.equal(result.factoryId, h.contracts.issuanceFactory.createdEvent.contractId);
  assert.equal(result.mintOutcome, 'OFFER');
  assert.match(result.factoryTemplateId, /Issuance:BdarIssuanceFactory$/);

  const contracts = standardLedgerContracts();
  contracts.instrument = activeContract('instrument', instrumentPayload({ supplyPolicy: { maxOutstandingSupply: null, maxMintPerRequest: null, mintApprovalRequired: true } }));
  assert.equal((await createHarness({ contracts }).bdar.getIssuanceFactory({ body: mintBody(), auth: issuerKey })).mintOutcome, 'AWAITING_APPROVAL');

  const preapproved = standardLedgerContracts();
  preapproved.pre = activeContract('preapproval', { admin: PARTIES.admin, account: accountA, instrumentIds: [INSTRUMENT_ID], expiresAt: null });
  assert.equal((await createHarness({ contracts: preapproved }).bdar.getIssuanceFactory({ body: mintBody(), auth: issuerKey })).mintOutcome, 'DIRECT');
});

test('issuance factory refuses non issuers and keys for other parties', async () => {
  const h = createHarness();
  const body = mintBody();
  body.choiceArguments.issuer = PARTIES.partyA;
  await rejectsWithCode(assert, h.bdar.getIssuanceFactory({ body, auth: authFor([PARTIES.partyA], ['issuer']) }), 'NOT_ISSUER');
  await rejectsWithCode(assert, h.bdar.getIssuanceFactory({ body: mintBody(), auth: walletA }), 'FORBIDDEN_PARTY');
  await rejectsWithCode(assert, h.bdar.getIssuanceFactory({ body: mintBody({ owner: null, provider: null, id: 'cip-112/burn' }), auth: issuerKey }), 'VALIDATION_FAILED');
});

test('instrument policy view uses API enums and seconds', async () => {
  const h = createHarness();
  const instrument = await h.bdar.getInstrument(INSTRUMENT_ID);
  assert.equal(instrument.standards, 'V1_AND_V2');
  assert.equal(instrument.accountPolicy, 'EXPLICIT');
  assert.deepEqual(instrument.eligibility.allowlist, { appliesTo: ['HOLD', 'SEND'] });
  assert.equal(instrument.eligibility.credential.subject, 'OWNER');
  assert.equal(instrument.redemptionPolicy, 'ISSUER_APPROVAL');
  assert.equal(instrument.settlement.maxTransferTtlSeconds, 604800);
  assert.equal(instrument.supply.outstanding, '100000000');
  assert.equal(instrument.supply.maxOutstandingSupply, '500000000');
});

test('party queries only return contracts where the party has a role (BOLA)', async () => {
  const h = createHarness();
  const holdings = await h.bdar.listForParty({ party: PARTIES.partyA, collection: 'holdings', query: {}, auth: walletA });
  assert.equal(holdings.items.length, 3);
  const custodian = await h.bdar.listForParty({ party: PARTIES.custodian, collection: 'holdings', query: {}, auth: authFor([PARTIES.custodian]) });
  assert.equal(custodian.items.length, 3, 'the account provider sees the holdings too');
  const partyB = await h.bdar.listForParty({ party: PARTIES.partyB, collection: 'holdings', query: {}, auth: authFor([PARTIES.partyB]) });
  assert.equal(partyB.items.length, 0);
  await rejectsWithCode(assert, h.bdar.listForParty({ party: PARTIES.partyA, collection: 'holdings', query: {}, auth: authFor([PARTIES.partyB]) }), 'FORBIDDEN_PARTY');

  const unlocked = await h.bdar.listForParty({ party: PARTIES.partyA, collection: 'holdings', query: { locked: 'false' }, auth: walletA });
  assert.equal(unlocked.items.length, 2);
  const incoming = await h.bdar.listForParty({ party: PARTIES.partyB, collection: 'transfer-instructions', query: { role: 'receiver' }, auth: authFor([PARTIES.partyB]) });
  assert.equal(incoming.items.length, 1);
  assert.equal(incoming.items[0].status, 'PENDING_RECEIVER');
  assert.equal(incoming.items[0].kind, 'TRANSFER');
  const outgoing = await h.bdar.listForParty({ party: PARTIES.partyB, collection: 'transfer-instructions', query: { role: 'sender' }, auth: authFor([PARTIES.partyB]) });
  assert.equal(outgoing.items.length, 0);
});

test('balances add exact decimals and split locked from available', async () => {
  const h = createHarness();
  const { items } = await h.bdar.balancesForParty({ party: PARTIES.partyA, query: {}, auth: walletA });
  assert.equal(items.length, 1);
  assert.deepEqual({ total: items[0].total, locked: items[0].locked, available: items[0].available, holdingCount: items[0].holdingCount }, {
    total: '100000000', locked: '10000000', available: '90000000', holdingCount: 3,
  });
});

test('party query pagination is stable and cursors are validated', async () => {
  const h = createHarness();
  const first = await h.bdar.listForParty({ party: PARTIES.partyA, collection: 'holdings', query: { pageSize: 2 }, auth: walletA });
  assert.equal(first.items.length, 2);
  const second = await h.bdar.listForParty({ party: PARTIES.partyA, collection: 'holdings', query: { pageSize: 2, pageToken: first.nextPageToken }, auth: walletA });
  assert.equal(second.items.length, 1);
  assert.equal(second.nextPageToken, undefined);
  const ids = [...first.items, ...second.items].map((i) => i.contractId);
  assert.equal(new Set(ids).size, 3);
  await rejectsWithCode(assert, h.bdar.listForParty({ party: PARTIES.partyA, collection: 'holdings', query: { pageToken: 'garbage' }, auth: walletA }), 'VALIDATION_FAILED');
});

test('account lookup: found for a party of the account, 404 with a hint otherwise', async () => {
  const h = createHarness();
  const account = await h.bdar.getAccount({ query: { owner: PARTIES.partyA, provider: PARTIES.custodian, id: 'A-0001' }, auth: authFor([PARTIES.custodian]) });
  assert.equal(account.status, 'ACTIVE');
  assert.deepEqual(account.rules, custodialRules);
  await rejectsWithCode(assert, h.bdar.getAccount({ query: { owner: PARTIES.partyA, provider: PARTIES.custodian, id: 'A-0001' }, auth: authFor([PARTIES.partyB]) }), 'FORBIDDEN_PARTY');
  await assert.rejects(h.bdar.getAccount({ query: { owner: PARTIES.partyA }, auth: walletA }), (error) => {
    assert.equal(error.code, 'ACCOUNT_NOT_FOUND');
    assert.deepEqual(error.details[0].implicitBasicAccountUsableFor, []);
    return true;
  });
});

test('account request validation mirrors the operator checks and returns a create command', async () => {
  const h = createHarness();
  const newAccount = custodial(PARTIES.partyB, PARTIES.custodian, 'B-0001');
  const ok = await h.bdar.validateAccountRequest({
    body: { account: newAccount, change: { type: 'OPEN', rules: custodialRules, purpose: 'CLIENT', termsReference: 'BitGo-Custody-Terms-v3' }, reference: 'ONB-B-0001' },
    auth: authFor([PARTIES.partyB]),
  });
  assert.equal(ok.valid, true);
  assert.deepEqual(ok.actAs, [PARTIES.partyB]);
  assert.deepEqual(ok.missingApprovals, [PARTIES.custodian]);
  const args = ok.createCommand.CreateCommand.createArguments;
  assert.equal(args.admin, PARTIES.admin);
  assert.deepEqual(args.change, { tag: 'BdarOpenAccount', value: { rules: custodialRules, purpose: 'BdarClientAccount', termsReference: 'BitGo-Custody-Terms-v3' } });

  const duplicate = await h.bdar.validateAccountRequest({
    body: { account: accountA, change: { type: 'OPEN', rules: custodialRules, termsReference: 'x' }, reference: 'dup' },
    auth: walletA,
  });
  assert.equal(duplicate.valid, false);
  assert.ok(duplicate.problems.some((p) => p.code === 'ACCOUNT_ALREADY_EXISTS'));
  assert.equal(duplicate.createCommand, null);

  const badRules = await h.bdar.validateAccountRequest({
    body: { account: basic(PARTIES.partyB), change: { type: 'OPEN', rules: custodialRules, termsReference: 't' }, reference: 'r' },
    auth: authFor([PARTIES.partyB]),
  });
  assert.ok(badRules.problems.some((p) => p.code === 'ACCOUNT_RULES_INVALID'));

  const close = await h.bdar.validateAccountRequest({ body: { account: basic(PARTIES.partyB), change: { type: 'CLOSE' }, reference: 'close' }, auth: authFor([PARTIES.partyB]) });
  assert.equal(close.valid, true);
  assert.equal(close.existingAccountCid, h.contracts.accountB.createdEvent.contractId);
});
