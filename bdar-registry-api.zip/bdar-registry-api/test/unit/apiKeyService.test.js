/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createApiKeyService } from '../../src/services/apiKeyService.js';
import { createMemoryApiKeyRepository, createMemoryAuditRepository } from '../../src/repositories/memory.js';
import { createAuditService } from '../../src/services/supportServices.js';
import { formatApiKey, parseApiKey } from '../../src/security/apiKeyFormat.js';
import { PARTIES, testConfig } from '../fakes/fixtures.js';

function setup({ now = new Date('2026-09-14T12:00:00Z') } = {}) {
  const clock = { now };
  const repository = createMemoryApiKeyRepository();
  const auditRepository = createMemoryAuditRepository();
  const service = createApiKeyService({
    repository, config: testConfig(), audit: createAuditService({ repository: auditRepository }), now: () => clock.now,
  });
  return { service, repository, auditRepository, clock };
}

const walletKey = { clientName: 'BitGo wallet', scopes: ['wallet'], allowedParties: [PARTIES.partyA] };

test('create returns the plaintext key once and stores only a hash', async () => {
  const { service, repository } = setup();
  const { apiKey, key } = await service.create(walletKey, 'cli:ops');
  assert.match(apiKey, /^bdar_test_/);
  const record = await repository.findByKeyId(key.keyId);
  assert.ok(record.secretHash instanceof Uint8Array && record.secretHash.length === 32, 'a 32 byte HMAC is stored');
  assert.ok(!JSON.stringify({ ...record, secretHash: undefined }).includes(parseApiKey(apiKey).secret));
  assert.equal(key.secretHash, undefined, 'the public view never contains hashes');
});

test('verify accepts the key and returns the frozen auth context', async () => {
  const { service } = setup();
  const { apiKey, key } = await service.create(walletKey, 'cli:ops');
  const result = await service.verify(apiKey, { ip: '10.0.0.1' });
  assert.equal(result.ok, true);
  assert.equal(result.auth.keyId, key.keyId);
  assert.deepEqual([...result.auth.scopes], ['wallet']);
  assert.ok(Object.isFrozen(result.auth));
});

test('verify rejects wrong environment, unknown key, wrong secret, revoked and expired keys', async () => {
  const { service, clock } = setup();
  const { apiKey, key } = await service.create({ ...walletKey, expiresAt: '2026-09-20T00:00:00Z' }, 'cli:ops');
  const parsed = parseApiKey(apiKey);

  assert.equal((await service.verify(formatApiKey('live', parsed.keyId, parsed.secret))).reason, 'wrong-environment');
  assert.equal((await service.verify(formatApiKey('test', 'zzzzzzzzzzzzzzzz', parsed.secret))).reason, 'unknown-key');
  assert.equal((await service.verify(formatApiKey('test', parsed.keyId, 'f'.repeat(64)))).reason, 'wrong-secret');
  assert.equal((await service.verify('not a key')).reason, 'malformed');

  clock.now = new Date('2026-09-21T00:00:00Z');
  assert.equal((await service.verify(apiKey)).reason, 'expired');
  clock.now = new Date('2026-09-14T12:00:00Z');
  await service.revoke(key.keyId, { reason: 'test' }, 'cli:ops');
  assert.equal((await service.verify(apiKey)).reason, 'revoked');
});

test('rotation keeps the old secret valid for the overlap period only', async () => {
  const { service, clock } = setup();
  const { apiKey: oldKey, key } = await service.create(walletKey, 'cli:ops');
  const { apiKey: newKey } = await service.rotate(key.keyId, { overlapHours: 2 }, 'cli:ops');
  assert.notEqual(oldKey, newKey);
  assert.equal(parseApiKey(newKey).keyId, key.keyId, 'the key id does not change');

  assert.equal((await service.verify(newKey)).ok, true);
  const old = await service.verify(oldKey);
  assert.equal(old.ok, true);
  assert.equal(old.auth.usingPreviousSecret, true);

  clock.now = new Date('2026-09-14T14:00:01Z');
  assert.equal((await service.verify(oldKey)).reason, 'wrong-secret');
  assert.equal((await service.verify(newKey)).ok, true);
});

test('rotation with zero overlap retires the old secret at once', async () => {
  const { service } = setup();
  const { apiKey: oldKey, key } = await service.create(walletKey, 'cli:ops');
  await service.rotate(key.keyId, { overlapHours: 0 }, 'cli:ops');
  assert.equal((await service.verify(oldKey)).ok, false);
});

test('party bound scopes need allowed parties and unknown scopes are refused', async () => {
  const { service } = setup();
  await assert.rejects(service.create({ clientName: 'x', scopes: ['wallet'], allowedParties: [] }, 'cli'), { code: 'VALIDATION_FAILED' });
  await assert.rejects(service.create({ clientName: 'x', scopes: ['superuser'] }, 'cli'), { code: 'VALIDATION_FAILED' });
  await assert.rejects(service.create({ clientName: 'x', scopes: ['registry:read'], rateLimitTier: 'gold' }, 'cli'), { code: 'VALIDATION_FAILED' });
  const readOnly = await service.create({ clientName: 'viewer', scopes: ['registry:read'] }, 'cli');
  assert.deepEqual(readOnly.key.allowedParties, []);
});

test('update changes scopes without changing the secret, and every change is audited', async () => {
  const { service, auditRepository } = setup();
  const { apiKey, key } = await service.create(walletKey, 'cli:ops');
  const updated = await service.update(key.keyId, { scopes: ['wallet', 'submit'], rateLimitTier: 'elevated' }, 'key:admin');
  assert.deepEqual(updated.scopes, ['wallet', 'submit']);
  assert.equal(updated.rateLimitTier, 'elevated');
  assert.deepEqual([...(await service.verify(apiKey)).auth.scopes], ['wallet', 'submit']);
  const actions = auditRepository.events.map((event) => event.action);
  assert.deepEqual(actions, ['apiKey.create', 'apiKey.update']);
  assert.ok(!JSON.stringify(auditRepository.events).includes(parseApiKey(apiKey).secret), 'audit events never contain the secret');
});

test('unknown key ids are not distinguishable by an exception', async () => {
  const { service } = setup();
  const result = await service.verify(formatApiKey('test', 'abcdefabcdefabcd', '0'.repeat(64)));
  assert.deepEqual(result, { ok: false, reason: 'unknown-key', keyId: 'abcdefabcdefabcd' });
});
