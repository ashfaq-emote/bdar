/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  MAX_API_KEY_LENGTH, formatApiKey, generateApiKey, hashSecret, parseApiKey, redactApiKey, secretMatches,
} from '../../src/security/apiKeyFormat.js';

const PEPPER = 'test-pepper-with-more-than-thirty-two-bytes-0123456789';

test('a generated key has the documented format and parses back', () => {
  const { keyId, secret, apiKey } = generateApiKey('live');
  assert.match(apiKey, /^bdar_live_[a-z0-9]{16}_[0-9a-f]{64}_[0-9a-f]{8}$/);
  assert.ok(apiKey.length <= MAX_API_KEY_LENGTH);
  assert.deepEqual(parseApiKey(apiKey), { environment: 'live', keyId, secret });
});

test('two generated keys never share a key id or secret', () => {
  const seen = new Set();
  for (let i = 0; i < 200; i += 1) {
    const { keyId, secret } = generateApiKey('dev');
    assert.ok(!seen.has(keyId) && !seen.has(secret));
    seen.add(keyId).add(secret);
  }
});

test('a typo is caught by the checksum', () => {
  const { apiKey } = generateApiKey('test');
  const lastSecretChar = apiKey.length - 10;
  const flipped = apiKey.slice(0, lastSecretChar) + (apiKey[lastSecretChar] === 'a' ? 'b' : 'a') + apiKey.slice(lastSecretChar + 1);
  assert.equal(parseApiKey(flipped), undefined);
});

test('malformed and oversized input is rejected without throwing', () => {
  for (const value of [undefined, null, 42, '', 'bdar_live_x', 'Bearer abc', 'x'.repeat(5000), `bdar_prod_${'a'.repeat(16)}_${'0'.repeat(64)}_00000000`]) {
    assert.equal(parseApiKey(value), undefined);
  }
});

test('the stored hash matches only the right secret and key id', () => {
  const { keyId, secret } = generateApiKey('uat');
  const hash = hashSecret(PEPPER, keyId, secret);
  assert.ok(Buffer.isBuffer(hash));
  assert.equal(secretMatches(PEPPER, keyId, secret, hash), true);
  assert.equal(secretMatches(PEPPER, keyId, secret.replace(/.$/, '0'), hash), secret.endsWith('0'));
  assert.equal(secretMatches(PEPPER, 'zzzzzzzzzzzzzzzz', secret, hash), false);
  assert.equal(secretMatches(`${PEPPER}x`, keyId, secret, hash), false, 'a different pepper must not match');
});

test('formatApiKey is deterministic and redaction hides the secret', () => {
  const secret = 'ab'.repeat(32);
  const key = formatApiKey('dev', 'abcdefgh12345678', secret);
  assert.equal(key, formatApiKey('dev', 'abcdefgh12345678', secret));
  const redacted = redactApiKey(key);
  assert.ok(!redacted.includes(secret));
  assert.ok(redacted.includes('abcdefgh12345678'));
});
