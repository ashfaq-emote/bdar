-- Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
-- BROADRIDGE PROPRIETARY AND CONFIDENTIAL. Broadridge Digital Asset Registry (BDAR) Registry API.
--
-- Least privilege for the runtime role. Run the migrations as the owner role, and run the
-- API as bdar_api_app. The block is skipped when the role does not exist (local development).

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'bdar_api_app') THEN
    GRANT SELECT, INSERT, UPDATE ON bdar_api_keys TO bdar_api_app;
    GRANT SELECT, INSERT ON bdar_audit_events TO bdar_api_app;
    GRANT USAGE, SELECT ON SEQUENCE bdar_audit_events_id_seq TO bdar_api_app;
    GRANT SELECT, INSERT, UPDATE, DELETE ON bdar_idempotency_keys TO bdar_api_app;
  END IF;
END
$$;
