-- Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
-- BROADRIDGE PROPRIETARY AND CONFIDENTIAL. Broadridge Digital Asset Registry (BDAR) Registry API.
--
-- Append only audit trail of security relevant and state changing API activity.
-- The application database user is granted INSERT and SELECT only (see 004_grants.sql).

CREATE TABLE IF NOT EXISTS bdar_audit_events (
  id                bigserial PRIMARY KEY,
  occurred_at       timestamptz NOT NULL DEFAULT now(),
  request_id        text,
  api_key_id        text,
  client_name       text,
  action            text NOT NULL,
  resource_type     text,
  resource_id       text,
  outcome           text NOT NULL CHECK (outcome IN ('success', 'failure', 'denied')),
  http_status       integer,
  ledger_update_id  text,
  source_ip         text,
  user_agent        text,
  details           jsonb NOT NULL DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS bdar_audit_events_time_idx ON bdar_audit_events (occurred_at);
CREATE INDEX IF NOT EXISTS bdar_audit_events_key_idx ON bdar_audit_events (api_key_id, occurred_at);
CREATE INDEX IF NOT EXISTS bdar_audit_events_action_idx ON bdar_audit_events (action, occurred_at);
