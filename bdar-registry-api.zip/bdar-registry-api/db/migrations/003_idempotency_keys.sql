-- Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
-- BROADRIDGE PROPRIETARY AND CONFIDENTIAL. Broadridge Digital Asset Registry (BDAR) Registry API.
--
-- Idempotency records for state changing requests (Idempotency-Key header).

CREATE TABLE IF NOT EXISTS bdar_idempotency_keys (
  api_key_id        text NOT NULL,
  idempotency_key   text NOT NULL,
  request_hash      text NOT NULL,
  state             text NOT NULL CHECK (state IN ('in_progress', 'completed')),
  response_status   integer,
  response_body     jsonb,
  created_at        timestamptz NOT NULL DEFAULT now(),
  expires_at        timestamptz NOT NULL,
  PRIMARY KEY (api_key_id, idempotency_key)
);

CREATE INDEX IF NOT EXISTS bdar_idempotency_keys_expiry_idx ON bdar_idempotency_keys (expires_at);
