-- Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
-- BROADRIDGE PROPRIETARY AND CONFIDENTIAL. Broadridge Digital Asset Registry (BDAR) Registry API.
--
-- API keys. Only a keyed hash of each secret is stored, never the secret itself.

CREATE TABLE IF NOT EXISTS bdar_api_keys (
  id                          uuid PRIMARY KEY,
  key_id                      text NOT NULL UNIQUE,
  environment                 text NOT NULL,
  secret_hash                 bytea NOT NULL,
  previous_secret_hash        bytea,
  previous_secret_expires_at  timestamptz,
  client_name                 text NOT NULL,
  description                 text NOT NULL DEFAULT '',
  scopes                      text[] NOT NULL,
  allowed_parties             text[] NOT NULL DEFAULT '{}',
  rate_limit_tier             text NOT NULL DEFAULT 'standard',
  status                      text NOT NULL CHECK (status IN ('active', 'revoked')),
  created_at                  timestamptz NOT NULL DEFAULT now(),
  created_by                  text NOT NULL,
  updated_at                  timestamptz NOT NULL DEFAULT now(),
  expires_at                  timestamptz,
  last_used_at                timestamptz,
  last_used_ip                text,
  revoked_at                  timestamptz,
  revoked_by                  text,
  revoke_reason               text,
  CONSTRAINT bdar_api_keys_key_id_format CHECK (key_id ~ '^[a-z0-9]{16}$'),
  CONSTRAINT bdar_api_keys_scopes_not_empty CHECK (cardinality(scopes) > 0)
);

CREATE INDEX IF NOT EXISTS bdar_api_keys_status_idx ON bdar_api_keys (status);
CREATE INDEX IF NOT EXISTS bdar_api_keys_client_idx ON bdar_api_keys (client_name);
