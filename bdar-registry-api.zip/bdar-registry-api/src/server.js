/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Process entry point: load configuration, create dependencies, listen, shut down cleanly.
 *
 * Shutdown sequence on SIGTERM or SIGINT:
 *   1. Readiness starts answering 503 so the load balancer stops sending traffic.
 *   2. Wait a short drain period (half of SHUTDOWN_GRACE_MS).
 *   3. Stop accepting connections and let in-flight requests finish.
 *   4. Close PostgreSQL and Redis.
 *   5. Exit. If anything hangs past SHUTDOWN_GRACE_MS, exit with code 1.
 */

import { readFileSync } from 'node:fs';
import http from 'node:http';
import https from 'node:https';
import pino from 'pino';
import { ConfigError, loadConfig } from './config/index.js';
import { createDependencies } from './container.js';
import { createApp } from './app.js';

const { version } = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

async function main() {
  let config;
  try {
    config = loadConfig(process.env);
  } catch (error) {
    if (error instanceof ConfigError) {
      process.stderr.write(`Configuration is not valid:\n${error.problems.map((p) => `  - ${p}`).join('\n')}\n`);
      process.exit(2);
    }
    throw error;
  }

  const logger = pino({
    level: config.logLevel,
    base: { service: 'bdar-registry-api', version, environment: config.apiEnvironment },
    redact: { paths: ['*.apiKey', '*.secret', '*.password', '*.token', '*.authorization', '*["x-api-key"]'], censor: '[redacted]' },
    timestamp: pino.stdTimeFunctions.isoTime,
  });

  const dependencies = await createDependencies({ config, logger, version });
  const app = createApp({ config, logger, dependencies, version });

  const server = config.server.tlsCertFile
    ? https.createServer({ cert: readFileSync(config.server.tlsCertFile), key: readFileSync(config.server.tlsKeyFile), minVersion: 'TLSv1.2' }, app)
    : http.createServer(app);

  // Slow client protection (OWASP API4): bounded header and request times.
  server.headersTimeout = 20000;
  server.requestTimeout = config.ledger.timeoutMs + 15000;
  server.keepAliveTimeout = 65000;
  server.maxHeadersCount = 100;

  server.listen(config.server.port, config.server.host, () => {
    logger.info({ port: config.server.port, host: config.server.host, tls: Boolean(config.server.tlsCertFile) }, 'BDAR registry API listening');
  });

  let stopping = false;
  async function shutdown(signal) {
    if (stopping) return;
    stopping = true;
    logger.info({ signal }, 'shutting down');
    dependencies.services.health.markShuttingDown();
    const forceExit = setTimeout(() => {
      logger.error('shutdown took too long, exiting');
      process.exit(1);
    }, config.server.shutdownGraceMs);
    forceExit.unref();
    await new Promise((resolve) => setTimeout(resolve, Math.floor(config.server.shutdownGraceMs / 2)).unref());
    server.close(async () => {
      await dependencies.close();
      logger.info('stopped');
      process.exit(0);
    });
    server.closeIdleConnections?.();
  }
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('unhandledRejection', (reason) => logger.error({ err: reason }, 'unhandled promise rejection'));
}

main().catch((error) => {
  process.stderr.write(`Fatal: ${error.stack ?? error}\n`);
  process.exit(1);
});
