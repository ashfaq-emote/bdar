/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Mapping between Daml contract payloads and the JSON the API returns or accepts.
 *
 * Why map at all? Daml constructor names such as `BdarRedeemWithIssuerApproval` are
 * precise but awkward for integrators, and RelTime values are microsecond strings.
 * The Broadridge extension endpoints use short upper case enums and seconds. The
 * token standard endpoints (/registry/...) keep the standard formats unchanged.
 */

import { apiError } from '../lib/errors.js';
import {
  accountKey, decimalText, isBurnAccount, isMintAccount, normalizeAccount, qualifiedName, relTimeSeconds,
  relTimeToSeconds, tagOf, variant,
} from './daml.js';

/** A two way mapping between Daml constructors and API enum values. */
function enumMap(pairs) {
  const toApi = new Map(pairs);
  const toDaml = new Map(pairs.map(([daml, api]) => [api, daml]));
  return {
    values: pairs.map(([, api]) => api),
    api(damlValue) {
      const tag = tagOf(damlValue);
      if (!toApi.has(tag)) throw new Error(`unexpected Daml constructor ${tag}`);
      return toApi.get(tag);
    },
    daml(apiValue, field) {
      if (!toDaml.has(apiValue)) {
        throw apiError('VALIDATION_FAILED', undefined, { details: [{ field, message: `must be one of ${pairs.map(([, api]) => api).join(', ')}` }] });
      }
      return toDaml.get(apiValue);
    },
  };
}

export const Enums = Object.freeze({
  standards: enumMap([['BdarSupportsV1AndV2', 'V1_AND_V2'], ['BdarSupportsV2Only', 'V2_ONLY']]),
  accountPolicy: enumMap([['BdarImplicitBasicAccounts', 'IMPLICIT_BASIC'], ['BdarExplicitAccounts', 'EXPLICIT']]),
  registryAction: enumMap([['BdarHold', 'HOLD'], ['BdarSend', 'SEND'], ['BdarMint', 'MINT'], ['BdarRedeem', 'REDEEM']]),
  credentialSubject: enumMap([['BdarCredentialOwner', 'OWNER'], ['BdarCredentialOwnerAndProvider', 'OWNER_AND_PROVIDER']]),
  redemptionPolicy: enumMap([
    ['BdarRedemptionDisabled', 'DISABLED'], ['BdarRedeemImmediately', 'IMMEDIATE'], ['BdarRedeemWithIssuerApproval', 'ISSUER_APPROVAL'],
  ]),
  instrumentStatus: enumMap([['BdarInstrumentActive', 'ACTIVE'], ['BdarInstrumentRetired', 'RETIRED']]),
  accountPurpose: enumMap([['BdarClientAccount', 'CLIENT'], ['BdarRecoveryAccount', 'RECOVERY']]),
});

const metaValues = (meta) => meta?.values ?? {};
const toMeta = (values) => ({ values: values ?? {} });
const nullable = (value) => (value === undefined ? null : value);

// ---------------------------------------------------------------------------
// Instruments
// ---------------------------------------------------------------------------

/** Full Broadridge view of an instrument, optionally with its supply. */
export function instrumentToApi(contract, supplyContract) {
  const i = contract.payload;
  const eligibility = i.eligibilityPolicy ?? {};
  const supplyPolicy = i.supplyPolicy ?? {};
  const settlement = i.settlementPolicy ?? {};
  const supply = supplyContract?.payload;
  return {
    instrumentId: i.instrumentId,
    contractId: contract.contractId,
    admin: i.admin,
    name: i.name,
    symbol: i.symbol,
    decimals: Number(i.decimals),
    issuers: i.issuers,
    standards: Enums.standards.api(i.standards),
    accountPolicy: Enums.accountPolicy.api(i.accountPolicy),
    eligibility: {
      allowlist: eligibility.allowlist
        ? { appliesTo: eligibility.allowlist.appliesTo.map((action) => Enums.registryAction.api(action)) }
        : null,
      credential: eligibility.credential
        ? {
          enabled: eligibility.credential.enabled,
          trustedIssuers: eligibility.credential.trustedIssuers,
          subject: Enums.credentialSubject.api(eligibility.credential.subject),
          requirements: eligibility.credential.requirements.map((r) => ({
            registryAction: Enums.registryAction.api(r.registryAction),
            credentialAction: r.credentialAction,
          })),
        }
        : null,
    },
    supply: {
      maxOutstandingSupply: decimalText(supplyPolicy.maxOutstandingSupply),
      maxMintPerRequest: decimalText(supplyPolicy.maxMintPerRequest),
      mintApprovalRequired: Boolean(supplyPolicy.mintApprovalRequired),
      outstanding: supply ? decimalText(supply.outstanding) : null,
      totalMinted: supply ? decimalText(supply.totalMinted) : null,
      totalBurned: supply ? decimalText(supply.totalBurned) : null,
    },
    redemptionPolicy: Enums.redemptionPolicy.api(i.redemptionPolicy),
    settlement: {
      maxTransferTtlSeconds: relTimeToSeconds(settlement.maxTransferTtl),
      maxAllocationTtlSeconds: relTimeToSeconds(settlement.maxAllocationTtl),
      allowCommittedAllocations: Boolean(settlement.allowCommittedAllocations),
      allowIteratedSettlement: Boolean(settlement.allowIteratedSettlement),
      allowMintAndBurnAllocations: Boolean(settlement.allowMintAndBurnAllocations),
    },
    controls: { clawbackEnabled: Boolean(i.controlPolicy?.clawbackEnabled) },
    pause: i.pause ? { reason: i.pause.reason, pausedUntil: nullable(i.pause.pausedUntil) } : null,
    status: Enums.instrumentStatus.api(i.status),
    meta: metaValues(i.meta),
    createdAt: contract.createdAt,
  };
}

/** The Daml policy records from the API policy input (shared by create and update). */
export function policiesToDaml(input) {
  const eligibility = input.eligibility ?? {};
  const credential = eligibility.credential;
  return {
    accountPolicy: Enums.accountPolicy.daml(input.accountPolicy, 'accountPolicy'),
    eligibilityPolicy: {
      allowlist: eligibility.allowlist
        ? { appliesTo: eligibility.allowlist.appliesTo.map((a) => Enums.registryAction.daml(a, 'eligibility.allowlist.appliesTo')) }
        : null,
      credential: credential
        ? {
          enabled: credential.enabled,
          trustedIssuers: credential.trustedIssuers,
          subject: Enums.credentialSubject.daml(credential.subject, 'eligibility.credential.subject'),
          requirements: credential.requirements.map((r) => ({
            registryAction: Enums.registryAction.daml(r.registryAction, 'eligibility.credential.requirements.registryAction'),
            credentialAction: r.credentialAction,
          })),
        }
        : null,
    },
    supplyPolicy: {
      maxOutstandingSupply: input.supply?.maxOutstandingSupply ?? null,
      maxMintPerRequest: input.supply?.maxMintPerRequest ?? null,
      mintApprovalRequired: Boolean(input.supply?.mintApprovalRequired),
    },
    redemptionPolicy: Enums.redemptionPolicy.daml(input.redemptionPolicy, 'redemptionPolicy'),
    settlementPolicy: {
      maxTransferTtl: relTimeSeconds(input.settlement.maxTransferTtlSeconds),
      maxAllocationTtl: relTimeSeconds(input.settlement.maxAllocationTtlSeconds),
      allowCommittedAllocations: Boolean(input.settlement.allowCommittedAllocations),
      allowIteratedSettlement: Boolean(input.settlement.allowIteratedSettlement),
      allowMintAndBurnAllocations: Boolean(input.settlement.allowMintAndBurnAllocations),
    },
    controlPolicy: { clawbackEnabled: Boolean(input.controls?.clawbackEnabled) },
  };
}

/**
 * Check the rules of `isValidInstrument` (Config.daml) before submitting, so the
 * client gets a clear 400 instead of a ledger rejection. The ledger checks again.
 */
export function instrumentProblems(input) {
  const problems = [];
  const add = (field, message) => problems.push({ field, message });
  if (input.decimals !== undefined && (input.decimals < 0 || input.decimals > 10)) add('decimals', 'must be between 0 and 10');
  if (input.issuers && new Set(input.issuers).size !== input.issuers.length) add('issuers', 'must not contain duplicates');
  if (input.controls?.clawbackEnabled && input.accountPolicy !== 'EXPLICIT') {
    add('controls.clawbackEnabled', 'clawback needs accountPolicy EXPLICIT');
  }
  for (const field of ['maxOutstandingSupply', 'maxMintPerRequest']) {
    const value = input.supply?.[field];
    if (value !== null && value !== undefined && !(Number(value) > 0)) add(`supply.${field}`, 'must be greater than zero');
  }
  if (input.settlement && !(input.settlement.maxTransferTtlSeconds > 0)) add('settlement.maxTransferTtlSeconds', 'must be greater than zero');
  if (input.settlement && !(input.settlement.maxAllocationTtlSeconds > 0)) add('settlement.maxAllocationTtlSeconds', 'must be greater than zero');
  const credential = input.eligibility?.credential;
  if (credential?.enabled && (credential.trustedIssuers.length === 0 || credential.requirements.length === 0)) {
    add('eligibility.credential', 'an enabled credential policy needs trusted issuers and requirements');
  }
  if (input.eligibility?.allowlist && input.eligibility.allowlist.appliesTo.length === 0) {
    add('eligibility.allowlist.appliesTo', 'must name at least one action');
  }
  return problems;
}

/** A complete BdarInstrument payload for BdarRegistryConfig_CreateInstrument. */
export function instrumentToDaml(input, adminParty) {
  return {
    admin: adminParty,
    instrumentId: input.instrumentId,
    name: input.name,
    symbol: input.symbol,
    decimals: String(input.decimals),
    issuers: input.issuers,
    standards: Enums.standards.daml(input.standards, 'standards'),
    ...policiesToDaml(input),
    pause: null,
    status: 'BdarInstrumentActive',
    meta: toMeta(input.meta),
  };
}

/** The token standard metadata API names and the minor version BDAR supports. */
export const V1_APIS = Object.freeze({
  'splice-api-token-metadata-v1': 1,
  'splice-api-token-holding-v1': 1,
  'splice-api-token-transfer-instruction-v1': 1,
  'splice-api-token-allocation-v1': 1,
  'splice-api-token-allocation-instruction-v1': 1,
});

export const V2_APIS = Object.freeze({
  'splice-api-token-metadata-v1': 1,
  'splice-api-token-holding-v2': 1,
  'splice-api-token-transfer-instruction-v2': 1,
  'splice-api-token-allocation-v2': 1,
  'splice-api-token-allocation-instruction-v2': 1,
  'splice-api-token-transfer-events-v2': 1,
});

/** APIs a registry supports across all its instruments. */
export const registrySupportedApis = () => ({ ...V1_APIS, ...V2_APIS });

/** The token standard `Instrument` schema (GET /registry/metadata/v1/instruments). */
export function instrumentToMetadata(contract, supplyContract, asOf) {
  const i = contract.payload;
  const supportsV1 = tagOf(i.standards) === 'BdarSupportsV1AndV2';
  const instrument = {
    id: i.instrumentId,
    name: i.name,
    symbol: i.symbol,
    decimals: Number(i.decimals),
    paused: Boolean(i.pause),
    supportedApis: supportsV1 ? registrySupportedApis() : { ...V2_APIS },
    // Both account policies accept explicit (custodial) accounts, so wallets should
    // always let the user enter a provider and an account id.
    showAccountInputFields: true,
    accountInputFieldsToShow: ['provider', 'accountId'],
  };
  if (supplyContract) {
    instrument.totalSupply = decimalText(supplyContract.payload.outstanding);
    instrument.totalSupplyAsOf = asOf;
  }
  if (i.pause) {
    instrument.pauseInfo = { reason: i.pause.reason, ...(i.pause.pausedUntil ? { until: i.pause.pausedUntil } : {}) };
  }
  return instrument;
}

// ---------------------------------------------------------------------------
// Holdings, transfer instructions, allocations
// ---------------------------------------------------------------------------

export function lockToApi(lock) {
  if (!lock) return null;
  return {
    holders: lock.holders,
    expiresAt: nullable(lock.expiresAt),
    expiresAfterSeconds: lock.expiresAfter ? relTimeToSeconds(lock.expiresAfter) : null,
    context: nullable(lock.context),
  };
}

export function holdingToApi(contract) {
  const h = contract.payload;
  return {
    contractId: contract.contractId,
    account: normalizeAccount(h.account),
    instrumentId: { admin: h.admin, id: h.instrumentId },
    amount: decimalText(h.amount),
    lock: lockToApi(h.lock),
    meta: metaValues(h.meta),
    createdAt: contract.createdAt,
  };
}

/** A lock is in force until its expiry time (if it has one). */
export function isLocked(holding, now = new Date()) {
  const lock = holding.payload.lock;
  if (!lock) return false;
  return !lock.expiresAt || new Date(lock.expiresAt) > now;
}

/** Balances per account and instrument: total, locked and available. */
export function balancesOf(holdingContracts, now = new Date()) {
  const rows = new Map();
  for (const contract of holdingContracts) {
    const h = contract.payload;
    const key = `${accountKey(h.account)}#${h.instrumentId}`;
    const row = rows.get(key) ?? {
      account: normalizeAccount(h.account), instrumentId: { admin: h.admin, id: h.instrumentId },
      total: 0n, locked: 0n, holdingCount: 0,
    };
    const units = decimalUnits(h.amount);
    row.total += units;
    if (isLocked(contract, now)) row.locked += units;
    row.holdingCount += 1;
    rows.set(key, row);
  }
  return [...rows.values()].map((row) => ({
    account: row.account,
    instrumentId: row.instrumentId,
    total: unitsToDecimal(row.total),
    locked: unitsToDecimal(row.locked),
    available: unitsToDecimal(row.total - row.locked),
    holdingCount: row.holdingCount,
  }));
}

/** Daml Decimal has 10 decimal places. Add them exactly with BigInt, never with floats. */
export function decimalUnits(text) {
  const [whole, fraction = ''] = String(text).split('.');
  const negative = whole.startsWith('-');
  const units = BigInt(whole.replace('-', '') || '0') * 10n ** 10n + BigInt((fraction + '0000000000').slice(0, 10));
  return negative ? -units : units;
}

export function unitsToDecimal(units) {
  const negative = units < 0n;
  const abs = negative ? -units : units;
  const whole = abs / 10n ** 10n;
  const fraction = (abs % 10n ** 10n).toString().padStart(10, '0').replace(/0+$/, '');
  return `${negative ? '-' : ''}${whole}${fraction ? `.${fraction}` : ''}`;
}

export function transferToApi(transfer) {
  return {
    sender: normalizeAccount(transfer.sender),
    receiver: normalizeAccount(transfer.receiver),
    amount: decimalText(transfer.amount),
    instrumentId: transfer.instrumentId,
    requestedAt: transfer.requestedAt,
    executeBefore: transfer.executeBefore,
    inputHoldingCids: transfer.inputHoldingCids ?? [],
    meta: metaValues(transfer.meta),
  };
}

export function transferInstructionToApi(contract) {
  const t = contract.payload;
  const state = t.state ?? {};
  const awaitingReceiver = tagOf(state) === 'BdarAwaitingReceiver';
  let kind = 'TRANSFER';
  if (isMintAccount(t.transfer.sender)) kind = 'MINT';
  else if (isBurnAccount(t.transfer.receiver)) kind = 'REDEMPTION';
  return {
    contractId: contract.contractId,
    kind,
    status: awaitingReceiver ? 'PENDING_RECEIVER' : 'PENDING_SENDER',
    transfer: transferToApi(t.transfer),
    approvals: awaitingReceiver ? state.value.receiverApprovals : state.value?.senderApprovals ?? [],
    lockedHoldingCids: awaitingReceiver ? state.value.lockedHoldingCids : [],
    issuers: t.issuers ?? [],
    originalInstructionCid: nullable(t.originalInstructionCid),
    createdAt: contract.createdAt,
  };
}

/** Locked holdings of a transfer instruction that is waiting for the receiver. */
export function lockedHoldingsOfInstruction(payload) {
  return tagOf(payload.state) === 'BdarAwaitingReceiver' ? payload.state.value.lockedHoldingCids ?? [] : [];
}

/** The BdarAllocation record of either allocation template. */
export function allocationCore(contract) {
  return qualifiedName(contract.templateId).endsWith(':BdarAllocationV1') ? contract.payload.core : contract.payload;
}

export function allocationToApi(contract) {
  const core = allocationCore(contract);
  return {
    contractId: contract.contractId,
    standard: qualifiedName(contract.templateId).endsWith(':BdarAllocationV1') ? 'V1_AND_V2' : 'V2_ONLY',
    settlement: core.settlement,
    allocation: core.allocation,
    lockedHoldingCids: core.lockedHoldingCids,
    authorizers: core.authorizers,
    withdrawers: core.withdrawers,
    createdAt: core.createdAt,
    expiresAt: core.expiresAt,
    allocateBefore: nullable(core.allocateBefore),
    numIterations: Number(core.numIterations),
    originalAllocationCid: nullable(core.originalAllocationCid),
  };
}

export function allocationInstructionToApi(contract) {
  const a = contract.payload;
  return {
    contractId: contract.contractId,
    settlement: a.settlement,
    allocation: a.allocation,
    requestedAt: a.requestedAt,
    inputHoldingCids: a.inputHoldingCids,
    approvals: a.approvals,
    rules: a.rules,
    allocateBefore: nullable(a.allocateBefore),
    originalInstructionCid: nullable(a.originalInstructionCid),
    createdAt: contract.createdAt,
  };
}

// ---------------------------------------------------------------------------
// Accounts and controls
// ---------------------------------------------------------------------------

export function accountToApi(contract) {
  const a = contract.payload;
  const frozen = tagOf(a.status) === 'BdarAccountFrozen';
  return {
    contractId: contract.contractId,
    account: normalizeAccount(a.account),
    accountKey: accountKey(a.account),
    rules: a.rules,
    status: frozen ? 'FROZEN' : 'ACTIVE',
    frozenReason: frozen ? a.status.value.reason : null,
    purpose: Enums.accountPurpose.api(a.purpose),
    termsReference: a.termsReference,
    meta: metaValues(a.meta),
    createdAt: contract.createdAt,
  };
}

/** API form of BdarAccountChange. */
export function accountChangeToApi(change) {
  switch (tagOf(change)) {
    case 'BdarOpenAccount':
      return { type: 'OPEN', rules: change.value.rules, purpose: Enums.accountPurpose.api(change.value.purpose), termsReference: change.value.termsReference };
    case 'BdarChangeAccountRules':
      return { type: 'CHANGE_RULES', newRules: change.value.newRules };
    case 'BdarSetTransferPreapproval':
      return { type: 'SET_PREAPPROVAL', instrumentIds: nullable(change.value.instrumentIds), expiresAt: nullable(change.value.expiresAt) };
    case 'BdarCloseAccount':
      return { type: 'CLOSE' };
    default:
      throw new Error(`unexpected account change ${tagOf(change)}`);
  }
}

/** Daml form of an API account change. */
export function accountChangeToDaml(change) {
  switch (change.type) {
    case 'OPEN':
      return variant('BdarOpenAccount', {
        rules: rulesToDaml(change.rules),
        purpose: Enums.accountPurpose.daml(change.purpose ?? 'CLIENT', 'change.purpose'),
        termsReference: change.termsReference,
      });
    case 'CHANGE_RULES':
      return variant('BdarChangeAccountRules', { newRules: rulesToDaml(change.newRules) });
    case 'SET_PREAPPROVAL':
      return variant('BdarSetTransferPreapproval', { instrumentIds: change.instrumentIds ?? null, expiresAt: change.expiresAt ?? null });
    case 'CLOSE':
      return variant('BdarCloseAccount', {});
    default:
      throw apiError('VALIDATION_FAILED', undefined, { details: [{ field: 'change.type', message: 'unknown change type' }] });
  }
}

export const rulesToDaml = (rules) => ({
  owner: { canInitiate: Boolean(rules.owner.canInitiate), mustApprove: Boolean(rules.owner.mustApprove) },
  provider: rules.provider ? { canInitiate: Boolean(rules.provider.canInitiate), mustApprove: Boolean(rules.provider.mustApprove) } : null,
});

/** Same rule as isValidAccountRules in AccountRules.daml. Returns a list of problems. */
export function accountRulesProblems(account, rules) {
  const problems = [];
  const a = normalizeAccount(account);
  if (!a.owner) problems.push('the account must have an owner');
  if (Boolean(a.provider) !== Boolean(rules.provider)) problems.push('provider rules must be given exactly when the account has a provider');
  if (a.provider && a.provider === a.owner) problems.push('the provider must differ from the owner');
  const roles = [rules.owner, ...(a.provider && rules.provider ? [rules.provider] : [])];
  if (!roles.some((rule) => rule.canInitiate)) problems.push('at least one party must be able to initiate');
  if (!roles.some((rule) => rule.mustApprove)) problems.push('at least one party must approve');
  return problems;
}

export function accountRequestToApi(contract) {
  const r = contract.payload;
  const parties = [r.account.owner, r.account.provider].filter(Boolean);
  return {
    contractId: contract.contractId,
    account: normalizeAccount(r.account),
    change: accountChangeToApi(r.change),
    approvals: r.approvals,
    missingApprovals: parties.filter((party) => !r.approvals.includes(party)),
    reference: r.reference,
    createdAt: contract.createdAt,
  };
}

export function preapprovalToApi(contract) {
  const p = contract.payload;
  return {
    contractId: contract.contractId,
    account: normalizeAccount(p.account),
    instrumentIds: nullable(p.instrumentIds),
    expiresAt: nullable(p.expiresAt),
    createdAt: contract.createdAt,
  };
}

export function clawbackRecordToApi(contract) {
  const c = contract.payload;
  return {
    contractId: contract.contractId,
    account: normalizeAccount(c.account),
    instrumentId: c.instrumentId,
    amount: decimalText(c.amount),
    outcome: c.recoveryAccount ? 'REASSIGN' : 'BURN',
    recoveryAccount: c.recoveryAccount ? normalizeAccount(c.recoveryAccount) : null,
    reason: c.reason,
    acknowledged: c.acknowledged,
    createdAt: contract.createdAt,
  };
}

export function allowlistEntryToApi(contract) {
  const e = contract.payload;
  return {
    contractId: contract.contractId,
    party: e.party,
    instrumentId: e.instrumentId,
    validUntil: nullable(e.validUntil),
    reference: e.reference,
    createdAt: contract.createdAt,
  };
}

export function mintRequestToApi(contract) {
  const m = contract.payload;
  return {
    contractId: contract.contractId,
    issuer: m.issuer,
    instrumentId: m.details.instrumentId,
    receiver: normalizeAccount(m.details.receiver),
    amount: decimalText(m.details.amount),
    reference: m.details.reference,
    requestedAt: m.details.requestedAt,
    executeBefore: m.details.executeBefore,
    createdAt: contract.createdAt,
  };
}

export function registryConfigToApi(contract) {
  const c = contract.payload;
  return {
    contractId: contract.contractId,
    admin: c.admin,
    registryName: c.registryName,
    credentialChecksEnabled: c.credentialChecksEnabled,
    meta: metaValues(c.meta),
    createdAt: contract.createdAt,
  };
}
