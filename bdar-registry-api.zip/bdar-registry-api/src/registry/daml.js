/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Daml identifiers and JSON value helpers for the BDAR packages.
 *
 * The JSON Ledger API encodes Daml values like this:
 *   Record          { "field": value, ... }
 *   Variant         { "tag": "Constructor", "value": value }      (a constructor without fields has value {})
 *   Enum            "Constructor"                                    (a type whose constructors all have no fields)
 *   Optional        null, or the value
 *   Decimal, Int    "123.45", "42"                                   (strings)
 *   Time            "2026-09-15T07:00:00Z"
 *   RelTime         { "microseconds": "3600000000" }
 *   TextMap         { "key": value }
 *   Map (DA.Map)    [[key, value], ...]
 */

export const BDAR_NAMESPACE = 'broadridge.com/bdar/';

/** Choice context keys, identical to Broadridge.DigitalAssetRegistry.Types. */
export const ContextKeys = Object.freeze({
  registryConfig: `${BDAR_NAMESPACE}registry-config`,
  eventLog: `${BDAR_NAMESPACE}event-log`,
  instruments: `${BDAR_NAMESPACE}instruments`,
  supplies: `${BDAR_NAMESPACE}supplies`,
  accounts: `${BDAR_NAMESPACE}accounts`,
  allowlist: `${BDAR_NAMESPACE}allowlist`,
  credentials: `${BDAR_NAMESPACE}credentials`,
  preapprovals: `${BDAR_NAMESPACE}preapprovals`,
  allocationFactory: `${BDAR_NAMESPACE}allocation-factory`,
  settlementFactory: `${BDAR_NAMESPACE}settlement-factory`,
});

export const MetaKeys = Object.freeze({
  reference: `${BDAR_NAMESPACE}reference`,
  pendingSide: `${BDAR_NAMESPACE}pending-side`,
});

/** Template and interface names, relative to their package. */
const TEMPLATES = {
  registryConfig: 'Broadridge.DigitalAssetRegistry.Config:BdarRegistryConfig',
  instrument: 'Broadridge.DigitalAssetRegistry.Config:BdarInstrument',
  supply: 'Broadridge.DigitalAssetRegistry.Config:BdarSupply',
  eventLog: 'Broadridge.DigitalAssetRegistry.EventLog:BdarEventLog',
  transferFactory: 'Broadridge.DigitalAssetRegistry.Factories:BdarTransferFactory',
  allocationFactory: 'Broadridge.DigitalAssetRegistry.Factories:BdarAllocationFactory',
  settlementFactory: 'Broadridge.DigitalAssetRegistry.Factories:BdarSettlementFactory',
  issuanceFactory: 'Broadridge.DigitalAssetRegistry.Issuance:BdarIssuanceFactory',
  mintRequest: 'Broadridge.DigitalAssetRegistry.Issuance:BdarMintRequest',
  holding: 'Broadridge.DigitalAssetRegistry.Holding:BdarHolding',
  account: 'Broadridge.DigitalAssetRegistry.Account:BdarAccount',
  accountRequest: 'Broadridge.DigitalAssetRegistry.Account:BdarAccountRequest',
  preapproval: 'Broadridge.DigitalAssetRegistry.Account:BdarTransferPreapproval',
  clawbackRecord: 'Broadridge.DigitalAssetRegistry.Account:BdarClawbackRecord',
  allowlistEntry: 'Broadridge.DigitalAssetRegistry.Eligibility:BdarAllowlistEntry',
  transferInstruction: 'Broadridge.DigitalAssetRegistry.Transfer:BdarTransferInstruction',
  allocationInstruction: 'Broadridge.DigitalAssetRegistry.Allocation:BdarAllocationInstruction',
  allocation: 'Broadridge.DigitalAssetRegistry.Allocation:BdarAllocation',
  allocationV1: 'Broadridge.DigitalAssetRegistry.Allocation:BdarAllocationV1',
};

const SPLICE_INTERFACES = {
  holdingV1: ['splice-api-token-holding-v1', 'Splice.Api.Token.HoldingV1:Holding'],
  holdingV2: ['splice-api-token-holding-v2', 'Splice.Api.Token.HoldingV2:Holding'],
  transferFactoryV1: ['splice-api-token-transfer-instruction-v1', 'Splice.Api.Token.TransferInstructionV1:TransferFactory'],
  transferFactoryV2: ['splice-api-token-transfer-instruction-v2', 'Splice.Api.Token.TransferInstructionV2:TransferFactory'],
  transferInstructionV1: ['splice-api-token-transfer-instruction-v1', 'Splice.Api.Token.TransferInstructionV1:TransferInstruction'],
  transferInstructionV2: ['splice-api-token-transfer-instruction-v2', 'Splice.Api.Token.TransferInstructionV2:TransferInstruction'],
  allocationFactoryV1: ['splice-api-token-allocation-instruction-v1', 'Splice.Api.Token.AllocationInstructionV1:AllocationFactory'],
  allocationFactoryV2: ['splice-api-token-allocation-instruction-v2', 'Splice.Api.Token.AllocationInstructionV2:AllocationFactory'],
  allocationInstructionV2: ['splice-api-token-allocation-instruction-v2', 'Splice.Api.Token.AllocationInstructionV2:AllocationInstruction'],
  allocationV1: ['splice-api-token-allocation-v1', 'Splice.Api.Token.AllocationV1:Allocation'],
  allocationV2: ['splice-api-token-allocation-v2', 'Splice.Api.Token.AllocationV2:Allocation'],
  settlementFactoryV2: ['splice-api-token-allocation-v2', 'Splice.Api.Token.AllocationV2:SettlementFactory'],
  allocationRequestV1: ['splice-api-token-allocation-request-v1', 'Splice.Api.Token.AllocationRequestV1:AllocationRequest'],
  allocationRequestV2: ['splice-api-token-allocation-request-v2', 'Splice.Api.Token.AllocationRequestV2:AllocationRequest'],
};

/**
 * Package name references (#package-name:Module:Entity). They keep working across
 * package upgrades, unlike package id references.
 */
export function createIdentifiers(registryConfig) {
  const bdar = (name) => `#${registryConfig.packageName}:${TEMPLATES[name]}`;
  const templates = Object.fromEntries(Object.keys(TEMPLATES).map((name) => [name, bdar(name)]));
  const interfaces = Object.fromEntries(
    Object.entries(SPLICE_INTERFACES).map(([name, [pkg, id]]) => [name, `#${pkg}:${id}`]),
  );
  interfaces.credential = `#${registryConfig.apiPackageName}:Broadridge.DigitalAssetRegistry.Api.CredentialV1:BdarCredential`;
  return Object.freeze({ templates: Object.freeze(templates), interfaces: Object.freeze(interfaces) });
}

/** "Module:Entity" part of any template id, whatever the package reference format. */
export const qualifiedName = (templateId) => templateId.split(':').slice(-2).join(':');

/** True if a template id (package id or package name format) names the given BDAR template. */
export const isTemplate = (templateId, name) => qualifiedName(templateId) === TEMPLATES[name];

// ---------------------------------------------------------------------------
// Accounts
// ---------------------------------------------------------------------------

export const MINT_ACCOUNT_ID = 'cip-112/mint';
export const BURN_ACCOUNT_ID = 'cip-112/burn';

export const basicAccount = (party) => ({ owner: party, provider: null, id: '' });
export const mintAccount = () => ({ owner: null, provider: null, id: MINT_ACCOUNT_ID });
export const burnAccount = () => ({ owner: null, provider: null, id: BURN_ACCOUNT_ID });

export const normalizeAccount = (account) => ({
  owner: account?.owner ?? null,
  provider: account?.provider ?? null,
  id: account?.id ?? '',
});

export const isRegularAccount = (account) => Boolean(account?.owner);
export const isBasicAccount = (account) => Boolean(account?.owner) && !account.provider && (account.id ?? '') === '';
export const isMintAccount = (account) => !account?.owner && !account?.provider && account?.id === MINT_ACCOUNT_ID;
export const isBurnAccount = (account) => !account?.owner && !account?.provider && account?.id === BURN_ACCOUNT_ID;

/** Parties of an account, owner first. */
export const accountParties = (account) => [account?.owner, account?.provider].filter(Boolean);

/** Same key as Broadridge.DigitalAssetRegistry.Context.accountKey: "owner|provider|id". */
export const accountKey = (account) => `${account?.owner ?? ''}|${account?.provider ?? ''}|${account?.id ?? ''}`;

export const sameAccount = (a, b) => accountKey(normalizeAccount(a)) === accountKey(normalizeAccount(b));

// ---------------------------------------------------------------------------
// Values
// ---------------------------------------------------------------------------

export const variant = (tag, value = {}) => ({ tag, value });
export const emptyMetadata = () => ({ values: {} });
export const emptyExtraArgs = () => ({ context: { values: {} }, meta: { values: {} } });
export const relTimeSeconds = (seconds) => ({ microseconds: String(BigInt(seconds) * 1000000n) });
export const relTimeToSeconds = (relTime) => Number(BigInt(relTime?.microseconds ?? '0') / 1000000n);

/** Tag of a variant value, or the value itself for an enum. */
export const tagOf = (value) => (typeof value === 'string' ? value : value?.tag);

/** A Daml Decimal as a plain decimal string without trailing zeros ("1000.0000000000" becomes "1000"). */
export function decimalText(value) {
  if (value === null || value === undefined) return null;
  const text = String(value);
  if (!text.includes('.')) return text;
  return text.replace(/0+$/, '').replace(/\.$/, '');
}

/** Convert a DA.Map JSON value ([[k, v], ...]) or an object into a plain object keyed by the stringified key. */
export function mapEntries(value) {
  if (Array.isArray(value)) return value.map(([key, entry]) => [key, entry]);
  return Object.entries(value ?? {});
}

/** AnyValue encoders for choice contexts (Splice.Api.Token.MetadataV1.AnyValue). */
export const AnyValue = Object.freeze({
  contractId: (cid) => ({ tag: 'AV_ContractId', value: cid }),
  map: (entries) => ({ tag: 'AV_Map', value: entries }),
  list: (items) => ({ tag: 'AV_List', value: items }),
  text: (text) => ({ tag: 'AV_Text', value: text }),
});
