/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Reads registry contracts from the ledger.
 *
 * This is the only module that knows WHERE contracts come from. Today it reads the
 * active contract set (ACS) through the JSON Ledger API as the registry admin party.
 * A later workstream hydrates PostgreSQL with contracts; that project will provide
 * a second implementation of the same interface (see ContractReader below) and the
 * rest of the API will not change.
 *
 * Caching: each template query is cached for CONTEXT_CACHE_TTL_MS (default 1 second).
 * A short cache protects the ledger from bursts of identical queries. It is always
 * cleared after the API itself submits a command. A stale entry can only make a
 * choice fail with a "contract not found" error, which the API returns as 409
 * STALE_CONTRACT so the client fetches a fresh context.
 *
 * @typedef {object} RegistryContract
 * @property {string} contractId
 * @property {string} templateId      as returned by the ledger (package id format)
 * @property {string} packageName
 * @property {object} payload         the Daml create arguments, JSON encoded
 * @property {string} createdEventBlob
 * @property {string} synchronizerId
 * @property {string} createdAt
 * @property {string[]} signatories
 * @property {string[]} observers
 * @property {Array<{interfaceId: string, viewValue: object}>} interfaceViews
 *
 * @typedef {object} ContractReader
 * @property {(name: string) => Promise<RegistryContract[]>} template
 * @property {(name: string) => Promise<RegistryContract>} singleton
 * @property {() => Promise<RegistryContract[]>} instruments
 * @property {(instrumentId: string) => Promise<RegistryContract|undefined>} instrument
 * @property {(instrumentId: string) => Promise<RegistryContract|undefined>} supply
 * @property {(parties: string[]) => Promise<RegistryContract[]>} credentials
 * @property {(contractId: string) => Promise<RegistryContract|undefined>} contract
 * @property {() => void} invalidate
 */

import { apiError } from '../lib/errors.js';
import { TtlCache, noopLogger } from '../lib/util.js';

/** Turn a JSON Ledger API active contract entry into a RegistryContract. */
export function normalizeContract(entry) {
  const event = entry.createdEvent;
  return {
    contractId: event.contractId,
    templateId: event.templateId,
    packageName: event.packageName,
    payload: event.createArgument ?? {},
    createdEventBlob: event.createdEventBlob ?? '',
    synchronizerId: entry.synchronizerId,
    createdAt: event.createdAt,
    signatories: event.signatories ?? [],
    observers: event.observers ?? [],
    interfaceViews: (event.interfaceViews ?? [])
      .filter((view) => view.viewValue !== undefined && view.viewValue !== null)
      .map((view) => ({ interfaceId: view.interfaceId, viewValue: view.viewValue })),
  };
}

/**
 * A disclosed contract as the token standard OpenAPI defines it.
 * The debug fields help people read a context. Clients must never trust them;
 * the ledger only uses createdEventBlob.
 */
export function toDisclosedContract(contract, { excludeDebugFields = false } = {}) {
  const disclosed = {
    templateId: contract.templateId,
    contractId: contract.contractId,
    createdEventBlob: contract.createdEventBlob,
    synchronizerId: contract.synchronizerId,
  };
  if (!excludeDebugFields) {
    disclosed.debugPackageName = contract.packageName;
    disclosed.debugPayload = contract.payload;
    disclosed.debugCreatedAt = contract.createdAt;
  }
  return disclosed;
}

/** Singletons created once by the registry bootstrap. */
const SINGLETONS = ['registryConfig', 'eventLog', 'transferFactory', 'allocationFactory', 'settlementFactory', 'issuanceFactory'];

/**
 * @param {{ ledger: object, adminParty: string, identifiers: object, cacheTtlMs: number,
 *           credentialReadParties?: string[], logger?: object }} options
 * @returns {ContractReader}
 */
export function createLedgerContractReader({ ledger, adminParty, identifiers, cacheTtlMs, credentialReadParties = [], logger = noopLogger }) {
  const cache = new TtlCache({ ttlMs: cacheTtlMs, maxEntries: 500 });

  function queryTemplate(name) {
    const templateId = identifiers.templates[name];
    if (!templateId) throw new Error(`unknown template ${name}`);
    return cache.getOrLoad(`template:${name}`, async () => {
      const { contracts } = await ledger.activeContracts({ parties: [adminParty], templateIds: [templateId] });
      return contracts.map(normalizeContract).sort((a, b) => a.contractId.localeCompare(b.contractId));
    });
  }

  function queryCredentials() {
    if (credentialReadParties.length === 0) return Promise.resolve([]);
    return cache.getOrLoad('interface:credential', async () => {
      const { contracts } = await ledger.activeContracts({
        parties: credentialReadParties,
        interfaceIds: [identifiers.interfaces.credential],
      });
      // The same credential can be visible to several read parties. Keep one copy.
      const byId = new Map(contracts.map(normalizeContract).map((contract) => [contract.contractId, contract]));
      return [...byId.values()];
    });
  }

  return {
    kind: 'ledger-acs',

    template: queryTemplate,

    /** A contract the bootstrap creates exactly once. 503 REGISTRY_NOT_BOOTSTRAPPED if it is missing. */
    async singleton(name) {
      if (!SINGLETONS.includes(name)) throw new Error(`${name} is not a registry singleton`);
      const contracts = (await queryTemplate(name)).filter((contract) => contract.payload.admin === adminParty);
      if (contracts.length === 0) throw apiError('REGISTRY_NOT_BOOTSTRAPPED', `The registry has no active ${name} contract`);
      if (contracts.length > 1) logger.warn({ name, count: contracts.length }, 'more than one registry singleton is active; using the oldest');
      return [...contracts].sort((a, b) => String(a.createdAt).localeCompare(String(b.createdAt)))[0];
    },

    async instruments() {
      return (await queryTemplate('instrument')).filter((contract) => contract.payload.admin === adminParty);
    },

    async instrument(instrumentId) {
      return (await this.instruments()).find((contract) => contract.payload.instrumentId === instrumentId);
    },

    async supply(instrumentId) {
      return (await queryTemplate('supply'))
        .find((contract) => contract.payload.admin === adminParty && contract.payload.instrumentId === instrumentId);
    },

    /** Credential contracts (BdarCredential interface) whose holder is one of `parties`. */
    async credentials(parties) {
      const wanted = new Set(parties);
      return (await queryCredentials()).filter((contract) => {
        const view = contract.interfaceViews[0]?.viewValue;
        return view && wanted.has(view.holder);
      });
    },

    /** One active contract by id, read as the admin. Undefined when it is archived or unknown. */
    async contract(contractId) {
      const found = await cache.getOrLoad(`contract:${contractId}`, async () => {
        const entry = await ledger.activeContractById(contractId, [adminParty]);
        return entry ? normalizeContract(entry) : null;
      });
      return found ?? undefined;
    },

    invalidate() {
      cache.clear();
    },
  };
}
