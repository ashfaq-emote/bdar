/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Builds choice contexts: the `choiceContextData` values and the disclosed contracts a
 * client passes to a BDAR choice.
 *
 * The executable specification is `getContext` in the Workstream 1 test module
 * Broadridge.DigitalAssetRegistry.Test.RegistryApi. This module does the same thing
 * against the live ledger:
 *
 *   key                                   value                                 when
 *   broadridge.com/bdar/registry-config   contract id                           always
 *   broadridge.com/bdar/event-log         contract id                           always
 *   broadridge.com/bdar/instruments       map instrumentId -> contract id       always
 *   broadridge.com/bdar/supplies          map instrumentId -> contract id       always
 *   broadridge.com/bdar/accounts          map "owner|provider|id" -> cid        explicit accounts in the request
 *   broadridge.com/bdar/preapprovals      map "owner|provider|id" -> cid        usable preapprovals of those accounts
 *   broadridge.com/bdar/allowlist         map "party|instrumentId" -> cid       only if an instrument has an allowlist
 *   broadridge.com/bdar/credentials       map party -> list of cids             only if credential checks are on
 *   broadridge.com/bdar/allocation-factory  contract id                         V1 execute-transfer only
 *   broadridge.com/bdar/settlement-factory  contract id                         V1 execute-transfer only
 *
 * Rule: the context is derived from the choice arguments the client sends, never
 * from what the client claims it needs. That keeps proofs of unrelated parties out
 * of a response (OWASP API3, excessive data exposure).
 */

import { apiError } from '../lib/errors.js';
import { unique } from '../lib/util.js';
import {
  AnyValue, ContextKeys, accountKey, accountParties, isRegularAccount, isTemplate, normalizeAccount, tagOf,
} from './daml.js';
import { toDisclosedContract } from './contractReader.js';

/** Limits sized for the token standard minimum: 25 legs, 50 allocations, 50 accounts, 100 parties. */
export const CONTEXT_LIMITS = Object.freeze({ instruments: 50, accounts: 100, parties: 200, holdings: 1000 });

const isActiveAt = (expiresAt, now) => !expiresAt || new Date(expiresAt) > now;

/**
 * @param {{ reader: import('./contractReader.js').ContractReader, adminParty: string, now?: () => Date }} deps
 */
export function createContextBuilder({ reader, adminParty, now = () => new Date() }) {
  return {
    /**
     * @param {{ instrumentIds?: string[], accounts?: object[], parties?: string[], holdingCids?: string[],
     *           includeV1Factories?: boolean, factories?: string[], excludeDebugFields?: boolean }} request
     * @returns {Promise<{ choiceContext: { choiceContextData: object, disclosedContracts: object[] }, facts: object }>}
     */
    async build(request) {
      const instrumentIds = unique((request.instrumentIds ?? []).filter(Boolean));
      const accounts = uniqueAccounts((request.accounts ?? []).map(normalizeAccount).filter(isRegularAccount));
      const holdingCids = unique(request.holdingCids ?? []);
      checkLimits({ instrumentIds, accounts, holdingCids, parties: request.parties ?? [] });
      const at = now();

      const [config, eventLog, allInstruments, allAccounts, allPreapprovals] = await Promise.all([
        reader.singleton('registryConfig'),
        reader.singleton('eventLog'),
        reader.instruments(),
        accounts.length > 0 ? reader.template('account') : [],
        accounts.length > 0 ? reader.template('preapproval') : [],
      ]);

      // Instruments and supplies. A missing instrument is a 404 here rather than a
      // context-missing failure on the ledger later.
      const instruments = new Map();
      const missing = [];
      for (const instrumentId of instrumentIds) {
        const contract = allInstruments.find((c) => c.payload.instrumentId === instrumentId);
        if (contract) instruments.set(instrumentId, contract); else missing.push(instrumentId);
      }
      if (missing.length > 0) {
        throw apiError('INSTRUMENT_NOT_FOUND', undefined, { details: missing.map((id) => ({ instrumentId: id })) });
      }
      const supplies = new Map();
      for (const instrumentId of instrumentIds) {
        const supply = await reader.supply(instrumentId);
        if (supply) supplies.set(instrumentId, supply);
      }

      // Explicit account contracts and usable preapprovals of the accounts in the request.
      const wantedKeys = new Set(accounts.map(accountKey));
      const accountContracts = new Map(
        allAccounts
          .filter((c) => c.payload.admin === adminParty && wantedKeys.has(accountKey(c.payload.account)))
          .map((c) => [accountKey(c.payload.account), c]),
      );
      const preapprovals = new Map();
      for (const contract of allPreapprovals) {
        const p = contract.payload;
        const key = accountKey(p.account);
        if (p.admin !== adminParty || !wantedKeys.has(key) || preapprovals.has(key)) continue;
        const covers = p.instrumentIds === null || p.instrumentIds === undefined
          || instrumentIds.some((id) => p.instrumentIds.includes(id));
        if (covers && isActiveAt(p.expiresAt, at)) preapprovals.set(key, contract);
      }

      // Subjects of eligibility checks: account parties plus any extra parties (issuers, actors).
      const subjects = unique([...accounts.flatMap(accountParties), ...(request.parties ?? [])]);

      const allowlist = new Map();
      if ([...instruments.values()].some((c) => c.payload.eligibilityPolicy?.allowlist)) {
        const entries = await reader.template('allowlistEntry');
        for (const contract of entries) {
          const e = contract.payload;
          if (e.admin === adminParty && subjects.includes(e.party) && instruments.has(e.instrumentId) && isActiveAt(e.validUntil, at)) {
            allowlist.set(`${e.party}|${e.instrumentId}`, contract);
          }
        }
      }

      const credentials = new Map();
      const credentialPolicies = [...instruments.values()]
        .map((c) => c.payload.eligibilityPolicy?.credential)
        .filter((policy) => policy?.enabled);
      if (config.payload.credentialChecksEnabled && credentialPolicies.length > 0 && subjects.length > 0) {
        const trusted = new Set(credentialPolicies.flatMap((policy) => policy.trustedIssuers));
        for (const contract of await reader.credentials(subjects)) {
          const view = contract.interfaceViews[0].viewValue;
          if (tagOf(view.status) !== 'BdarCredentialActive' || !trusted.has(view.issuer)) continue;
          credentials.set(view.holder, [...(credentials.get(view.holder) ?? []), contract]);
        }
      }

      // Holdings the submitter cannot see but the choice will archive or unlock.
      const holdings = [];
      for (const contractId of holdingCids) {
        const contract = await reader.contract(contractId);
        if (!contract) {
          throw apiError('STALE_CONTRACT', 'A holding used by this request is no longer active', { details: [{ contractId }] });
        }
        if (!isTemplate(contract.templateId, 'holding') || contract.payload.admin !== adminParty) {
          throw apiError('VALIDATION_FAILED', 'A contract id is not a holding of this registry', { details: [{ contractId }] });
        }
        holdings.push(contract);
      }

      const factoryNames = unique([
        ...(request.factories ?? []),
        ...(request.includeV1Factories ? ['allocationFactory', 'settlementFactory'] : []),
      ]);
      const factories = new Map();
      for (const name of factoryNames) factories.set(name, await reader.singleton(name));

      const cidMap = (map) => AnyValue.map(Object.fromEntries([...map].map(([key, contract]) => [key, AnyValue.contractId(contract.contractId)])));
      const values = {
        [ContextKeys.registryConfig]: AnyValue.contractId(config.contractId),
        [ContextKeys.eventLog]: AnyValue.contractId(eventLog.contractId),
        [ContextKeys.instruments]: cidMap(instruments),
        [ContextKeys.supplies]: cidMap(supplies),
        [ContextKeys.accounts]: cidMap(accountContracts),
        [ContextKeys.preapprovals]: cidMap(preapprovals),
        [ContextKeys.allowlist]: cidMap(allowlist),
        [ContextKeys.credentials]: AnyValue.map(Object.fromEntries(
          [...credentials].map(([party, list]) => [party, AnyValue.list(list.map((c) => AnyValue.contractId(c.contractId)))]),
        )),
      };
      if (request.includeV1Factories) {
        values[ContextKeys.allocationFactory] = AnyValue.contractId(factories.get('allocationFactory').contractId);
        values[ContextKeys.settlementFactory] = AnyValue.contractId(factories.get('settlementFactory').contractId);
      }

      const disclosed = new Map();
      const disclose = (contract) => {
        if (!disclosed.has(contract.contractId)) {
          disclosed.set(contract.contractId, toDisclosedContract(contract, { excludeDebugFields: request.excludeDebugFields }));
        }
      };
      [...factories.values()].forEach(disclose);
      [config, eventLog, ...instruments.values(), ...supplies.values(), ...accountContracts.values(), ...preapprovals.values(),
        ...allowlist.values(), ...[...credentials.values()].flat(), ...holdings].forEach(disclose);

      return {
        choiceContext: { choiceContextData: { values }, disclosedContracts: [...disclosed.values()] },
        facts: { config, instruments, supplies, accounts: accountContracts, preapprovals, factories },
      };
    },
  };
}

function uniqueAccounts(accounts) {
  const byKey = new Map();
  for (const account of accounts) if (!byKey.has(accountKey(account))) byKey.set(accountKey(account), account);
  return [...byKey.values()];
}

function checkLimits({ instrumentIds, accounts, holdingCids, parties }) {
  const problems = [];
  if (instrumentIds.length > CONTEXT_LIMITS.instruments) problems.push({ field: 'instrumentIds', message: `at most ${CONTEXT_LIMITS.instruments} instruments` });
  if (accounts.length > CONTEXT_LIMITS.accounts) problems.push({ field: 'accounts', message: `at most ${CONTEXT_LIMITS.accounts} accounts` });
  if (parties.length > CONTEXT_LIMITS.parties) problems.push({ field: 'parties', message: `at most ${CONTEXT_LIMITS.parties} parties` });
  if (holdingCids.length > CONTEXT_LIMITS.holdings) problems.push({ field: 'holdingCids', message: `at most ${CONTEXT_LIMITS.holdings} holdings` });
  if (problems.length > 0) throw apiError('VALIDATION_FAILED', 'The request is larger than this registry supports', { details: problems });
}
