#!/usr/bin/env node
/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * API key administration from the command line.
 *
 * Used for the very first key (there is no key yet to call /admin/v1/api-keys with)
 * and for break glass operations when the API is down. It talks to PostgreSQL
 * directly, with the same service code the API uses, and writes the same audit events.
 *
 *   npm run keys -- create --client "Broadridge Ops" --scopes keys:manage,operator:write,operator:read,audit:read --parties "*"
 *   npm run keys -- list [--status active]
 *   npm run keys -- show --key-id k3h9x2m4p8q1w7e5
 *   npm run keys -- rotate --key-id k3h9x2m4p8q1w7e5 [--overlap-hours 24]
 *   npm run keys -- revoke --key-id k3h9x2m4p8q1w7e5 --reason "laptop lost"
 *
 * The plaintext key is printed once, on stdout, and nowhere else.
 */

import { parseArgs } from 'node:util';
import { userInfo } from 'node:os';
import { loadConfig } from '../config/index.js';
import { createApiKeyService } from '../services/apiKeyService.js';
import { createAuditService } from '../services/supportServices.js';

const USAGE = `Usage: npm run keys -- <create|list|show|rotate|revoke> [options]
  create  --client <name> --scopes <a,b> [--parties <p1,p2|*>] [--tier <standard>] [--expires <ISO time>] [--description <text>]
  list    [--status active|revoked] [--client <name>]
  show    --key-id <id>
  rotate  --key-id <id> [--overlap-hours <n>]
  revoke  --key-id <id> --reason <text>`;

const csv = (value) => (value ? value.split(',').map((item) => item.trim()).filter(Boolean) : undefined);

async function main() {
  const [command, ...rest] = process.argv.slice(2);
  const { values } = parseArgs({
    args: rest,
    options: {
      client: { type: 'string' }, scopes: { type: 'string' }, parties: { type: 'string' }, tier: { type: 'string' },
      expires: { type: 'string' }, description: { type: 'string' }, status: { type: 'string' }, 'key-id': { type: 'string' },
      'overlap-hours': { type: 'string' }, reason: { type: 'string' },
    },
    strict: true,
  });

  // The CLI does not need the ledger or Redis, only the database and the pepper.
  const config = loadConfig({ ...process.env, BDAR_ADMIN_PARTY: process.env.BDAR_ADMIN_PARTY ?? 'cli::00', LEDGER_JSON_API_URL: process.env.LEDGER_JSON_API_URL ?? 'http://localhost:0' });
  if (!config.database.url) throw new Error('DATABASE_URL must be set');
  const { default: pg } = await import('pg');
  const { createPostgresApiKeyRepository, createPostgresAuditRepository } = await import('../repositories/postgres.js');
  const pool = new pg.Pool({ connectionString: config.database.url, ssl: config.database.ssl ? { rejectUnauthorized: true } : undefined, max: 2 });
  const actor = `cli:${userInfo().username}`;
  const audit = createAuditService({ repository: createPostgresAuditRepository(pool) });
  const keys = createApiKeyService({ repository: createPostgresApiKeyRepository(pool), config, audit });

  try {
    switch (command) {
      case 'create': {
        const result = await keys.create({
          clientName: values.client, description: values.description, scopes: csv(values.scopes),
          allowedParties: csv(values.parties) ?? [], rateLimitTier: values.tier, expiresAt: values.expires ?? null,
        }, actor);
        process.stdout.write(`${JSON.stringify(result.key, null, 2)}\n\nAPI key (shown once, store it in your secret manager now):\n${result.apiKey}\n`);
        break;
      }
      case 'list':
        process.stdout.write(`${JSON.stringify(await keys.list({ status: values.status, clientName: values.client }), null, 2)}\n`);
        break;
      case 'show':
        process.stdout.write(`${JSON.stringify(await keys.get(values['key-id']), null, 2)}\n`);
        break;
      case 'rotate': {
        const overlapHours = values['overlap-hours'] === undefined ? undefined : Number(values['overlap-hours']);
        const result = await keys.rotate(values['key-id'], { overlapHours }, actor);
        process.stdout.write(`${JSON.stringify(result.key, null, 2)}\n\nNew API key (shown once):\n${result.apiKey}\n`);
        break;
      }
      case 'revoke':
        if (!values.reason) throw new Error('--reason is required');
        process.stdout.write(`${JSON.stringify(await keys.revoke(values['key-id'], { reason: values.reason }, actor), null, 2)}\n`);
        break;
      default:
        process.stderr.write(`${USAGE}\n`);
        process.exitCode = 2;
    }
  } finally {
    await pool.end();
  }
}

main().catch((error) => {
  const details = error.details?.length ? `\n${JSON.stringify(error.details, null, 2)}` : '';
  process.stderr.write(`Error: ${error.message}${details}\n`);
  process.exit(1);
});
