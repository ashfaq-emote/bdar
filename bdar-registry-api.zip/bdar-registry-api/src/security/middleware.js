/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Security middleware that does not depend on Express internals: request ids,
 * API key authentication, rate limiting and scope checks.
 *
 * Each factory returns a standard `(req, res, next)` function, so the logic can be
 * unit tested with plain objects.
 */

import { randomUUID } from 'node:crypto';
import { ApiError, apiError } from '../lib/errors.js';
import { requireAnyScope } from './scopes.js';

const REQUEST_ID_PATTERN = /^[A-Za-z0-9._-]{8,128}$/;

/**
 * Give every request an id. A well formed X-Request-Id from the caller is kept so a
 * request can be traced end to end; anything else is replaced.
 */
export function requestId() {
  return function requestIdMiddleware(req, res, next) {
    const incoming = req.headers['x-request-id'];
    req.id = typeof incoming === 'string' && REQUEST_ID_PATTERN.test(incoming) ? incoming : randomUUID();
    res.setHeader('X-Request-Id', req.id);
    next();
  };
}

/**
 * API key authentication.
 *
 * Order of checks (see the Technical Implementation Guide, section on API keys):
 *   1. Refuse keys in the URL query string (they leak into logs and browser history).
 *   2. If the client IP is blocked for repeated failures, answer 429 at once.
 *   3. Read the X-API-Key header. Missing: 401.
 *   4. Verify the key (format, checksum, environment, record, hash, status, expiry).
 *   5. On failure: count the failure for the IP, audit it, answer 401 with a generic message.
 *   6. On success: attach req.auth and continue.
 *
 * @param {{ apiKeyService: object, rateLimiter?: object, audit?: object, logger?: object, optional?: boolean }} deps
 */
export function authenticate({ apiKeyService, rateLimiter, audit, logger, optional = false }) {
  return async function authenticateMiddleware(req, res, next) {
    try {
      const url = req.originalUrl ?? req.url ?? '';
      if (/[?&](api[_-]?key|apikey|key|token)=/i.test(url)) {
        throw apiError('VALIDATION_FAILED', 'API keys must be sent in the X-API-Key header, never in the URL');
      }
      const ip = req.ip ?? 'unknown';
      if (rateLimiter && (await rateLimiter.isBlocked('authFailure', `ip:${ip}`))) {
        const blockSeconds = rateLimiter.policy('authFailure')?.blockSeconds || 60;
        throw apiError('RATE_LIMITED', undefined, { headers: { 'Retry-After': String(blockSeconds) } });
      }
      const header = req.headers['x-api-key'];
      if (header === undefined) {
        if (optional) return next();
        throw apiError('AUTH_MISSING_API_KEY', undefined, { headers: { 'WWW-Authenticate': 'ApiKey header="X-API-Key"' } });
      }
      const result = await apiKeyService.verify(Array.isArray(header) ? header[0] : header, { ip });
      if (!result.ok) {
        await rateLimiter?.consume('authFailure', `ip:${ip}`);
        logger?.warn({ reason: result.reason, keyId: result.keyId, ip, requestId: req.id }, 'API key rejected');
        audit?.record({
          action: 'auth.failure', outcome: 'denied', httpStatus: 401, requestId: req.id, apiKeyId: result.keyId,
          sourceIp: ip, userAgent: req.headers['user-agent'], details: { reason: result.reason, path: req.path },
        });
        throw apiError('AUTH_INVALID_API_KEY', undefined, { headers: { 'WWW-Authenticate': 'ApiKey header="X-API-Key"' } });
      }
      req.auth = result.auth;
      return next();
    } catch (error) {
      return next(error);
    }
  };
}

/**
 * Rate limiting for one named policy. Subject is the API key id when the request
 * is authenticated and the policy is keyed by API key, otherwise the client IP.
 * Sets RateLimit-Limit, RateLimit-Remaining and RateLimit-Reset on every response
 * and Retry-After on 429.
 */
export function rateLimit({ rateLimiter, policy }) {
  return async function rateLimitMiddleware(req, res, next) {
    try {
      const settings = rateLimiter.policy(policy);
      if (!settings) return next();
      const byKey = settings.keyBy === 'apiKey' && req.auth;
      const subject = byKey ? `key:${req.auth.keyId}` : `ip:${req.ip ?? 'unknown'}`;
      const result = await rateLimiter.consume(policy, subject, { tier: byKey ? req.auth.rateLimitTier : 'standard' });
      if (!result) return next();
      res.setHeader('RateLimit-Limit', String(result.limit));
      res.setHeader('RateLimit-Remaining', String(result.remaining));
      res.setHeader('RateLimit-Reset', String(result.resetSeconds));
      res.setHeader('RateLimit-Policy', `${result.limit};w=${settings.durationSeconds};name="${policy}"`);
      if (result.limited) {
        throw apiError('RATE_LIMITED', undefined, { headers: { 'Retry-After': String(result.resetSeconds) } });
      }
      return next();
    } catch (error) {
      return next(error);
    }
  };
}

/** Scope check for a route. */
export function requireScopes(scopes) {
  return function requireScopesMiddleware(req, res, next) {
    try {
      if (scopes && scopes.length > 0) requireAnyScope(req.auth, scopes);
      next();
    } catch (error) {
      next(error);
    }
  };
}

/** Reject request bodies that are not JSON for methods that carry a body. */
export function requireJsonBody() {
  return function requireJsonBodyMiddleware(req, res, next) {
    const hasBody = ['POST', 'PUT', 'PATCH'].includes(req.method)
      && (Number(req.headers['content-length'] ?? 0) > 0 || req.headers['transfer-encoding'] !== undefined);
    const type = String(req.headers['content-type'] ?? '');
    if (hasBody && !/^application\/json(\s*;|$)/i.test(type)) {
      return next(apiError('UNSUPPORTED_MEDIA_TYPE'));
    }
    return next();
  };
}

/** Mark an Idempotency-Key header as required and check its format. */
export function requireIdempotencyKey() {
  return function requireIdempotencyKeyMiddleware(req, res, next) {
    const key = req.headers['idempotency-key'];
    if (typeof key !== 'string' || key.length === 0) return next(apiError('IDEMPOTENCY_KEY_REQUIRED'));
    if (!/^[A-Za-z0-9._:-]{8,128}$/.test(key)) {
      return next(apiError('VALIDATION_FAILED', 'Idempotency-Key must be 8 to 128 characters of letters, digits, dot, underscore, colon or hyphen'));
    }
    req.idempotencyKey = key;
    return next();
  };
}

export { ApiError };
