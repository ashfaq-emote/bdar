/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Rate limiting: counters and stores.
 *
 * Algorithm: fixed window counter with an optional block period.
 *   - Each (policy, subject) pair has a counter that lives for `durationSeconds`.
 *   - Every request adds one point. When the counter goes above `points` the
 *     request is refused with 429 until the window ends.
 *   - If `blockSeconds` is set, crossing the limit also blocks the subject for that
 *     long, even if a new window starts (used for failed authentication).
 *
 * Stores:
 *   - RedisStore: shared by every API instance. One Lua script does the check and
 *     the increment atomically, so two instances can never both pass the last point.
 *   - MemoryStore: per process. Used for local development and as the fallback.
 *   - FallbackStore: uses Redis, and switches to memory for a short cool down when
 *     Redis errors or is too slow. Limits keep working (per instance) during a
 *     Redis outage instead of failing open or taking the API down.
 */

/** Lua script used by RedisStore. KEYS[1]=counter, KEYS[2]=block. ARGV: windowMs, limit, blockMs, cost. */
export const REDIS_CONSUME_SCRIPT = `
local blocked = redis.call('PTTL', KEYS[2])
if blocked > 0 then
  return {-1, blocked}
end
local current = redis.call('INCRBY', KEYS[1], tonumber(ARGV[4]))
local ttl = redis.call('PTTL', KEYS[1])
if ttl < 0 then
  redis.call('PEXPIRE', KEYS[1], ARGV[1])
  ttl = tonumber(ARGV[1])
end
if current > tonumber(ARGV[2]) and tonumber(ARGV[3]) > 0 then
  redis.call('SET', KEYS[2], '1', 'PX', ARGV[3])
  return {current, tonumber(ARGV[3])}
end
return {current, ttl}
`;

/** Per process store. Good for one instance or as a fallback. */
export class MemoryStore {
  constructor({ now = () => Date.now(), maxKeys = 100000 } = {}) {
    this.now = now;
    this.maxKeys = maxKeys;
    this.counters = new Map();
    this.blocks = new Map();
    this.kind = 'memory';
  }

  async consume(key, { windowMs, limit, blockMs, cost = 1 }) {
    const now = this.now();
    const blockedUntil = this.blocks.get(key);
    if (blockedUntil !== undefined) {
      if (blockedUntil > now) return { count: -1, msBeforeReset: blockedUntil - now };
      this.blocks.delete(key);
    }
    let entry = this.counters.get(key);
    if (!entry || entry.resetAt <= now) {
      entry = { count: 0, resetAt: now + windowMs };
      this.counters.set(key, entry);
      this.evictIfNeeded(now);
    }
    entry.count += cost;
    if (entry.count > limit && blockMs > 0) {
      this.blocks.set(key, now + blockMs);
      return { count: entry.count, msBeforeReset: blockMs };
    }
    return { count: entry.count, msBeforeReset: entry.resetAt - now };
  }

  async isBlocked(key) {
    const blockedUntil = this.blocks.get(key);
    return blockedUntil !== undefined && blockedUntil > this.now();
  }

  async reset(key) {
    this.counters.delete(key);
    this.blocks.delete(key);
  }

  evictIfNeeded(now) {
    if (this.counters.size <= this.maxKeys) return;
    for (const [key, entry] of this.counters) {
      if (entry.resetAt <= now) this.counters.delete(key);
    }
    while (this.counters.size > this.maxKeys) this.counters.delete(this.counters.keys().next().value);
  }
}

/** Shared store on Redis. `redis` is an ioredis client (or anything with eval, pttl, del). */
export class RedisStore {
  constructor({ redis, keyPrefix = 'bdar:rl:' }) {
    this.redis = redis;
    this.keyPrefix = keyPrefix;
    this.kind = 'redis';
  }

  async consume(key, { windowMs, limit, blockMs, cost = 1 }) {
    const [count, ttl] = await this.redis.eval(
      REDIS_CONSUME_SCRIPT,
      2,
      `${this.keyPrefix}${key}`,
      `${this.keyPrefix}${key}:block`,
      windowMs,
      limit,
      blockMs,
      cost,
    );
    return { count: Number(count), msBeforeReset: Math.max(0, Number(ttl)) };
  }

  async isBlocked(key) {
    return Number(await this.redis.pttl(`${this.keyPrefix}${key}:block`)) > 0;
  }

  async reset(key) {
    await this.redis.del(`${this.keyPrefix}${key}`, `${this.keyPrefix}${key}:block`);
  }
}

/** Redis first, memory when Redis is unhealthy. */
export class FallbackStore {
  constructor({ primary, fallback = new MemoryStore(), logger, coolDownMs = 10000, now = () => Date.now() }) {
    this.primary = primary;
    this.fallback = fallback;
    this.logger = logger;
    this.coolDownMs = coolDownMs;
    this.now = now;
    this.degradedUntil = 0;
  }

  get kind() {
    return this.isDegraded() ? 'memory-fallback' : this.primary.kind;
  }

  isDegraded() {
    return this.degradedUntil > this.now();
  }

  async call(method, ...args) {
    if (!this.isDegraded()) {
      try {
        return await this.primary[method](...args);
      } catch (error) {
        this.degradedUntil = this.now() + this.coolDownMs;
        this.logger?.warn({ err: error, coolDownMs: this.coolDownMs }, 'rate limit store unavailable, using in-memory fallback');
      }
    }
    return this.fallback[method](...args);
  }

  consume(key, options) {
    return this.call('consume', key, options);
  }

  isBlocked(key) {
    return this.call('isBlocked', key);
  }

  reset(key) {
    return this.call('reset', key);
  }
}

/**
 * The rate limiter used by the middleware.
 *
 * @param {{ store: object, config: { enabled: boolean, tiers: object, policies: object } }} options
 */
export function createRateLimiter({ store, config }) {
  return {
    store,
    config,

    /** Policy settings for a name, or undefined if the policy or the whole limiter is off. */
    policy(name) {
      if (!config.enabled) return undefined;
      const policy = config.policies[name];
      return policy && policy.enabled ? policy : undefined;
    },

    /**
     * Consume points for a subject under a policy.
     * @returns {Promise<{ limited: boolean, limit: number, remaining: number, resetSeconds: number } | undefined>}
     */
    async consume(policyName, subject, { tier = 'standard', cost = 1 } = {}) {
      const policy = this.policy(policyName);
      if (!policy) return undefined;
      const multiplier = config.tiers[tier] ?? config.tiers.standard ?? 1;
      const limit = Math.max(1, Math.floor(policy.points * multiplier));
      const result = await store.consume(`${policyName}:${subject}`, {
        windowMs: policy.durationSeconds * 1000,
        limit,
        blockMs: (policy.blockSeconds ?? 0) * 1000,
        cost,
      });
      const blocked = result.count === -1;
      return {
        limited: blocked || result.count > limit,
        limit,
        remaining: blocked ? 0 : Math.max(0, limit - result.count),
        resetSeconds: Math.max(1, Math.ceil(result.msBeforeReset / 1000)),
      };
    },

    /** True if the subject is currently blocked under the policy (does not consume). */
    async isBlocked(policyName, subject) {
      if (!this.policy(policyName)) return false;
      return store.isBlocked(`${policyName}:${subject}`);
    },
  };
}
