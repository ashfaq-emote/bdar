/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Scopes and party binding: what an authenticated API key may do.
 *
 * Authentication answers "who is calling". Authorization answers "may this caller
 * do this, for these parties". Both are checked on every request.
 */

import { apiError } from '../lib/errors.js';

/** Every scope the API knows, with the business role it maps to. */
export const Scopes = Object.freeze({
  REGISTRY_READ: 'registry:read',
  WALLET: 'wallet',
  ISSUER: 'issuer',
  EXECUTOR: 'executor',
  SUBMIT: 'submit',
  OPERATOR_READ: 'operator:read',
  OPERATOR_WRITE: 'operator:write',
  KEYS_MANAGE: 'keys:manage',
  AUDIT_READ: 'audit:read',
});

export const ALL_SCOPES = Object.freeze(Object.values(Scopes));

export const SCOPE_DESCRIPTIONS = Object.freeze({
  [Scopes.REGISTRY_READ]: 'Read registry and instrument metadata.',
  [Scopes.WALLET]: 'Wallet flows: transfer and allocation contexts, holdings, balances, accounts, for the allowed parties.',
  [Scopes.ISSUER]: 'Issuer flows: issuance context, mint requests, redemption decisions, for the allowed parties.',
  [Scopes.EXECUTOR]: 'Settlement app flows: settlement factory, cancel and execute transfer contexts, for the allowed parties.',
  [Scopes.SUBMIT]: 'Prepare and execute externally signed transactions for the allowed parties.',
  [Scopes.OPERATOR_READ]: 'Broadridge operations: read registry administration data and detailed health.',
  [Scopes.OPERATOR_WRITE]: 'Broadridge operations: submit commands as the registry admin party.',
  [Scopes.KEYS_MANAGE]: 'Create, rotate and revoke API keys.',
  [Scopes.AUDIT_READ]: 'Read the audit trail.',
});

/** Allowed parties value that means "any party". Only for internal operator keys. */
export const ANY_PARTY = '*';

/** Scopes that act for specific parties and therefore need a party list. */
export const PARTY_BOUND_SCOPES = Object.freeze([Scopes.WALLET, Scopes.ISSUER, Scopes.EXECUTOR, Scopes.SUBMIT]);

/** True if the key holds at least one of the scopes. */
export const hasAnyScope = (auth, scopes) => Boolean(auth) && scopes.some((scope) => auth.scopes.includes(scope));

/** Throw 403 unless the key holds at least one of the scopes. */
export function requireAnyScope(auth, scopes) {
  if (!hasAnyScope(auth, scopes)) {
    throw apiError('FORBIDDEN_SCOPE', undefined, { details: [{ requiredAnyOf: scopes }] });
  }
}

/** True if the key may act for the party. */
export const canActFor = (auth, party) =>
  Boolean(auth) && (auth.allowedParties.includes(ANY_PARTY) || auth.allowedParties.includes(party));

/**
 * Throw 403 unless the key may act for at least one of the parties.
 * Used where a request involves several parties and the caller must be one of them
 * (for example the sender or the receiver of a transfer).
 */
export function requireAnyParty(auth, parties) {
  const candidates = parties.filter(Boolean);
  if (candidates.length === 0 || !candidates.some((party) => canActFor(auth, party))) {
    throw apiError('FORBIDDEN_PARTY');
  }
}

/** Throw 403 unless the key may act for every one of the parties. */
export function requireAllParties(auth, parties) {
  const candidates = parties.filter(Boolean);
  if (candidates.length === 0 || !candidates.every((party) => canActFor(auth, party))) {
    throw apiError('FORBIDDEN_PARTY');
  }
}

/** Validate a scope list for a new or updated key. Returns a list of problems. */
export function validateKeyScopes(scopes, allowedParties) {
  const problems = [];
  if (!Array.isArray(scopes) || scopes.length === 0) problems.push('at least one scope is required');
  for (const scope of scopes ?? []) {
    if (!ALL_SCOPES.includes(scope)) problems.push(`unknown scope ${scope}`);
  }
  const needsParties = (scopes ?? []).some((scope) => PARTY_BOUND_SCOPES.includes(scope));
  if (needsParties && (!Array.isArray(allowedParties) || allowedParties.length === 0)) {
    problems.push(`scopes ${PARTY_BOUND_SCOPES.join(', ')} need at least one allowed party`);
  }
  return problems;
}

/**
 * A key manager may only grant what it holds itself (OWASP API5, broken function level
 * authorization). Without this rule a keys:manage key could mint an operator:write key.
 */
export function requireGrantable(auth, { scopes = [], allowedParties = [] }) {
  const missingScopes = scopes.filter((scope) => !auth.scopes.includes(scope));
  const missingParties = auth.allowedParties.includes(ANY_PARTY)
    ? []
    : allowedParties.filter((party) => !auth.allowedParties.includes(party));
  if (missingScopes.length > 0 || missingParties.length > 0) {
    throw apiError('FORBIDDEN_SCOPE', 'An API key can only grant scopes and parties it holds itself', {
      details: [{ missingScopes, missingParties }],
    });
  }
}
