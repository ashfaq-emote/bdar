/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * API key format, generation and hashing.
 *
 * A key looks like this (one line, 99 or 100 characters depending on the environment):
 *
 *   bdar_live_k3v9x2m7q4w8z1c6_<64 hex characters of secret>_<8 hex characters of checksum>
 *
 *   bdar      fixed prefix, so secret scanners (GitHub, GitLab) can find leaked keys
 *   live      environment: dev, test, uat or live. A dev key never works in live
 *   k3v9...   key id: public, 16 characters, used to find the key record
 *   secret    32 random bytes from the operating system CSPRNG, hex encoded
 *   checksum  CRC-32 of everything before it, so typos are rejected without a database call
 *
 * Only an HMAC-SHA256 of the secret is stored, keyed with a server side pepper
 * (API_KEY_PEPPER) that lives in the secrets manager, not in the database. A copy
 * of the database alone is therefore not enough to use or brute force keys.
 */

import { createHmac, randomBytes, randomInt, timingSafeEqual } from 'node:crypto';
import { crc32 } from 'node:zlib';

const PREFIX = 'bdar';
const KEY_ID_ALPHABET = 'abcdefghijklmnopqrstuvwxyz0123456789';
const KEY_ID_LENGTH = 16;
const SECRET_BYTES = 32;
const KEY_PATTERN = /^bdar_(dev|test|uat|live)_([a-z0-9]{16})_([0-9a-f]{64})_([0-9a-f]{8})$/;

/** Maximum accepted header length. Anything longer is rejected before parsing. */
export const MAX_API_KEY_LENGTH = 128;

const checksumOf = (text) => crc32(text).toString(16).padStart(8, '0');

/**
 * Create a new random key.
 * @param {string} environment dev | test | uat | live
 * @returns {{ keyId: string, secret: string, apiKey: string }}
 */
export function generateApiKey(environment) {
  let keyId = '';
  for (let i = 0; i < KEY_ID_LENGTH; i += 1) keyId += KEY_ID_ALPHABET[randomInt(KEY_ID_ALPHABET.length)];
  const secret = generateSecret();
  return { keyId, secret, apiKey: formatApiKey(environment, keyId, secret) };
}

/** 32 random bytes from the operating system CSPRNG, hex encoded. */
export const generateSecret = () => randomBytes(SECRET_BYTES).toString('hex');

/** Assemble the full key text, including the checksum. */
export function formatApiKey(environment, keyId, secret) {
  const body = `${PREFIX}_${environment}_${keyId}_${secret}`;
  return `${body}_${checksumOf(body)}`;
}

/**
 * Split a presented key into its parts. Returns undefined for anything that is not
 * a well formed key with a correct checksum.
 */
export function parseApiKey(apiKey) {
  if (typeof apiKey !== 'string' || apiKey.length > MAX_API_KEY_LENGTH) return undefined;
  const match = KEY_PATTERN.exec(apiKey);
  if (!match) return undefined;
  const [, environment, keyId, secret, checksum] = match;
  const body = `${PREFIX}_${environment}_${keyId}_${secret}`;
  if (checksumOf(body) !== checksum) return undefined;
  return { environment, keyId, secret };
}

/** HMAC-SHA256 of the secret, bound to the key id, keyed with the pepper. */
export function hashSecret(pepper, keyId, secret) {
  return createHmac('sha256', pepper).update(`${keyId}:${secret}`).digest();
}

/** Constant time comparison of a presented secret with a stored hash. */
export function secretMatches(pepper, keyId, secret, storedHash) {
  if (!storedHash) return false;
  const presented = hashSecret(pepper, keyId, secret);
  const stored = Buffer.isBuffer(storedHash) ? storedHash : Buffer.from(storedHash);
  return stored.length === presented.length && timingSafeEqual(stored, presented);
}

/** A short, non secret fingerprint that is safe to log: prefix, environment and key id. */
export function redactApiKey(apiKey) {
  const parsed = parseApiKey(apiKey);
  return parsed ? `bdar_${parsed.environment}_${parsed.keyId}_***` : '***';
}
