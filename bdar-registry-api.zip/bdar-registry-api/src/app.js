/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * The Express application. No network listeners, no process handling: server.js does
 * that. Tests build the app with in-memory dependencies and call it with supertest.
 *
 * Hardening applied here (see the OWASP section of the Technical Implementation Guide):
 *   - helmet: security headers; the API serves JSON only, so the CSP is "default-src 'none'".
 *   - x-powered-by off, ETags off, strict JSON body parsing with a size limit.
 *   - trust proxy set to an exact hop count, so req.ip is the real client behind the load balancer.
 *   - CORS closed unless origins are listed. Browsers should not call this API directly.
 *   - Cache-Control: no-store on every response.
 *   - One error format; no stack traces.
 */

import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import { pinoHttp } from 'pino-http';
import yaml from 'js-yaml';
import { rateLimit, requestId } from './security/middleware.js';
import { createRouter } from './http/router.js';
import { createValidator } from './http/validation.js';
import { errorHandler, notFound } from './http/errorHandler.js';
import { buildRoutes } from './http/routes.js';
import { buildOpenApiDocument } from './openapi/generate.js';

/**
 * @param {{ config: object, logger: object, dependencies: object, version: string }} options
 */
export function createApp({ config, logger, dependencies, version }) {
  const app = express();
  app.disable('x-powered-by');
  app.set('etag', false);
  app.set('trust proxy', config.server.trustProxyHops);
  app.set('query parser', 'simple');
  app.set('json escape', true);

  app.use(requestId());
  app.use(pinoHttp({
    logger,
    genReqId: (req) => req.id,
    customProps: (req) => ({ operationId: req.operationId, apiKeyId: req.auth?.keyId }),
    redact: { paths: ['req.headers["x-api-key"]', 'req.headers.authorization', 'req.headers.cookie'], censor: '[redacted]' },
    serializers: { req: (req) => ({ id: req.id, method: req.method, url: req.url.split('?')[0] }) },
    customLogLevel: (req, res, error) => (error || res.statusCode >= 500 ? 'error' : res.statusCode >= 400 ? 'warn' : 'info'),
  }));
  app.use(helmet({
    contentSecurityPolicy: { useDefaults: false, directives: { defaultSrc: ["'none'"], frameAncestors: ["'none'"] } },
    crossOriginResourcePolicy: { policy: 'same-origin' },
    hsts: { maxAge: 31536000, includeSubDomains: true, preload: false },
    referrerPolicy: { policy: 'no-referrer' },
  }));
  app.use(cors({
    origin: config.server.corsAllowedOrigins.length > 0 ? config.server.corsAllowedOrigins : false,
    methods: ['GET', 'POST', 'PUT', 'PATCH'],
    allowedHeaders: ['Content-Type', 'X-API-Key', 'Idempotency-Key', 'X-Request-Id'],
    exposedHeaders: ['X-Request-Id', 'RateLimit-Limit', 'RateLimit-Remaining', 'RateLimit-Reset', 'Retry-After', 'Idempotent-Replayed'],
    maxAge: 600,
  }));
  app.use((req, res, next) => {
    res.setHeader('Cache-Control', 'no-store');
    next();
  });
  app.use(express.json({ limit: config.server.requestBodyLimit, strict: true, type: 'application/json' }));

  const routes = buildRoutes();
  const { apiKeyService, rateLimiter, audit, idempotency, services } = dependencies;

  if (config.server.openApiPublic) {
    const document = buildOpenApiDocument({ routes, version, rateLimitPolicies: config.rateLimit.policies });
    const json = JSON.stringify(document, null, 2);
    const text = yaml.dump(document, { noRefs: true, lineWidth: 120 });
    const docLimit = rateLimit({ rateLimiter, policy: 'public' });
    app.get('/openapi.json', docLimit, (req, res) => res.type('application/json').send(json));
    app.get('/openapi.yaml', docLimit, (req, res) => res.type('application/yaml').send(text));
  }

  app.use(createRouter({
    routes, services, apiKeyService, rateLimiter, audit, idempotency, validator: createValidator(), logger,
  }));

  app.use(notFound());
  app.use(errorHandler({ logger }));
  return app;
}
