/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Configuration loading and validation.
 *
 * All settings come from environment variables (and one JSON file for rate limit
 * policies). The API refuses to start if any setting is missing or unsafe, so a
 * misconfiguration is found at deploy time, not in the middle of the night.
 */

import { readFileSync } from 'node:fs';
import path from 'node:path';

const ENVIRONMENTS = ['dev', 'test', 'uat', 'live'];
const LEDGER_AUTH_MODES = ['none', 'static', 'oauth2'];
const RATE_LIMIT_KEY_BY = ['ip', 'apiKey'];

/** Thrown when the configuration is invalid. Lists every problem at once. */
export class ConfigError extends Error {
  constructor(problems) {
    super(`Invalid configuration:\n - ${problems.join('\n - ')}`);
    this.name = 'ConfigError';
    this.problems = problems;
  }
}

/**
 * Load and validate the configuration.
 *
 * @param {Record<string, string | undefined>} env usually process.env
 * @param {{ cwd?: string, readFile?: (file: string) => string }} [options]
 * @returns {Readonly<object>} a deeply frozen configuration object
 */
export function loadConfig(env = process.env, options = {}) {
  const cwd = options.cwd ?? process.cwd();
  const readFile = options.readFile ?? ((file) => readFileSync(file, 'utf8'));
  const problems = [];
  const read = new EnvReader(env, problems);

  const nodeEnv = read.oneOf('NODE_ENV', ['development', 'test', 'production'], 'development');
  const isProduction = nodeEnv === 'production';

  const config = {
    nodeEnv,
    isProduction,
    server: {
      host: read.string('HOST', '0.0.0.0'),
      port: read.integer('PORT', 8080, { min: 1, max: 65535 }),
      trustProxyHops: read.integer('TRUST_PROXY_HOPS', 0, { min: 0, max: 10 }),
      requestBodyLimit: read.string('REQUEST_BODY_LIMIT', '512kb'),
      corsAllowedOrigins: read.list('CORS_ALLOWED_ORIGINS'),
      openApiPublic: read.boolean('OPENAPI_PUBLIC', !isProduction),
      tlsCertFile: read.optionalString('TLS_CERT_FILE'),
      tlsKeyFile: read.optionalString('TLS_KEY_FILE'),
      shutdownGraceMs: read.integer('SHUTDOWN_GRACE_MS', 15000, { min: 0 }),
    },
    logLevel: read.oneOf('LOG_LEVEL', ['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent'], 'info'),
    apiEnvironment: read.oneOf('API_ENVIRONMENT', ENVIRONMENTS, isProduction ? 'live' : 'dev'),
    registry: {
      adminParty: read.party('BDAR_ADMIN_PARTY'),
      registryName: read.string('BDAR_REGISTRY_NAME', 'Broadridge Digital Asset Registry'),
      packageName: read.string('BDAR_PACKAGE_NAME', 'broadridge-digital-asset-registry'),
      apiPackageName: read.string('BDAR_API_PACKAGE_NAME', 'broadridge-digital-asset-registry-api-v1'),
      credentialReadParties: read.list('BDAR_CREDENTIAL_READ_PARTIES'),
      contextCacheTtlMs: read.integer('CONTEXT_CACHE_TTL_MS', 1000, { min: 0, max: 60000 }),
      maxSettlementAllocations: read.integer('MAX_SETTLEMENT_ALLOCATIONS', 100, { min: 1, max: 1000 }),
    },
    ledger: {
      baseUrl: read.url('LEDGER_JSON_API_URL'),
      userId: read.string('LEDGER_USER_ID', 'bdar-registry-api'),
      authMode: read.oneOf('LEDGER_AUTH_MODE', LEDGER_AUTH_MODES, 'none'),
      staticToken: read.optionalString('LEDGER_STATIC_TOKEN'),
      oauth: {
        tokenUrl: read.optionalString('OAUTH_TOKEN_URL'),
        clientId: read.optionalString('OAUTH_CLIENT_ID'),
        clientSecret: read.optionalString('OAUTH_CLIENT_SECRET'),
        audience: read.optionalString('OAUTH_AUDIENCE'),
        scope: read.optionalString('OAUTH_SCOPE'),
      },
      timeoutMs: read.integer('LEDGER_TIMEOUT_MS', 15000, { min: 1000, max: 120000 }),
      acsLimit: read.integer('LEDGER_ACS_LIMIT', 10000, { min: 1 }),
    },
    database: {
      url: read.optionalString('DATABASE_URL'),
      ssl: read.boolean('DATABASE_SSL', isProduction),
      poolMax: read.integer('DATABASE_POOL_MAX', 10, { min: 1, max: 100 }),
    },
    apiKeys: {
      pepper: read.optionalString('API_KEY_PEPPER'),
      cacheTtlMs: read.integer('API_KEY_CACHE_TTL_MS', 30000, { min: 0, max: 300000 }),
      rotationOverlapHours: read.integer('API_KEY_ROTATION_OVERLAP_HOURS', 24, { min: 0, max: 720 }),
      header: 'x-api-key',
    },
    idempotency: {
      ttlHours: read.integer('IDEMPOTENCY_TTL_HOURS', 24, { min: 1, max: 720 }),
    },
    rateLimit: null,
    redis: {
      url: read.optionalString('REDIS_URL'),
      keyPrefix: read.string('REDIS_KEY_PREFIX', 'bdar:rl:'),
      commandTimeoutMs: read.integer('REDIS_COMMAND_TIMEOUT_MS', 200, { min: 10, max: 5000 }),
    },
  };

  // Cross field rules.
  if (config.ledger.authMode === 'static' && !config.ledger.staticToken) {
    problems.push('LEDGER_STATIC_TOKEN is required when LEDGER_AUTH_MODE=static');
  }
  if (config.ledger.authMode === 'oauth2') {
    for (const [name, value] of [
      ['OAUTH_TOKEN_URL', config.ledger.oauth.tokenUrl],
      ['OAUTH_CLIENT_ID', config.ledger.oauth.clientId],
      ['OAUTH_CLIENT_SECRET', config.ledger.oauth.clientSecret],
    ]) {
      if (!value) problems.push(`${name} is required when LEDGER_AUTH_MODE=oauth2`);
    }
  }
  if (!config.apiKeys.pepper || Buffer.byteLength(config.apiKeys.pepper) < 32) {
    problems.push('API_KEY_PEPPER must be set and at least 32 bytes long');
  }
  if (isProduction) {
    if (!config.database.url) problems.push('DATABASE_URL is required in production');
    if (config.ledger.authMode === 'none') problems.push('LEDGER_AUTH_MODE=none is not allowed in production');
    if (config.apiEnvironment !== 'live' && config.apiEnvironment !== 'uat') {
      problems.push('API_ENVIRONMENT must be live or uat in production');
    }
    if (config.ledger.baseUrl && config.ledger.baseUrl.startsWith('http://') && !read.boolean('ALLOW_PLAINTEXT_LEDGER', false)) {
      problems.push('LEDGER_JSON_API_URL must use https in production (set ALLOW_PLAINTEXT_LEDGER=true only for a sidecar on localhost)');
    }
    if (config.server.corsAllowedOrigins.includes('*')) problems.push('CORS_ALLOWED_ORIGINS must not contain * in production');
  }
  if (Boolean(config.server.tlsCertFile) !== Boolean(config.server.tlsKeyFile)) {
    problems.push('TLS_CERT_FILE and TLS_KEY_FILE must be set together');
  }

  config.rateLimit = loadRateLimitConfig(env, read, problems, { cwd, readFile });

  if (problems.length > 0) throw new ConfigError(problems);
  return deepFreeze(config);
}

/**
 * Rate limit policies: defaults from the JSON file, then environment overrides.
 * Environment names use upper snake case of the policy name, for example
 * RATE_LIMIT_AUTH_FAILURE_POINTS for the policy "authFailure".
 */
function loadRateLimitConfig(env, read, problems, { cwd, readFile }) {
  const file = read.string('RATE_LIMIT_CONFIG_FILE', 'config/rate-limits.json');
  let fromFile;
  try {
    fromFile = JSON.parse(readFile(path.resolve(cwd, file)));
  } catch (error) {
    problems.push(`RATE_LIMIT_CONFIG_FILE could not be read (${file}): ${error.message}`);
    return { enabled: false, tiers: {}, policies: {} };
  }

  const enabled = read.boolean('RATE_LIMIT_ENABLED', fromFile.enabled !== false);
  const tiers = { ...(fromFile.tiers ?? {}) };
  for (const [tier, multiplier] of Object.entries(tiers)) {
    if (typeof multiplier !== 'number' || multiplier <= 0) problems.push(`rate limit tier ${tier} must have a positive multiplier`);
  }
  if (!tiers.standard) tiers.standard = 1;

  const policies = {};
  for (const [name, policy] of Object.entries(fromFile.policies ?? {})) {
    const envName = `RATE_LIMIT_${name.replace(/([a-z])([A-Z])/g, '$1_$2').toUpperCase()}`;
    const merged = {
      enabled: read.boolean(`${envName}_ENABLED`, policy.enabled !== false),
      points: read.integer(`${envName}_POINTS`, policy.points, { min: 1 }),
      durationSeconds: read.integer(`${envName}_DURATION_SECONDS`, policy.durationSeconds, { min: 1 }),
      blockSeconds: read.integer(`${envName}_BLOCK_SECONDS`, policy.blockSeconds ?? 0, { min: 0 }),
      keyBy: policy.keyBy,
      description: policy.description ?? '',
    };
    if (!RATE_LIMIT_KEY_BY.includes(merged.keyBy)) problems.push(`rate limit policy ${name}: keyBy must be ip or apiKey`);
    policies[name] = merged;
  }
  for (const required of ['public', 'authFailure', 'metadata', 'context', 'query', 'submission', 'operator', 'keys']) {
    if (!policies[required]) problems.push(`rate limit policy ${required} is missing from ${file}`);
  }
  return { enabled, tiers, policies };
}

/** Small helper that reads typed values and collects problems instead of throwing. */
class EnvReader {
  constructor(env, problems) {
    this.env = env;
    this.problems = problems;
  }

  raw(name) {
    const value = this.env[name];
    return value === undefined || value.trim() === '' ? undefined : value.trim();
  }

  string(name, fallback) {
    const value = this.raw(name);
    if (value !== undefined) return value;
    if (fallback === undefined) this.problems.push(`${name} is required`);
    return fallback;
  }

  optionalString(name) {
    return this.raw(name);
  }

  integer(name, fallback, { min = Number.MIN_SAFE_INTEGER, max = Number.MAX_SAFE_INTEGER } = {}) {
    const value = this.raw(name);
    if (value === undefined) {
      if (fallback === undefined) this.problems.push(`${name} is required`);
      return fallback;
    }
    if (!/^-?\d+$/.test(value)) {
      this.problems.push(`${name} must be a whole number`);
      return fallback;
    }
    const parsed = Number(value);
    if (parsed < min || parsed > max) this.problems.push(`${name} must be between ${min} and ${max}`);
    return parsed;
  }

  boolean(name, fallback) {
    const value = this.raw(name);
    if (value === undefined) return fallback;
    if (['true', '1', 'yes'].includes(value.toLowerCase())) return true;
    if (['false', '0', 'no'].includes(value.toLowerCase())) return false;
    this.problems.push(`${name} must be true or false`);
    return fallback;
  }

  oneOf(name, allowed, fallback) {
    const value = this.raw(name) ?? fallback;
    if (!allowed.includes(value)) this.problems.push(`${name} must be one of ${allowed.join(', ')}`);
    return value;
  }

  list(name) {
    const value = this.raw(name);
    return value === undefined ? [] : value.split(',').map((item) => item.trim()).filter(Boolean);
  }

  url(name) {
    const value = this.string(name);
    if (value === undefined) return undefined;
    try {
      const parsed = new URL(value);
      if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error('protocol');
      return value.replace(/\/+$/, '');
    } catch {
      this.problems.push(`${name} must be an http or https URL`);
      return undefined;
    }
  }

  party(name) {
    const value = this.string(name);
    if (value !== undefined && !/^[^\s]{1,255}::[^\s]+$/.test(value)) {
      this.problems.push(`${name} must be a full party id (hint::fingerprint)`);
    }
    return value;
  }
}

function deepFreeze(value) {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) deepFreeze(child);
  }
  return value;
}
