/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Client for the Canton JSON Ledger API v2.
 *
 * Only the endpoints the registry API needs are wrapped:
 *   GET  /v2/version                                     readiness
 *   GET  /v2/state/ledger-end                            readiness and ACS snapshots
 *   POST /v2/state/active-contracts                      read active contracts (ACS)
 *   POST /v2/events/events-by-contract-id                read one contract by id
 *   POST /v2/commands/submit-and-wait-for-transaction    operator commands as the admin party
 *   POST /v2/interactive-submission/prepare              prepare a transaction for an external signer
 *   POST /v2/interactive-submission/executeAndWait       execute a signed prepared transaction
 *
 * The URL comes from configuration only. No request ever makes this client call a
 * URL supplied by an API caller (OWASP API7, server side request forgery).
 */

import { apiError } from '../lib/errors.js';
import { noopLogger } from '../lib/util.js';

/** An error returned by the JSON Ledger API, with the Canton error details kept. */
export class LedgerError extends Error {
  constructor({ httpStatus, cantonError, message, cause }) {
    super(message ?? cantonError?.cause ?? `ledger request failed with HTTP ${httpStatus}`, { cause });
    this.name = 'LedgerError';
    this.httpStatus = httpStatus;
    this.cantonError = cantonError;
    this.code = cantonError?.code;
  }
}

const BDAR_ERROR_ID = /broadridge\.com\/bdar\/[a-z0-9-]+/;

/** Find a Broadridge registry error id (for example broadridge.com/bdar/account-frozen) in a Canton error. */
export function extractBdarErrorId(cantonError) {
  if (!cantonError) return undefined;
  const haystack = [cantonError.cause, ...Object.values(cantonError.context ?? {}), JSON.stringify(cantonError.resources ?? [])]
    .filter((item) => typeof item === 'string');
  for (const text of haystack) {
    const match = BDAR_ERROR_ID.exec(text);
    if (match) return match[0];
  }
  return undefined;
}

/**
 * Turn a ledger failure into an API error the client can act on.
 *   - Daml rejections (including Broadridge error ids) become 409 LEDGER_REJECTED, or 400 for argument errors.
 *   - Contract not found (a stale context) becomes 409 STALE_CONTRACT.
 *   - Timeouts become 504, connection failures 503, anything else 502.
 */
export function toApiError(error) {
  if (!(error instanceof LedgerError)) {
    if (error?.name === 'TimeoutError' || error?.name === 'AbortError') return apiError('LEDGER_TIMEOUT', undefined, { cause: error });
    if (error?.cause?.code === 'ECONNREFUSED' || error instanceof TypeError) return apiError('LEDGER_UNAVAILABLE', undefined, { cause: error });
    return apiError('LEDGER_ERROR', undefined, { cause: error });
  }
  const canton = error.cantonError;
  const bdarErrorId = extractBdarErrorId(canton);
  const code = canton?.code ?? '';
  const extra = {
    ledgerError: {
      code: code || undefined,
      errorId: bdarErrorId,
      cause: canton?.cause ? String(canton.cause).slice(0, 500) : undefined,
      correlationId: canton?.correlationId,
    },
  };
  if (/CONTRACT_NOT_FOUND|CONTRACT_NOT_ACTIVE|INCONSISTENT_CONTRACT/.test(code)) {
    return apiError('STALE_CONTRACT', undefined, { cause: error, extra });
  }
  if (/CONTRACT_EVENTS_NOT_FOUND/.test(code)) return apiError('CONTRACT_NOT_FOUND', undefined, { cause: error });
  if (/DUPLICATE_COMMAND|SUBMISSION_ALREADY_IN_FLIGHT/.test(code)) {
    return apiError('CONFLICT', 'The ledger already accepted or is processing this command. Check the result before retrying', { cause: error, extra });
  }
  if (error.httpStatus === 401 || error.httpStatus === 403) return apiError('LEDGER_ERROR', 'The registry API is not authorized on the ledger', { cause: error });
  if (bdarErrorId || /DAML_FAILURE|INTERPRETATION|UNHANDLED_EXCEPTION|DAML_AUTHORIZATION/.test(code)) {
    const argumentError = /invalid-argument|amount-precision|ttl-too-long/.test(bdarErrorId ?? '');
    return apiError('LEDGER_REJECTED', undefined, { status: argumentError ? 400 : 409, cause: error, extra });
  }
  if (error.httpStatus === 400) return apiError('VALIDATION_FAILED', 'The ledger refused the request format', { cause: error, extra });
  if (error.httpStatus === 503 || error.httpStatus === 429) return apiError('LEDGER_UNAVAILABLE', undefined, { cause: error });
  return apiError('LEDGER_ERROR', undefined, { cause: error, extra });
}

/**
 * @param {{ baseUrl: string, userId: string, timeoutMs: number, acsLimit: number,
 *           tokenProvider: { getToken(): Promise<string|undefined> }, fetchImpl?: typeof fetch, logger?: object }} options
 */
export function createLedgerClient({ baseUrl, userId, timeoutMs, acsLimit, tokenProvider, fetchImpl = fetch, logger = noopLogger }) {
  async function request(method, path, { body, query, timeout = timeoutMs } = {}) {
    const url = new URL(baseUrl + path);
    for (const [key, value] of Object.entries(query ?? {})) url.searchParams.set(key, String(value));
    const headers = { accept: 'application/json' };
    const token = await tokenProvider.getToken();
    if (token) headers.authorization = `Bearer ${token}`;
    if (body !== undefined) headers['content-type'] = 'application/json';
    const started = Date.now();
    let response;
    try {
      response = await fetchImpl(url, {
        method,
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: AbortSignal.timeout(timeout),
      });
    } catch (error) {
      logger.warn({ err: error, path, durationMs: Date.now() - started }, 'ledger request failed');
      throw error;
    }
    const text = await response.text();
    logger.debug({ path, status: response.status, durationMs: Date.now() - started }, 'ledger request');
    if (!response.ok) {
      let cantonError;
      try {
        cantonError = JSON.parse(text);
      } catch {
        cantonError = { code: `HTTP_${response.status}`, cause: text.slice(0, 500) };
      }
      if (response.status === 401) tokenProvider.invalidate?.();
      throw new LedgerError({ httpStatus: response.status, cantonError });
    }
    return text.length > 0 ? JSON.parse(text) : {};
  }

  /** Event format that reads as the given parties, for templates and/or interfaces. */
  function eventFormat(parties, { templateIds = [], interfaceIds = [], includeBlob = true, includeViews = true } = {}) {
    const cumulative = [
      ...templateIds.map((templateId) => ({
        identifierFilter: { TemplateFilter: { value: { templateId, includeCreatedEventBlob: includeBlob } } },
      })),
      ...interfaceIds.map((interfaceId) => ({
        identifierFilter: {
          InterfaceFilter: { value: { interfaceId, includeInterfaceView: includeViews, includeCreatedEventBlob: includeBlob } },
        },
      })),
    ];
    if (cumulative.length === 0) {
      cumulative.push({ identifierFilter: { WildcardFilter: { value: { includeCreatedEventBlob: includeBlob } } } });
    }
    return {
      filtersByParty: Object.fromEntries(parties.map((party) => [party, { cumulative }])),
      verbose: false,
    };
  }

  return {
    eventFormat,

    version() {
      return request('GET', '/v2/version', { timeout: Math.min(timeoutMs, 5000) });
    },

    async ledgerEnd() {
      const result = await request('GET', '/v2/state/ledger-end', { timeout: Math.min(timeoutMs, 5000) });
      return Number(result.offset ?? 0);
    },

    /**
     * Active contracts visible to `parties` at `activeAtOffset` (default: ledger end).
     * @returns {Promise<{ offset: number, contracts: Array<{ createdEvent: object, synchronizerId: string }> }>}
     */
    async activeContracts({ parties, templateIds, interfaceIds, activeAtOffset, includeBlob = true }) {
      const offset = activeAtOffset ?? (await this.ledgerEnd());
      if (offset === 0) return { offset, contracts: [] };
      const result = await request('POST', '/v2/state/active-contracts', {
        query: { limit: acsLimit },
        body: { activeAtOffset: offset, eventFormat: eventFormat(parties, { templateIds, interfaceIds, includeBlob }) },
      });
      const contracts = (Array.isArray(result) ? result : [])
        .map((entry) => entry.contractEntry?.JsActiveContract)
        .filter(Boolean);
      if (contracts.length >= acsLimit) {
        logger.warn({ templateIds, interfaceIds, acsLimit }, 'active contract query reached LEDGER_ACS_LIMIT; results may be incomplete');
      }
      return { offset, contracts };
    },

    /** The create event of a contract if it exists and is not archived, else undefined. */
    async activeContractById(contractId, parties) {
      try {
        const result = await request('POST', '/v2/events/events-by-contract-id', {
          body: { contractId, eventFormat: eventFormat(parties) },
        });
        if (!result.created || result.archived) return undefined;
        return { createdEvent: result.created.createdEvent, synchronizerId: result.created.synchronizerId };
      } catch (error) {
        if (error instanceof LedgerError && (error.httpStatus === 404 || /CONTRACT_EVENTS_NOT_FOUND/.test(error.code ?? ''))) {
          return undefined;
        }
        throw error;
      }
    },

    /** Submit commands as the given parties and return the resulting transaction (ledger effects shape). */
    async submitAndWaitForTransaction({ actAs, readAs = [], commandId, commands, disclosedContracts = [] }) {
      const result = await request('POST', '/v2/commands/submit-and-wait-for-transaction', {
        body: {
          commands: { commands, commandId, actAs, readAs, userId, disclosedContracts },
          transactionFormat: {
            transactionShape: 'TRANSACTION_SHAPE_LEDGER_EFFECTS',
            eventFormat: eventFormat(actAs, { includeBlob: false }),
          },
        },
      });
      return result.transaction;
    },

    /** Prepare a transaction that an external party signs. */
    prepare({ actAs, readAs = [], commandId, commands, disclosedContracts = [], synchronizerId }) {
      return request('POST', '/v2/interactive-submission/prepare', {
        body: {
          userId, commandId, commands, actAs, readAs, disclosedContracts,
          ...(synchronizerId ? { synchronizerId } : {}),
          packageIdSelectionPreference: [],
          verboseHashing: false,
        },
      });
    },

    /** Execute a signed prepared transaction and wait for the result. */
    executeAndWait({ preparedTransaction, partySignatures, submissionId, hashingSchemeVersion }) {
      return request('POST', '/v2/interactive-submission/executeAndWait', {
        body: {
          userId, preparedTransaction, partySignatures, submissionId, hashingSchemeVersion,
          deduplicationPeriod: { Empty: {} },
        },
      });
    },
  };
}

/**
 * Access tokens for the ledger.
 *   none    no Authorization header (local sandbox only)
 *   static  a fixed token (short lived test environments)
 *   oauth2  OAuth 2.0 client credentials; the token is cached and refreshed 60 seconds before expiry
 */
export function createTokenProvider(ledgerConfig, { fetchImpl = fetch, now = () => Date.now() } = {}) {
  if (ledgerConfig.authMode === 'none') return { async getToken() { return undefined; } };
  if (ledgerConfig.authMode === 'static') return { async getToken() { return ledgerConfig.staticToken; } };

  let cached;
  let inFlight;
  const { tokenUrl, clientId, clientSecret, audience, scope } = ledgerConfig.oauth;
  async function fetchToken() {
    const form = new URLSearchParams({ grant_type: 'client_credentials', client_id: clientId, client_secret: clientSecret });
    if (audience) form.set('audience', audience);
    if (scope) form.set('scope', scope);
    const response = await fetchImpl(tokenUrl, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded', accept: 'application/json' },
      body: form,
      signal: AbortSignal.timeout(10000),
    });
    if (!response.ok) throw new LedgerError({ httpStatus: response.status, message: `token endpoint returned HTTP ${response.status}` });
    const json = await response.json();
    cached = { token: json.access_token, expiresAt: now() + Math.max(60, Number(json.expires_in ?? 300)) * 1000 };
    return cached.token;
  }
  return {
    async getToken() {
      if (cached && cached.expiresAt - 60000 > now()) return cached.token;
      inFlight ??= fetchToken().finally(() => { inFlight = undefined; });
      return inFlight;
    },
    invalidate() {
      cached = undefined;
    },
  };
}
