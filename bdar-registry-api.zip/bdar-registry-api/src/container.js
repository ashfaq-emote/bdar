/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Composition root: creates every dependency from the configuration and wires them
 * together. Nothing else in the code base creates clients or reads configuration.
 *
 * Storage choices:
 *   DATABASE_URL set    PostgreSQL repositories (required in production)
 *   DATABASE_URL unset  in-memory repositories (local development only; keys vanish on restart)
 *   REDIS_URL set       Redis rate limit store with in-memory fallback
 *   REDIS_URL unset     in-memory rate limit store (one instance only)
 *
 * pg and ioredis are imported on demand so that tests and local runs without them
 * never load those modules.
 */

import { createLedgerClient, createTokenProvider } from './ledger/ledgerClient.js';
import { createIdentifiers } from './registry/daml.js';
import { createLedgerContractReader } from './registry/contractReader.js';
import { createContextBuilder } from './registry/contextBuilder.js';
import { createMemoryApiKeyRepository, createMemoryAuditRepository, createMemoryIdempotencyRepository } from './repositories/memory.js';
import { FallbackStore, MemoryStore, RedisStore, createRateLimiter } from './security/rateLimiter.js';
import { createApiKeyService } from './services/apiKeyService.js';
import { createAuditService, createIdempotencyService } from './services/supportServices.js';
import { createTokenStandardService } from './services/tokenStandardService.js';
import { createBdarService } from './services/bdarService.js';
import { createSubmissionService } from './services/submissionService.js';
import { createOperatorService } from './services/operatorService.js';
import { createHealthService } from './services/healthService.js';

/**
 * @param {{ config: object, logger: object, version: string, overrides?: { ledger?: object, fetchImpl?: typeof fetch,
 *           repositories?: object, rateLimitStore?: object, now?: () => Date } }} options
 */
export async function createDependencies({ config, logger, version, overrides = {} }) {
  const closers = [];
  const now = overrides.now ?? (() => new Date());

  // ----------------------------------------------------------------- storage
  let repositories = overrides.repositories;
  if (!repositories && config.database.url) {
    const { default: pg } = await import('pg');
    const { createPostgresApiKeyRepository, createPostgresAuditRepository, createPostgresIdempotencyRepository } = await import('./repositories/postgres.js');
    const pool = new pg.Pool({
      connectionString: config.database.url,
      max: config.database.poolMax,
      ssl: config.database.ssl ? { rejectUnauthorized: true } : undefined,
      statement_timeout: 5000,
      idleTimeoutMillis: 30000,
      application_name: 'bdar-registry-api',
    });
    pool.on('error', (error) => logger.error({ err: error }, 'PostgreSQL pool error'));
    closers.push(() => pool.end());
    repositories = {
      apiKeys: createPostgresApiKeyRepository(pool),
      audit: createPostgresAuditRepository(pool),
      idempotency: createPostgresIdempotencyRepository(pool),
    };
  }
  if (!repositories) {
    logger.warn('DATABASE_URL is not set: using in-memory API keys, audit and idempotency (development only)');
    repositories = {
      apiKeys: createMemoryApiKeyRepository(),
      audit: createMemoryAuditRepository(),
      idempotency: createMemoryIdempotencyRepository(),
    };
  }

  // -------------------------------------------------------------- rate limits
  let rateLimitStore = overrides.rateLimitStore;
  if (!rateLimitStore && config.redis.url && config.rateLimit.enabled) {
    const { default: Redis } = await import('ioredis');
    const redis = new Redis(config.redis.url, {
      commandTimeout: config.redis.commandTimeoutMs,
      maxRetriesPerRequest: 1,
      enableOfflineQueue: false,
      lazyConnect: false,
    });
    redis.on('error', (error) => logger.warn({ err: error }, 'Redis error'));
    closers.push(() => redis.quit());
    rateLimitStore = new FallbackStore({ primary: new RedisStore({ redis, keyPrefix: config.redis.keyPrefix }), logger });
  }
  rateLimitStore ??= new MemoryStore();
  const rateLimiter = createRateLimiter({ store: rateLimitStore, config: config.rateLimit });

  // ------------------------------------------------------------------- ledger
  const ledger = overrides.ledger ?? createLedgerClient({
    baseUrl: config.ledger.baseUrl,
    userId: config.ledger.userId,
    timeoutMs: config.ledger.timeoutMs,
    acsLimit: config.ledger.acsLimit,
    tokenProvider: createTokenProvider(config.ledger, { fetchImpl: overrides.fetchImpl }),
    fetchImpl: overrides.fetchImpl,
    logger: logger.child({ component: 'ledger' }),
  });
  const identifiers = createIdentifiers(config.registry);
  const adminParty = config.registry.adminParty;
  const reader = createLedgerContractReader({
    ledger, adminParty, identifiers,
    cacheTtlMs: config.registry.contextCacheTtlMs,
    credentialReadParties: config.registry.credentialReadParties,
    logger: logger.child({ component: 'reader' }),
  });
  const contextBuilder = createContextBuilder({ reader, adminParty, now });

  // ----------------------------------------------------------------- services
  const audit = createAuditService({ repository: repositories.audit, logger });
  const idempotency = createIdempotencyService({ repository: repositories.idempotency, ttlHours: config.idempotency.ttlHours, now });
  const apiKeyService = createApiKeyService({ repository: repositories.apiKeys, config, audit, logger, now });

  const services = {
    apiKeys: apiKeyService,
    audit,
    tokenStandard: createTokenStandardService({ reader, contextBuilder, adminParty, maxSettlementAllocations: config.registry.maxSettlementAllocations, now }),
    bdar: createBdarService({ reader, contextBuilder, identifiers, adminParty, now }),
    submissions: createSubmissionService({ ledger, reader, adminParty, packageName: config.registry.packageName }),
    operator: createOperatorService({ ledger, reader, contextBuilder, identifiers, config, now }),
    health: createHealthService({ ledger, apiKeyRepository: repositories.apiKeys, rateLimitStore, reader, config, version, logger, now }),
  };

  // Housekeeping of the idempotency table once an hour.
  const purgeTimer = setInterval(() => {
    repositories.idempotency.purgeExpired().catch((error) => logger.warn({ err: error }, 'idempotency purge failed'));
  }, 3600000);
  purgeTimer.unref();
  closers.push(() => clearInterval(purgeTimer));

  return {
    ledger, reader, contextBuilder, identifiers, repositories, rateLimiter, rateLimitStore, audit, idempotency, apiKeyService, services,
    async close() {
      for (const close of closers.reverse()) {
        try {
          await close();
        } catch (error) {
          logger.warn({ err: error }, 'error while closing a dependency');
        }
      }
    },
  };
}
