/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Builds the OpenAPI 3.0.3 document from the route table and the component schemas.
 *
 * `npm run openapi` writes openapi/bdar-registry-api.yaml and .json.
 * `npm run openapi -- --check` fails if the committed files are out of date (use in CI).
 */

import { ErrorCodes } from '../lib/errors.js';
import { SCOPE_DESCRIPTIONS } from '../security/scopes.js';
import { schemas } from '../http/schemas.js';
import { TAG_DESCRIPTIONS } from '../http/routes.js';

const ERROR_DESCRIPTIONS = {
  400: 'The request is not valid (VALIDATION_FAILED, INVALID_JSON, WRONG_ADMIN, IDEMPOTENCY_KEY_REQUIRED).',
  401: 'No API key, or the key is not valid (AUTH_MISSING_API_KEY, AUTH_INVALID_API_KEY).',
  403: 'The key lacks the scope or may not act for the party (FORBIDDEN_SCOPE, FORBIDDEN_PARTY, TEMPLATE_NOT_ALLOWED, NOT_ISSUER).',
  404: 'The resource does not exist or is no longer active.',
  405: 'The method is not allowed on this path.',
  409: 'Conflict with the current state: stale contract, ledger rejection, idempotency conflict, duplicate resource.',
  413: 'The request body is larger than REQUEST_BODY_LIMIT.',
  415: 'The request body is not application/json.',
  429: 'Rate limited. Retry after the number of seconds in Retry-After.',
  500: 'Unexpected error. Quote the requestId to support.',
  502: 'The ledger returned an unexpected error.',
  503: 'The ledger or a dependency is not available, or the registry is not bootstrapped.',
  504: 'The ledger did not answer in time. The command may still complete; retry with the same Idempotency-Key.',
};

const RATE_LIMIT_HEADERS = {
  'RateLimit-Limit': { description: 'Requests allowed in the current window for this policy.', schema: { type: 'integer' } },
  'RateLimit-Remaining': { description: 'Requests left in the current window.', schema: { type: 'integer' } },
  'RateLimit-Reset': { description: 'Seconds until the window resets.', schema: { type: 'integer' } },
  'X-Request-Id': { description: 'Request id. Send your own (8 to 128 of A-Z a-z 0-9 . _ -) to trace a call end to end.', schema: { type: 'string' } },
};

export function buildOpenApiDocument({ routes, version, rateLimitPolicies = {} }) {
  const paths = {};
  for (const route of routes) {
    const operation = {
      operationId: route.operationId,
      tags: [route.tag],
      summary: route.summary,
      description: [
        route.description,
        route.standard ? `Standard: ${route.standard}.` : undefined,
        route.auth === 'apiKey' && route.scopes?.length ? `Scopes (any of): ${route.scopes.join(', ')}.` : undefined,
        route.rateLimit ? `Rate limit policy: ${route.rateLimit}${rateLimitPolicies[route.rateLimit] ? ` (${rateLimitPolicies[route.rateLimit].points} per ${rateLimitPolicies[route.rateLimit].durationSeconds} s by default)` : ''}.` : undefined,
        route.idempotent ? 'Idempotent: requires the Idempotency-Key header.' : undefined,
      ].filter(Boolean).join('\n\n'),
      security: route.auth === 'apiKey' ? [{ ApiKeyAuth: [] }] : [],
      'x-bdar-scopes': route.scopes ?? [],
      'x-bdar-rate-limit-policy': route.rateLimit,
      'x-bdar-idempotent': Boolean(route.idempotent),
    };
    if (route.parameters?.length) operation.parameters = route.parameters;
    if (route.body) {
      operation.requestBody = {
        required: !route.bodyOptional,
        content: { 'application/json': { schema: { $ref: `#/components/schemas/${route.body}` } } },
      };
    }
    operation.responses = {};
    for (const [status, schemaName] of Object.entries(route.responses)) {
      operation.responses[status] = {
        description: Number(status) < 300 ? 'Success' : ERROR_DESCRIPTIONS[status] ?? 'Error',
        headers: RATE_LIMIT_HEADERS,
        content: { 'application/json': { schema: { $ref: `#/components/schemas/${schemaName}` } } },
      };
    }
    for (const status of route.errors ?? []) {
      if (!operation.responses[status]) operation.responses[status] = { $ref: `#/components/responses/Error${status}` };
    }
    paths[route.path] ??= {};
    paths[route.path][route.method] = operation;
  }

  const responses = Object.fromEntries(Object.entries(ERROR_DESCRIPTIONS).map(([status, description]) => [
    `Error${status}`,
    {
      description,
      headers: status === '429' || status === '503'
        ? { 'Retry-After': { description: 'Seconds to wait before retrying.', schema: { type: 'integer' } }, 'X-Request-Id': RATE_LIMIT_HEADERS['X-Request-Id'] }
        : { 'X-Request-Id': RATE_LIMIT_HEADERS['X-Request-Id'] },
      content: { 'application/json': { schema: { $ref: '#/components/schemas/Error' } } },
    },
  ]));

  const usedTags = [...new Set(routes.map((route) => route.tag))];
  return {
    openapi: '3.0.3',
    info: {
      title: 'Broadridge Digital Asset Registry (BDAR) Registry API',
      version,
      description: [
        'HTTP API of the Broadridge Digital Asset Registry for CIP-56 (token standard V1) and CIP-112 (token standard V2) tokens.',
        '',
        'Authentication: send your API key in the `X-API-Key` header on every call except ping and the health probes. '
          + 'Keys are scoped (see the scope list below) and bound to the parties they may act for.',
        '',
        'Scopes:',
        ...Object.entries(SCOPE_DESCRIPTIONS).map(([scope, description]) => `- \`${scope}\`: ${description}`),
        '',
        'Errors always use the `Error` schema. Match on `code`. Codes: '
          + Object.keys(ErrorCodes).map((code) => `\`${code}\``).join(', ') + '.',
        '',
        'Rate limits: every response of a limited operation carries `RateLimit-Limit`, `RateLimit-Remaining` and `RateLimit-Reset`. '
          + 'A 429 carries `Retry-After`.',
        '',
        'Party ids contain `::`. URL encode them in paths and query strings.',
      ].join('\n'),
      contact: { name: 'Broadridge Digital Asset Registry team' },
      license: { name: 'Proprietary. Copyright (c) 2026 Broadridge Financial Solutions, Inc.' },
    },
    servers: [
      { url: '{baseUrl}', variables: { baseUrl: { default: 'https://bdar-api.example.broadridge.com', description: 'The API base URL of your environment.' } } },
    ],
    tags: usedTags.map((name) => ({ name, description: TAG_DESCRIPTIONS[name] })),
    paths,
    components: {
      securitySchemes: {
        ApiKeyAuth: {
          type: 'apiKey',
          in: 'header',
          name: 'X-API-Key',
          description: 'Format: bdar_<environment>_<key id>_<secret>_<checksum>. Never put the key in a URL.',
        },
      },
      schemas,
      responses,
    },
  };
}
