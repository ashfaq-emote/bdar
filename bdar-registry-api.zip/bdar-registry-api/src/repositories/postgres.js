/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * PostgreSQL repositories for API keys, audit events and idempotency records.
 *
 * Every query uses parameters ($1, $2, ...). Values are never concatenated into
 * SQL text, which rules out SQL injection. The only dynamic SQL is the column list of
 * an update, and those names come from the UPDATABLE_API_KEY_FIELDS allow list.
 *
 * jsonb values are passed as JSON text: node-postgres would otherwise turn a
 * JavaScript array into a PostgreSQL array literal.
 */

const API_KEY_COLUMNS = `
  id, key_id, environment, secret_hash, previous_secret_hash, previous_secret_expires_at,
  client_name, description, scopes, allowed_parties, rate_limit_tier, status,
  created_at, created_by, updated_at, expires_at, last_used_at, last_used_ip,
  revoked_at, revoked_by, revoke_reason`;

const UPDATABLE_API_KEY_FIELDS = {
  description: 'description',
  scopes: 'scopes',
  allowedParties: 'allowed_parties',
  rateLimitTier: 'rate_limit_tier',
  expiresAt: 'expires_at',
  status: 'status',
  secretHash: 'secret_hash',
  previousSecretHash: 'previous_secret_hash',
  previousSecretExpiresAt: 'previous_secret_expires_at',
  revokedAt: 'revoked_at',
  revokedBy: 'revoked_by',
  revokeReason: 'revoke_reason',
  updatedAt: 'updated_at',
};

function apiKeyFromRow(row) {
  return {
    id: row.id,
    keyId: row.key_id,
    environment: row.environment,
    secretHash: row.secret_hash,
    previousSecretHash: row.previous_secret_hash,
    previousSecretExpiresAt: row.previous_secret_expires_at,
    clientName: row.client_name,
    description: row.description,
    scopes: row.scopes,
    allowedParties: row.allowed_parties,
    rateLimitTier: row.rate_limit_tier,
    status: row.status,
    createdAt: row.created_at,
    createdBy: row.created_by,
    updatedAt: row.updated_at,
    expiresAt: row.expires_at,
    lastUsedAt: row.last_used_at,
    lastUsedIp: row.last_used_ip,
    revokedAt: row.revoked_at,
    revokedBy: row.revoked_by,
    revokeReason: row.revoke_reason,
  };
}

/** @param {import('pg').Pool} pool */
export function createPostgresApiKeyRepository(pool) {
  return {
    kind: 'postgres',
    async insert(record) {
      await pool.query(
        `INSERT INTO bdar_api_keys (${API_KEY_COLUMNS})
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21)`,
        [
          record.id, record.keyId, record.environment, record.secretHash, record.previousSecretHash,
          record.previousSecretExpiresAt, record.clientName, record.description, record.scopes,
          record.allowedParties, record.rateLimitTier, record.status, record.createdAt, record.createdBy,
          record.updatedAt, record.expiresAt, record.lastUsedAt, null, record.revokedAt, record.revokedBy,
          record.revokeReason,
        ],
      );
    },
    async findByKeyId(keyId) {
      const { rows } = await pool.query(`SELECT ${API_KEY_COLUMNS} FROM bdar_api_keys WHERE key_id = $1`, [keyId]);
      return rows[0] ? apiKeyFromRow(rows[0]) : undefined;
    },
    async list({ status, clientName } = {}) {
      const { rows } = await pool.query(
        `SELECT ${API_KEY_COLUMNS} FROM bdar_api_keys
         WHERE ($1::text IS NULL OR status = $1) AND ($2::text IS NULL OR client_name = $2)
         ORDER BY created_at`,
        [status ?? null, clientName ?? null],
      );
      return rows.map(apiKeyFromRow);
    },
    async update(keyId, changes) {
      const sets = [];
      const values = [];
      for (const [field, value] of Object.entries(changes)) {
        const column = UPDATABLE_API_KEY_FIELDS[field];
        if (!column) throw new Error(`field ${field} cannot be updated`);
        values.push(value);
        sets.push(`${column} = $${values.length}`);
      }
      values.push(keyId);
      const { rows } = await pool.query(
        `UPDATE bdar_api_keys SET ${sets.join(', ')} WHERE key_id = $${values.length} RETURNING ${API_KEY_COLUMNS}`,
        values,
      );
      return rows[0] ? apiKeyFromRow(rows[0]) : undefined;
    },
    async markUsed(keyId, at, ip) {
      await pool.query('UPDATE bdar_api_keys SET last_used_at = $1, last_used_ip = $2 WHERE key_id = $3', [at, ip ?? null, keyId]);
    },
    async ping() {
      await pool.query('SELECT 1');
      return true;
    },
  };
}

/** @param {import('pg').Pool} pool */
export function createPostgresAuditRepository(pool) {
  return {
    kind: 'postgres',
    async insert(event) {
      await pool.query(
        `INSERT INTO bdar_audit_events
           (request_id, api_key_id, client_name, action, resource_type, resource_id, outcome,
            http_status, ledger_update_id, source_ip, user_agent, details)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
        [
          event.requestId ?? null, event.apiKeyId ?? null, event.clientName ?? null, event.action,
          event.resourceType ?? null, event.resourceId ?? null, event.outcome, event.httpStatus ?? null,
          event.ledgerUpdateId ?? null, event.sourceIp ?? null, event.userAgent ?? null, JSON.stringify(event.details ?? {}),
        ],
      );
    },
    async list({ from, to, action, apiKeyId, limit = 100 } = {}) {
      const { rows } = await pool.query(
        `SELECT id, occurred_at, request_id, api_key_id, client_name, action, resource_type, resource_id,
                outcome, http_status, ledger_update_id, source_ip, details
           FROM bdar_audit_events
          WHERE ($1::timestamptz IS NULL OR occurred_at >= $1)
            AND ($2::timestamptz IS NULL OR occurred_at < $2)
            AND ($3::text IS NULL OR action = $3)
            AND ($4::text IS NULL OR api_key_id = $4)
          ORDER BY occurred_at DESC
          LIMIT $5`,
        [from ?? null, to ?? null, action ?? null, apiKeyId ?? null, Math.min(limit, 1000)],
      );
      return rows.map((row) => ({
        id: Number(row.id),
        occurredAt: row.occurred_at,
        requestId: row.request_id,
        apiKeyId: row.api_key_id,
        clientName: row.client_name,
        action: row.action,
        resourceType: row.resource_type,
        resourceId: row.resource_id,
        outcome: row.outcome,
        httpStatus: row.http_status,
        ledgerUpdateId: row.ledger_update_id,
        sourceIp: row.source_ip,
        details: row.details,
      }));
    },
  };
}

/** @param {import('pg').Pool} pool */
export function createPostgresIdempotencyRepository(pool) {
  return {
    kind: 'postgres',
    async begin({ apiKeyId, idempotencyKey, requestHash, expiresAt }) {
      // Remove an expired record for the same key first, then insert if absent.
      await pool.query(
        'DELETE FROM bdar_idempotency_keys WHERE api_key_id = $1 AND idempotency_key = $2 AND expires_at <= now()',
        [apiKeyId, idempotencyKey],
      );
      const inserted = await pool.query(
        `INSERT INTO bdar_idempotency_keys (api_key_id, idempotency_key, request_hash, state, expires_at)
         VALUES ($1, $2, $3, 'in_progress', $4)
         ON CONFLICT (api_key_id, idempotency_key) DO NOTHING
         RETURNING request_hash, state, response_status, response_body`,
        [apiKeyId, idempotencyKey, requestHash, expiresAt],
      );
      if (inserted.rowCount === 1) {
        return { created: true, record: { apiKeyId, idempotencyKey, requestHash, state: 'in_progress' } };
      }
      const { rows } = await pool.query(
        `SELECT request_hash, state, response_status, response_body
           FROM bdar_idempotency_keys WHERE api_key_id = $1 AND idempotency_key = $2`,
        [apiKeyId, idempotencyKey],
      );
      const row = rows[0];
      return {
        created: false,
        record: row && {
          apiKeyId, idempotencyKey, requestHash: row.request_hash, state: row.state,
          responseStatus: row.response_status, responseBody: row.response_body,
        },
      };
    },
    async complete({ apiKeyId, idempotencyKey, responseStatus, responseBody }) {
      await pool.query(
        `UPDATE bdar_idempotency_keys SET state = 'completed', response_status = $1, response_body = $2
          WHERE api_key_id = $3 AND idempotency_key = $4`,
        [responseStatus, JSON.stringify(responseBody ?? null), apiKeyId, idempotencyKey],
      );
    },
    async abandon({ apiKeyId, idempotencyKey }) {
      await pool.query('DELETE FROM bdar_idempotency_keys WHERE api_key_id = $1 AND idempotency_key = $2', [apiKeyId, idempotencyKey]);
    },
    async purgeExpired() {
      await pool.query('DELETE FROM bdar_idempotency_keys WHERE expires_at <= now()');
    },
  };
}
