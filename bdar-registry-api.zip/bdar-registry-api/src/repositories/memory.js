/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * In-memory repositories. Used by unit tests and by local development without a
 * database. They implement exactly the same methods as the PostgreSQL versions.
 */

const clone = (value) => (value === null || value === undefined ? value : structuredClone(value));

export function createMemoryApiKeyRepository() {
  const records = new Map();
  return {
    kind: 'memory',
    async insert(record) {
      if (records.has(record.keyId)) throw new Error('duplicate key id');
      records.set(record.keyId, clone(record));
    },
    async findByKeyId(keyId) {
      return clone(records.get(keyId));
    },
    async list({ status, clientName } = {}) {
      return [...records.values()]
        .filter((record) => (status ? record.status === status : true))
        .filter((record) => (clientName ? record.clientName === clientName : true))
        .sort((a, b) => a.createdAt - b.createdAt)
        .map(clone);
    },
    async update(keyId, changes) {
      const record = records.get(keyId);
      if (!record) return undefined;
      Object.assign(record, clone(changes));
      return clone(record);
    },
    async markUsed(keyId, at, ip) {
      const record = records.get(keyId);
      if (record) Object.assign(record, { lastUsedAt: at, lastUsedIp: ip ?? null });
    },
    async ping() {
      return true;
    },
  };
}

export function createMemoryAuditRepository() {
  const events = [];
  return {
    kind: 'memory',
    events,
    async insert(event) {
      events.push({ id: events.length + 1, occurredAt: new Date(), ...clone(event) });
    },
    async list({ from, to, action, apiKeyId, limit = 100 } = {}) {
      return events
        .filter((event) => (from ? event.occurredAt >= from : true))
        .filter((event) => (to ? event.occurredAt < to : true))
        .filter((event) => (action ? event.action === action : true))
        .filter((event) => (apiKeyId ? event.apiKeyId === apiKeyId : true))
        .slice(-limit)
        .reverse()
        .map(clone);
    },
  };
}

export function createMemoryIdempotencyRepository({ now = () => new Date() } = {}) {
  const entries = new Map();
  const id = (apiKeyId, key) => JSON.stringify([apiKeyId, key]);
  return {
    kind: 'memory',
    /** Insert an in-progress record. Returns the existing record if one is already there. */
    async begin({ apiKeyId, idempotencyKey, requestHash, expiresAt }) {
      const existing = entries.get(id(apiKeyId, idempotencyKey));
      if (existing && existing.expiresAt > now()) return { created: false, record: clone(existing) };
      const record = { apiKeyId, idempotencyKey, requestHash, state: 'in_progress', responseStatus: null, responseBody: null, expiresAt };
      entries.set(id(apiKeyId, idempotencyKey), record);
      return { created: true, record: clone(record) };
    },
    async complete({ apiKeyId, idempotencyKey, responseStatus, responseBody }) {
      const record = entries.get(id(apiKeyId, idempotencyKey));
      if (record) Object.assign(record, { state: 'completed', responseStatus, responseBody: clone(responseBody) });
    },
    async abandon({ apiKeyId, idempotencyKey }) {
      entries.delete(id(apiKeyId, idempotencyKey));
    },
    async purgeExpired() {
      for (const [key, record] of entries) if (record.expiresAt <= now()) entries.delete(key);
    },
  };
}
