/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Request validation with Ajv.
 *
 * The component schemas are written in the OpenAPI 3.0 dialect. Ajv validates JSON
 * Schema, so `toJsonSchema` converts the two OpenAPI specific parts before compiling:
 *   - `nullable: true` becomes a union with null,
 *   - `#/components/schemas/X` references point at the shared schema registered in Ajv.
 * Documentation only keywords (example, deprecated) are removed.
 */

import Ajv from 'ajv';
import addFormats from 'ajv-formats';
import { apiError } from '../lib/errors.js';
import { schemas } from './schemas.js';

const DOC_ONLY_KEYWORDS = new Set(['example', 'deprecated', 'externalDocs', 'xml', 'discriminator']);
const SHARED_ID = 'bdar-components.json';

/** Convert an OpenAPI 3.0 schema object to plain JSON Schema (draft 7). */
export function toJsonSchema(schema) {
  if (Array.isArray(schema)) return schema.map(toJsonSchema);
  if (schema === null || typeof schema !== 'object') return schema;
  const out = {};
  for (const [key, value] of Object.entries(schema)) {
    if (DOC_ONLY_KEYWORDS.has(key) || key === 'nullable') continue;
    if (key === '$ref' && typeof value === 'string' && value.startsWith('#/components/schemas/')) {
      out.$ref = `${SHARED_ID}#/definitions/${value.slice('#/components/schemas/'.length)}`;
    } else if (key === 'properties' || key === 'definitions') {
      out[key] = Object.fromEntries(Object.entries(value).map(([name, child]) => [name, toJsonSchema(child)]));
    } else {
      out[key] = toJsonSchema(value);
    }
  }
  if (schema.nullable === true) {
    if (typeof out.type === 'string') {
      out.type = [out.type, 'null'];
      if (Array.isArray(out.enum)) out.enum = [...out.enum, null];
      return out;
    }
    return { anyOf: [out, { type: 'null' }] };
  }
  return out;
}

/** Ajv error list to the API `details` format. */
function toDetails(errors, location) {
  return (errors ?? []).slice(0, 20).map((error) => ({
    location,
    field: error.instancePath || (error.params?.missingProperty ? `/${error.params.missingProperty}` : '/'),
    message: error.message,
    ...(error.params?.additionalProperty ? { unexpected: error.params.additionalProperty } : {}),
    ...(error.params?.allowedValues ? { allowed: error.params.allowedValues } : {}),
  }));
}

export function createValidator() {
  const shared = { $id: SHARED_ID, definitions: toJsonSchema({ definitions: schemas }).definitions };
  const options = { allErrors: true, strict: true, strictRequired: false, allowUnionTypes: true, useDefaults: true, removeAdditional: false };
  const ajv = new Ajv({ ...options, coerceTypes: false });
  // Query strings arrive as text, so the query validator converts "25" to 25 before checking.
  const queryAjv = new Ajv({ ...options, coerceTypes: true });
  for (const instance of [ajv, queryAjv]) {
    addFormats(instance, ['date-time', 'int32']);
    instance.addSchema(shared);
  }

  return {
    /**
     * Compile the validators of one route.
     * @returns {(req: { params: object, query: object, body: unknown }) => void} throws 400 VALIDATION_FAILED
     */
    compileRoute(route) {
      const byLocation = (location) => (route.parameters ?? []).filter((p) => p.in === location);
      const objectSchema = (list, additional) => ({
        type: 'object',
        additionalProperties: additional,
        properties: Object.fromEntries(list.map((p) => [p.name, toJsonSchema(p.schema)])),
        required: list.filter((p) => p.required).map((p) => p.name),
      });
      const validatePath = ajv.compile(objectSchema(byLocation('path'), false));
      const validateQuery = queryAjv.compile(objectSchema(byLocation('query'), false));
      const validateBody = route.body ? ajv.compile({ $ref: `${SHARED_ID}#/definitions/${route.body}` }) : undefined;

      /**
       * Validate a request context { params, query, body }. The context holds copies
       * (Express 5 re-parses req.query on every read), so coercion and defaults stick.
       */
      return function validate(ctx) {
        if (!validatePath(ctx.params)) {
          throw apiError('VALIDATION_FAILED', 'A path parameter is not valid', { details: toDetails(validatePath.errors, 'path') });
        }
        if (!validateQuery(ctx.query)) {
          throw apiError('VALIDATION_FAILED', 'A query parameter is not valid', { details: toDetails(validateQuery.errors, 'query') });
        }
        if (validateBody) {
          if (ctx.body === undefined && route.bodyOptional) ctx.body = {};
          if (ctx.body === undefined) throw apiError('VALIDATION_FAILED', 'A JSON request body is required');
          if (!validateBody(ctx.body)) {
            throw apiError('VALIDATION_FAILED', undefined, { details: toDetails(validateBody.errors, 'body') });
          }
        } else if (ctx.body !== undefined && Object.keys(ctx.body).length > 0) {
          throw apiError('VALIDATION_FAILED', 'This operation does not take a request body');
        }
      };
    },
  };
}
