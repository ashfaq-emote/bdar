/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * The last two middleware: 404 for unknown paths, and the error handler that turns
 * every thrown error into the standard error body.
 *
 * Rules (OWASP API8, security misconfiguration):
 *   - Never send stack traces or internal messages to the client.
 *   - Log unexpected errors with the request id so support can find them.
 *   - Errors from body-parser (bad JSON, body too large) get their own codes.
 */

import { ApiError, apiError, toErrorBody } from '../lib/errors.js';
import { noopLogger } from '../lib/util.js';

export function notFound() {
  return function notFoundMiddleware(req, res, next) {
    next(apiError('ROUTE_NOT_FOUND'));
  };
}

/** Map errors thrown by express.json() to API errors. */
export function normalizeError(error) {
  if (error instanceof ApiError) return error;
  if (error?.type === 'entity.parse.failed') return apiError('INVALID_JSON', undefined, { cause: error });
  if (error?.type === 'entity.too.large') return apiError('PAYLOAD_TOO_LARGE', undefined, { cause: error });
  if (error?.type === 'encoding.unsupported' || error?.type === 'charset.unsupported') return apiError('UNSUPPORTED_MEDIA_TYPE', undefined, { cause: error });
  if (error?.type === 'request.aborted') return apiError('VALIDATION_FAILED', 'The request was aborted', { cause: error });
  return error;
}

export function errorHandler({ logger = noopLogger } = {}) {
  // Express recognises an error handler by its four arguments, so `next` must stay.
  return function errorHandlerMiddleware(rawError, req, res, next) {
    const error = normalizeError(rawError);
    const body = toErrorBody(error, req.id);
    if (!(error instanceof ApiError)) {
      logger.error({ err: rawError, requestId: req.id, operationId: req.operationId, path: req.path }, 'unhandled error');
    } else if (error.status >= 500) {
      logger.error({ err: error.cause ?? error, code: error.code, requestId: req.id, operationId: req.operationId }, 'dependency error');
    }
    if (res.headersSent) return undefined;
    for (const [name, value] of Object.entries(error.headers ?? {})) res.setHeader(name, value);
    res.setHeader('Cache-Control', 'no-store');
    return res.status(body.status).json(body);
  };
}
