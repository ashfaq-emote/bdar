/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * The route table: every HTTP operation of the registry API, as data.
 *
 * The same table is used to
 *   1. build the Express router (src/http/router.js), and
 *   2. generate the OpenAPI document (src/openapi/generate.js).
 * So the published specification cannot drift from what the server does.
 *
 * Fields of a route:
 *   operationId   unique name, also used in logs, metrics and audit events
 *   method, path  OpenAPI style path ({param})
 *   tag           OpenAPI tag (functional group)
 *   auth          'none' or 'apiKey'
 *   scopes        the key needs at least one of these
 *   rateLimit     name of the rate limit policy (config/rate-limits.json)
 *   parameters    OpenAPI parameter objects (path, query, header)
 *   body          name of the request body schema, or undefined
 *   idempotent    true: Idempotency-Key header required, response replayed on retry
 *   audit         audit action name, written for success and failure
 *   responses     status code -> response schema name
 *   handler       async (ctx, services) => { status, body }
 */

import { Scopes } from '../security/scopes.js';
import { requireGrantable } from '../security/scopes.js';
import { apiError } from '../lib/errors.js';
import { params } from './schemas.js';
import { PARTY_COLLECTION_NAMES } from '../services/bdarService.js';

const ok = (body) => ({ status: 200, body });
const created = (body) => ({ status: 201, body });

const READ_SCOPES = [Scopes.REGISTRY_READ, Scopes.WALLET, Scopes.ISSUER, Scopes.EXECUTOR, Scopes.OPERATOR_READ];
const OPERATOR_READ = [Scopes.OPERATOR_READ, Scopes.OPERATOR_WRITE];
const OPERATOR_WRITE = [Scopes.OPERATOR_WRITE];
const PARTY_READ = [Scopes.WALLET, Scopes.ISSUER, Scopes.EXECUTOR, Scopes.OPERATOR_READ];

const CONTEXT_ERRORS = [400, 401, 403, 404, 409, 429, 502, 503, 504];
const COMMAND_ERRORS = [400, 401, 403, 404, 409, 413, 415, 429, 502, 503, 504];

const TAGS = {
  system: 'System',
  metadata: 'Token Standard: Metadata',
  transfers: 'Token Standard: Transfers',
  allocations: 'Token Standard: Allocations and Settlement',
  issuance: 'BDAR: Issuance',
  instruments: 'BDAR: Instruments',
  wallet: 'BDAR: Wallet Queries',
  accounts: 'BDAR: Accounts',
  submissions: 'BDAR: Prepare and Execute',
  operatorInstruments: 'Operator: Instruments and Registry',
  operatorAccounts: 'Operator: Accounts and Controls',
  operatorIssuance: 'Operator: Mint Requests',
  operatorHousekeeping: 'Operator: Housekeeping',
  audit: 'Operator: Audit',
  keys: 'API Keys',
};

export const TAG_DESCRIPTIONS = {
  [TAGS.system]: 'Ping, health, the OpenAPI document and the identity of the calling key.',
  [TAGS.metadata]: 'CIP-56 and CIP-112 registry and instrument metadata.',
  [TAGS.transfers]: 'CIP-56 (V1) and CIP-112 (V2) transfer factory and transfer instruction choice contexts.',
  [TAGS.allocations]: 'Allocation factory, allocation instruction and allocation choice contexts, and the V2 settlement factory.',
  [TAGS.issuance]: 'Broadridge issuance factory context for issuers.',
  [TAGS.instruments]: 'Full instrument policies and supply figures.',
  [TAGS.wallet]: 'Party scoped reads: holdings, balances, pending instructions, allocations and records.',
  [TAGS.accounts]: 'Account lookup and account request validation.',
  [TAGS.submissions]: 'Interactive submission for externally signed parties.',
  [TAGS.operatorInstruments]: 'Registry bootstrap, instrument lifecycle and registry configuration. Admin party commands.',
  [TAGS.operatorAccounts]: 'Account requests, freeze, unfreeze, clawback and allowlist. Admin party commands.',
  [TAGS.operatorIssuance]: 'Approve or reject mint requests that need registry approval.',
  [TAGS.operatorHousekeeping]: 'Release expired instructions, allocations and preapprovals.',
  [TAGS.audit]: 'The audit trail of the API.',
  [TAGS.keys]: 'API key lifecycle for Broadridge administrators.',
};

const contractIdParam = (name, what) => params.contractIdPath(name, `The contract id of the ${what}.`);

/** The token standard context routes share their shape. */
function contextRoute({ operationId, path, tag, scopes, summary, description, parameters, handler }) {
  return {
    operationId, method: 'post', path, tag, auth: 'apiKey', scopes, rateLimit: 'context', summary, description,
    parameters, body: 'GetChoiceContextRequest', bodyOptional: false, responses: { 200: 'ChoiceContext' }, errors: CONTEXT_ERRORS, handler,
  };
}

export function buildRoutes() {
  const routes = [];
  const add = (route) => routes.push(route);

  // ======================================================================= System

  add({
    operationId: 'ping', method: 'get', path: '/ping', tag: TAGS.system, auth: 'none', rateLimit: 'public',
    summary: 'Ping', description: 'Answers without calling any dependency. Use it to check the API is reachable.',
    responses: { 200: 'Ping' }, errors: [429],
    handler: async (ctx, s) => ok(s.health.ping()),
  });
  add({
    operationId: 'getLiveness', method: 'get', path: '/health/live', tag: TAGS.system, auth: 'none', rateLimit: 'public',
    summary: 'Liveness probe', description: 'Returns 200 while the process can serve requests. Point the container liveness probe here.',
    responses: { 200: 'Liveness' }, errors: [429],
    handler: async (ctx, s) => ok(s.health.live()),
  });
  add({
    operationId: 'getReadiness', method: 'get', path: '/health/ready', tag: TAGS.system, auth: 'none', rateLimit: 'public',
    summary: 'Readiness probe',
    description: 'Returns 200 when the ledger and the database answer, otherwise 503. Point the load balancer health check here.',
    responses: { 200: 'Readiness', 503: 'Readiness' }, errors: [429],
    handler: async (ctx, s) => {
      const { ready, body } = await s.health.ready();
      return { status: ready ? 200 : 503, body };
    },
  });
  add({
    operationId: 'getHealth', method: 'get', path: '/health', tag: TAGS.system, auth: 'apiKey', scopes: [Scopes.OPERATOR_READ], rateLimit: 'metadata',
    summary: 'Detailed health', description: 'Status, latency and detail of every dependency, and non secret settings.',
    responses: { 200: 'HealthDetailed' }, errors: [401, 403, 429],
    handler: async (ctx, s) => ok(await s.health.detailed()),
  });
  add({
    operationId: 'whoAmI', method: 'get', path: '/auth/v1/whoami', tag: TAGS.system, auth: 'apiKey', scopes: [], rateLimit: 'metadata',
    summary: 'Identity of the calling API key', description: 'Returns the key id, client, scopes and allowed parties. Useful to test a new key.',
    responses: { 200: 'WhoAmI' }, errors: [401, 429],
    handler: async (ctx) => ok({ ...ctx.auth }),
  });

  // ============================================================ Token standard: metadata

  add({
    operationId: 'getRegistryInfo', method: 'get', path: '/registry/metadata/v1/info', tag: TAGS.metadata, auth: 'apiKey', scopes: READ_SCOPES,
    rateLimit: 'metadata', standard: 'CIP-56, CIP-112',
    summary: 'Registry information', description: 'The admin party of the registry and the token standard APIs it supports.',
    responses: { 200: 'GetRegistryInfoResponse' }, errors: [401, 403, 429, 503],
    handler: async (ctx, s) => ok(await s.tokenStandard.getRegistryInfo()),
  });
  add({
    operationId: 'listInstruments', method: 'get', path: '/registry/metadata/v1/instruments', tag: TAGS.metadata, auth: 'apiKey', scopes: READ_SCOPES,
    rateLimit: 'metadata', standard: 'CIP-56, CIP-112',
    summary: 'List instruments', description: 'All instruments of the registry, sorted by id, with total supply and pause state.',
    parameters: [params.metadataPageSize, params.pageToken],
    responses: { 200: 'ListInstrumentsResponse' }, errors: [400, 401, 403, 429, 503],
    handler: async (ctx, s) => ok(await s.tokenStandard.listInstruments(ctx.query)),
  });
  add({
    operationId: 'getInstrument', method: 'get', path: '/registry/metadata/v1/instruments/{instrumentId}', tag: TAGS.metadata, auth: 'apiKey',
    scopes: READ_SCOPES, rateLimit: 'metadata', standard: 'CIP-56, CIP-112',
    summary: 'Get an instrument', description: 'One instrument in the token standard format.',
    parameters: [params.instrumentId],
    responses: { 200: 'Instrument' }, errors: [401, 403, 404, 429, 503],
    handler: async (ctx, s) => ok(await s.tokenStandard.getInstrument(ctx.params.instrumentId)),
  });

  // =========================================================== Token standard: transfers

  for (const version of [1, 2]) {
    const standard = version === 1 ? 'CIP-56' : 'CIP-112';
    add({
      operationId: `getTransferFactoryV${version}`, method: 'post', path: `/registry/transfer-instruction/v${version}/transfer-factory`,
      tag: TAGS.transfers, auth: 'apiKey', scopes: [Scopes.WALLET], rateLimit: 'context', standard,
      summary: `Transfer factory (${standard})`,
      description: `The factory contract id, the transfer kind and the choice context for TransferFactory_Transfer (V${version}). `
        + 'Send the intended choice arguments with empty extraArgs. The API key must be allowed to act for a sender account party.',
      body: `TransferFactoryRequestV${version}`, responses: { 200: 'TransferFactoryWithChoiceContext' }, errors: CONTEXT_ERRORS,
      handler: async (ctx, s) => ok(await s.tokenStandard.getTransferFactory({ version, body: ctx.body, auth: ctx.auth })),
    });
    for (const action of ['accept', 'reject', 'withdraw']) {
      const choice = `TransferInstruction_${action[0].toUpperCase()}${action.slice(1)}`;
      add(contextRoute({
        operationId: `getTransferInstruction${action[0].toUpperCase()}${action.slice(1)}ContextV${version}`,
        path: `/registry/transfer-instruction/v${version}/{transferInstructionId}/choice-contexts/${action}`,
        tag: TAGS.transfers, scopes: [Scopes.WALLET, Scopes.ISSUER],
        summary: `Context to ${action} a transfer instruction (${standard})`,
        description: `Choice context for ${choice}. The API key must be allowed to act for the sender, the receiver or an issuer of the instruction.`,
        parameters: [contractIdParam('transferInstructionId', 'transfer instruction')],
        handler: async (ctx, s) => ok(await s.tokenStandard.getTransferInstructionContext({
          version, action, contractId: ctx.params.transferInstructionId, body: ctx.body, auth: ctx.auth,
        })),
      }));
    }
  }

  // ========================================================= Token standard: allocations

  for (const version of [1, 2]) {
    const standard = version === 1 ? 'CIP-56' : 'CIP-112';
    add({
      operationId: `getAllocationFactoryV${version}`, method: 'post', path: `/registry/allocation-instruction/v${version}/allocation-factory`,
      tag: TAGS.allocations, auth: 'apiKey', scopes: [Scopes.WALLET, Scopes.ISSUER], rateLimit: 'context', standard,
      summary: `Allocation factory (${standard})`,
      description: `The factory contract id and choice context for AllocationFactory_Allocate (V${version}).`,
      body: `AllocationFactoryRequestV${version}`, responses: { 200: 'FactoryWithChoiceContext' }, errors: CONTEXT_ERRORS,
      handler: async (ctx, s) => ok(await s.tokenStandard.getAllocationFactory({ version, body: ctx.body, auth: ctx.auth })),
    });
  }
  for (const action of ['accept', 'withdraw']) {
    add(contextRoute({
      operationId: `getAllocationInstruction${action[0].toUpperCase()}${action.slice(1)}Context`,
      path: `/registry/allocation-instruction/v2/{allocationInstructionId}/choice-contexts/${action}`,
      tag: TAGS.allocations, scopes: [Scopes.WALLET],
      summary: `Context to ${action} an allocation instruction (CIP-112)`,
      description: `Choice context for AllocationInstruction_${action[0].toUpperCase()}${action.slice(1)}. The key must act for an authorizer account party.`,
      parameters: [contractIdParam('allocationInstructionId', 'allocation instruction')],
      handler: async (ctx, s) => ok(await s.tokenStandard.getAllocationInstructionContext({
        action, contractId: ctx.params.allocationInstructionId, body: ctx.body, auth: ctx.auth,
      })),
    }));
  }
  const allocationActions = {
    1: { 'execute-transfer': [Scopes.EXECUTOR, Scopes.WALLET], withdraw: [Scopes.WALLET, Scopes.ISSUER], cancel: [Scopes.EXECUTOR, Scopes.WALLET] },
    2: { withdraw: [Scopes.WALLET, Scopes.ISSUER], cancel: [Scopes.EXECUTOR, Scopes.WALLET] },
  };
  for (const version of [1, 2]) {
    const standard = version === 1 ? 'CIP-56' : 'CIP-112';
    for (const [action, scopes] of Object.entries(allocationActions[version])) {
      const pascal = action.split('-').map((part) => part[0].toUpperCase() + part.slice(1)).join('');
      add(contextRoute({
        operationId: `getAllocation${pascal}ContextV${version}`,
        path: `/registry/allocations/v${version}/{allocationId}/choice-contexts/${action}`,
        tag: TAGS.allocations, scopes,
        summary: `Context to ${action.replace('-', ' ')} an allocation (${standard})`,
        description: `Choice context for Allocation_${pascal}. Locked holdings of the allocation are disclosed.`,
        parameters: [contractIdParam('allocationId', 'allocation')],
        handler: async (ctx, s) => ok(await s.tokenStandard.getAllocationContext({
          version, action, contractId: ctx.params.allocationId, body: ctx.body, auth: ctx.auth,
        })),
      }));
    }
  }
  add({
    operationId: 'getSettlementFactory', method: 'post', path: '/registry/allocation/v2/settlement-factory', tag: TAGS.allocations,
    auth: 'apiKey', scopes: [Scopes.EXECUTOR], rateLimit: 'context', standard: 'CIP-112',
    summary: 'Settlement factory (CIP-112)',
    description: 'The factory contract id and choice context for SettlementFactory_SettleBatch. Supports at least 25 legs, 50 allocations and 100 parties. The key must act for a settlement executor.',
    body: 'SettlementFactoryRequest', responses: { 200: 'FactoryWithChoiceContext' }, errors: CONTEXT_ERRORS,
    handler: async (ctx, s) => ok(await s.tokenStandard.getSettlementFactory({ body: ctx.body, auth: ctx.auth })),
  });

  // ================================================================= BDAR: issuance

  add({
    operationId: 'getIssuanceFactory', method: 'post', path: '/registry/bdar/v1/issuance-factory', tag: TAGS.issuance, auth: 'apiKey',
    scopes: [Scopes.ISSUER], rateLimit: 'context', standard: 'BDAR',
    summary: 'Issuance factory context',
    description: 'The factory contract id, the expected outcome and the choice context for BdarIssuanceFactory_RequestMint. The key must act for the issuer.',
    body: 'IssuanceFactoryRequest', responses: { 200: 'IssuanceFactoryResponse' }, errors: CONTEXT_ERRORS,
    handler: async (ctx, s) => ok(await s.bdar.getIssuanceFactory({ body: ctx.body, auth: ctx.auth })),
  });

  // ============================================================== BDAR: instruments

  add({
    operationId: 'listBdarInstruments', method: 'get', path: '/registry/bdar/v1/instruments', tag: TAGS.instruments, auth: 'apiKey',
    scopes: READ_SCOPES, rateLimit: 'metadata', summary: 'List instruments with policies',
    description: 'Every instrument with its full policy set and supply figures.',
    parameters: [params.pageSize, params.pageToken], responses: { 200: 'BdarInstrumentPage' }, errors: [400, 401, 403, 429, 503],
    handler: async (ctx, s) => ok(await s.bdar.listInstruments(ctx.query)),
  });
  add({
    operationId: 'getBdarInstrument', method: 'get', path: '/registry/bdar/v1/instruments/{instrumentId}', tag: TAGS.instruments, auth: 'apiKey',
    scopes: READ_SCOPES, rateLimit: 'metadata', summary: 'Get an instrument with policies',
    description: 'One instrument with eligibility, supply, redemption, settlement and control policies.',
    parameters: [params.instrumentId], responses: { 200: 'BdarInstrument' }, errors: [401, 403, 404, 429, 503],
    handler: async (ctx, s) => ok(await s.bdar.getInstrument(ctx.params.instrumentId)),
  });

  // ============================================================ BDAR: party queries

  const collectionSchemas = {
    holdings: 'HoldingPage',
    'transfer-instructions': 'TransferInstructionPage',
    'allocation-instructions': 'AllocationInstructionPage',
    allocations: 'AllocationPage',
    accounts: 'BdarAccountPage',
    'account-requests': 'AccountRequestPage',
    preapprovals: 'PreapprovalPage',
    'clawback-records': 'ClawbackRecordPage',
    'mint-requests': 'MintRequestPage',
  };
  const collectionQuery = {
    holdings: [params.instrumentIdQuery, { name: 'locked', in: 'query', required: false, schema: { type: 'string', enum: ['true', 'false'] } }],
    'transfer-instructions': [params.instrumentIdQuery, { name: 'role', in: 'query', required: false, schema: { type: 'string', enum: ['sender', 'receiver', 'issuer'] } }],
    allocations: [{ name: 'role', in: 'query', required: false, schema: { type: 'string', enum: ['authorizer', 'executor'] } }],
  };
  for (const collection of PARTY_COLLECTION_NAMES) {
    const pascal = collection.split('-').map((part) => part[0].toUpperCase() + part.slice(1)).join('');
    add({
      operationId: `listParty${pascal}`, method: 'get', path: `/registry/bdar/v1/parties/{party}/${collection}`, tag: TAGS.wallet,
      auth: 'apiKey', scopes: PARTY_READ, rateLimit: 'query',
      summary: `List ${collection.replace('-', ' ')} of a party`,
      description: `Active ${collection.replace('-', ' ')} where the party has a role. The key must be allowed to act for the party.`,
      parameters: [params.party, ...(collectionQuery[collection] ?? []), params.pageSize, params.pageToken],
      responses: { 200: collectionSchemas[collection] }, errors: [400, 401, 403, 429, 503],
      handler: async (ctx, s) => ok(await s.bdar.listForParty({ party: ctx.params.party, collection, query: ctx.query, auth: ctx.auth })),
    });
  }
  add({
    operationId: 'listPartyBalances', method: 'get', path: '/registry/bdar/v1/parties/{party}/balances', tag: TAGS.wallet, auth: 'apiKey',
    scopes: PARTY_READ, rateLimit: 'query', summary: 'Balances of a party',
    description: 'Total, locked and available amounts per account and instrument, computed from active holdings with exact decimal arithmetic.',
    parameters: [params.party, params.instrumentIdQuery], responses: { 200: 'BalanceList' }, errors: [400, 401, 403, 429, 503],
    handler: async (ctx, s) => ok(await s.bdar.balancesForParty({ party: ctx.params.party, query: ctx.query, auth: ctx.auth })),
  });

  // ================================================================= BDAR: accounts

  add({
    operationId: 'getAccount', method: 'get', path: '/registry/bdar/v1/accounts', tag: TAGS.accounts, auth: 'apiKey',
    scopes: [Scopes.WALLET, Scopes.OPERATOR_READ], rateLimit: 'query', summary: 'Look up one account',
    description: 'The BdarAccount contract of an owner, provider and account id. 404 if there is none (a basic account may still be usable implicitly).',
    parameters: [
      { name: 'owner', in: 'query', required: true, schema: { $ref: '#/components/schemas/Party' } },
      { name: 'provider', in: 'query', required: false, schema: { $ref: '#/components/schemas/Party' } },
      { name: 'id', in: 'query', required: false, schema: { type: 'string', maxLength: 256 } },
    ],
    responses: { 200: 'BdarAccount' }, errors: [400, 401, 403, 404, 429, 503],
    handler: async (ctx, s) => ok(await s.bdar.getAccount({ query: ctx.query, auth: ctx.auth })),
  });
  add({
    operationId: 'validateAccountRequest', method: 'post', path: '/registry/bdar/v1/account-requests/validate', tag: TAGS.accounts,
    auth: 'apiKey', scopes: [Scopes.WALLET], rateLimit: 'query', summary: 'Validate an account request',
    description: 'Checks an account request the way the operator will and returns a ready CreateCommand. Nothing is written to the ledger.',
    body: 'AccountRequestValidationRequest', responses: { 200: 'AccountRequestValidationResponse' }, errors: [400, 401, 403, 415, 429, 503],
    handler: async (ctx, s) => ok(await s.bdar.validateAccountRequest({ body: ctx.body, auth: ctx.auth })),
  });

  // ============================================================== BDAR: submissions

  add({
    operationId: 'prepareSubmission', method: 'post', path: '/registry/bdar/v1/submissions/prepare', tag: TAGS.submissions, auth: 'apiKey',
    scopes: [Scopes.SUBMIT], rateLimit: 'submission', summary: 'Prepare a transaction for external signing',
    description: 'Prepares registry commands for parties that sign outside the participant. Only allow listed choices, only for the key\'s parties, never for the admin party.',
    body: 'PrepareRequest', responses: { 200: 'PrepareResponse' }, errors: COMMAND_ERRORS, audit: 'submission.prepare',
    handler: async (ctx, s) => ok(await s.submissions.prepare({ body: ctx.body, auth: ctx.auth })),
  });
  add({
    operationId: 'executeSubmission', method: 'post', path: '/registry/bdar/v1/submissions/execute', tag: TAGS.submissions, auth: 'apiKey',
    scopes: [Scopes.SUBMIT], rateLimit: 'submission', idempotent: true, summary: 'Execute a signed transaction',
    description: 'Submits a prepared transaction with the party signatures and waits for the result.',
    body: 'ExecuteRequest', responses: { 200: 'ExecuteResponse' }, errors: COMMAND_ERRORS, audit: 'submission.execute',
    handler: async (ctx, s) => ok(await s.submissions.execute({ body: ctx.body, auth: ctx.auth, idempotencyKey: ctx.idempotencyKey })),
  });

  // ===================================================================== Operator

  const operatorCommand = (route) => add({
    auth: 'apiKey', scopes: OPERATOR_WRITE, rateLimit: 'operator', idempotent: true, errors: COMMAND_ERRORS, ...route,
  });
  const operatorRead = (route) => add({ auth: 'apiKey', scopes: OPERATOR_READ, rateLimit: 'operator', errors: [400, 401, 403, 404, 429, 503], ...route });
  const cmd = (ctx) => ({ body: ctx.body ?? {}, auth: ctx.auth, idempotencyKey: ctx.idempotencyKey });

  operatorCommand({
    operationId: 'bootstrapRegistry', method: 'post', path: '/registry/bdar/v1/admin/bootstrap', tag: TAGS.operatorInstruments,
    summary: 'Bootstrap the registry', description: 'Creates whichever of the registry config, event log and factories are missing. Safe to call again.',
    body: 'BootstrapRequest', bodyOptional: true, responses: { 200: 'BootstrapResponse', 201: 'BootstrapResponse' }, audit: 'registry.bootstrap',
    handler: async (ctx, s) => s.operator.bootstrap(cmd(ctx)),
  });
  operatorRead({
    operationId: 'getRegistryConfig', method: 'get', path: '/registry/bdar/v1/admin/registry-config', tag: TAGS.operatorInstruments,
    summary: 'Get the registry configuration', responses: { 200: 'RegistryConfig' },
    handler: async (ctx, s) => ok(await s.operator.getRegistryConfig()),
  });
  operatorCommand({
    operationId: 'setCredentialChecks', method: 'put', path: '/registry/bdar/v1/admin/registry-config/credential-checks', tag: TAGS.operatorInstruments,
    summary: 'Switch credential checks on or off', description: 'The registry wide switch. Instruments still need an enabled credential policy.',
    body: 'CredentialChecksRequest', responses: { 200: 'RegistryConfigResult' }, audit: 'registry.credentialChecks',
    handler: async (ctx, s) => s.operator.setCredentialChecks(cmd(ctx)),
  });
  operatorCommand({
    operationId: 'createInstrument', method: 'post', path: '/registry/bdar/v1/admin/instruments', tag: TAGS.operatorInstruments,
    summary: 'Create an instrument', description: 'Creates the instrument and its supply record in one transaction.',
    body: 'InstrumentCreateRequest', responses: { 201: 'InstrumentResult' }, audit: 'instrument.create',
    handler: async (ctx, s) => s.operator.createInstrument(cmd(ctx)),
  });
  operatorCommand({
    operationId: 'updateInstrumentPolicies', method: 'put', path: '/registry/bdar/v1/admin/instruments/{instrumentId}/policies', tag: TAGS.operatorInstruments,
    summary: 'Replace instrument policies', description: 'Replaces issuers and every policy at once (BdarInstrument_UpdatePolicies).',
    parameters: [params.instrumentId], body: 'InstrumentPolicies', responses: { 200: 'InstrumentResult' }, audit: 'instrument.updatePolicies',
    handler: async (ctx, s) => s.operator.updateInstrumentPolicies({ instrumentId: ctx.params.instrumentId, ...cmd(ctx) }),
  });
  operatorCommand({
    operationId: 'updateInstrumentDisplay', method: 'patch', path: '/registry/bdar/v1/admin/instruments/{instrumentId}/display', tag: TAGS.operatorInstruments,
    summary: 'Change name, symbol or metadata', parameters: [params.instrumentId], body: 'InstrumentDisplayRequest', responses: { 200: 'InstrumentResult' },
    audit: 'instrument.updateDisplay',
    handler: async (ctx, s) => s.operator.updateInstrumentDisplay({ instrumentId: ctx.params.instrumentId, ...cmd(ctx) }),
  });
  for (const [action, schema, description] of [
    ['pause', 'PauseRequest', 'Stops every movement of value in the instrument.'],
    ['resume', 'EmptyRequest', 'Clears the pause.'],
    ['retire', 'EmptyRequest', 'No new issuance, transfers or allocations. Holders can still redeem.'],
  ]) {
    operatorCommand({
      operationId: `${action}Instrument`, method: 'post', path: `/registry/bdar/v1/admin/instruments/{instrumentId}/${action}`, tag: TAGS.operatorInstruments,
      summary: `${action[0].toUpperCase()}${action.slice(1)} an instrument`, description,
      parameters: [params.instrumentId], body: schema, bodyOptional: schema === 'EmptyRequest', responses: { 200: 'InstrumentResult' },
      audit: `instrument.${action}`,
      handler: async (ctx, s) => s.operator[`${action}Instrument`]({ instrumentId: ctx.params.instrumentId, ...cmd(ctx) }),
    });
  }

  operatorRead({
    operationId: 'listAccountRequests', method: 'get', path: '/registry/bdar/v1/admin/account-requests', tag: TAGS.operatorAccounts,
    summary: 'List pending account requests', parameters: [params.partyQuery], responses: { 200: 'AccountRequestList' },
    handler: async (ctx, s) => ok(await s.operator.listAccountRequests({ query: ctx.query })),
  });
  operatorCommand({
    operationId: 'acceptAccountRequest', method: 'post', path: '/registry/bdar/v1/admin/account-requests/{accountRequestId}/accept', tag: TAGS.operatorAccounts,
    summary: 'Accept an account request', description: 'Checks one account per owner, provider and id, and that every account party approved.',
    parameters: [contractIdParam('accountRequestId', 'account request')], body: 'EmptyRequest', bodyOptional: true,
    responses: { 200: 'AccountRequestAcceptResult' }, audit: 'accountRequest.accept',
    handler: async (ctx, s) => s.operator.acceptAccountRequest({ contractId: ctx.params.accountRequestId, ...cmd(ctx) }),
  });
  operatorCommand({
    operationId: 'rejectAccountRequest', method: 'post', path: '/registry/bdar/v1/admin/account-requests/{accountRequestId}/reject', tag: TAGS.operatorAccounts,
    summary: 'Reject an account request', parameters: [contractIdParam('accountRequestId', 'account request')], body: 'ReasonRequest',
    responses: { 200: 'TransactionResult' }, audit: 'accountRequest.reject',
    handler: async (ctx, s) => s.operator.rejectAccountRequest({ contractId: ctx.params.accountRequestId, ...cmd(ctx) }),
  });
  operatorRead({
    operationId: 'listAccounts', method: 'get', path: '/registry/bdar/v1/admin/accounts', tag: TAGS.operatorAccounts,
    summary: 'List accounts', parameters: [params.partyQuery, { name: 'status', in: 'query', required: false, schema: { type: 'string', enum: ['ACTIVE', 'FROZEN'] } }],
    responses: { 200: 'BdarAccountList' },
    handler: async (ctx, s) => ok(await s.operator.listAccounts({ query: ctx.query })),
  });
  operatorCommand({
    operationId: 'freezeAccount', method: 'post', path: '/registry/bdar/v1/admin/accounts/freeze', tag: TAGS.operatorAccounts,
    summary: 'Freeze an account', description: 'Blocks every movement of value from or to the account until it is unfrozen.',
    body: 'AccountFreezeRequest', responses: { 200: 'AccountResult' }, audit: 'account.freeze',
    handler: async (ctx, s) => s.operator.freezeAccount(cmd(ctx)),
  });
  operatorCommand({
    operationId: 'unfreezeAccount', method: 'post', path: '/registry/bdar/v1/admin/accounts/unfreeze', tag: TAGS.operatorAccounts,
    summary: 'Unfreeze an account', body: 'AccountUnfreezeRequest', responses: { 200: 'AccountResult' }, audit: 'account.unfreeze',
    handler: async (ctx, s) => s.operator.unfreezeAccount(cmd(ctx)),
  });
  operatorCommand({
    operationId: 'clawbackHoldings', method: 'post', path: '/registry/bdar/v1/admin/accounts/clawback', tag: TAGS.operatorAccounts,
    summary: 'Claw back holdings', description: 'Seizes holdings of an explicit account and burns them or moves them to a recovery account.',
    body: 'ClawbackRequest', responses: { 200: 'ClawbackResult' }, audit: 'account.clawback',
    handler: async (ctx, s) => s.operator.clawback(cmd(ctx)),
  });
  operatorRead({
    operationId: 'listAllowlist', method: 'get', path: '/registry/bdar/v1/admin/allowlist', tag: TAGS.operatorAccounts,
    summary: 'List allowlist entries', parameters: [params.instrumentIdQuery, params.partyQuery], responses: { 200: 'AllowlistEntryList' },
    handler: async (ctx, s) => ok(await s.operator.listAllowlist({ query: ctx.query })),
  });
  operatorCommand({
    operationId: 'addAllowlistEntry', method: 'post', path: '/registry/bdar/v1/admin/allowlist', tag: TAGS.operatorAccounts,
    summary: 'Add an allowlist entry', body: 'AllowlistAddRequest', responses: { 201: 'TransactionResult' }, audit: 'allowlist.add',
    handler: async (ctx, s) => s.operator.addAllowlistEntry(cmd(ctx)),
  });
  operatorCommand({
    operationId: 'revokeAllowlistEntry', method: 'post', path: '/registry/bdar/v1/admin/allowlist/revoke', tag: TAGS.operatorAccounts,
    summary: 'Revoke an allowlist entry', body: 'AllowlistRevokeRequest', responses: { 200: 'TransactionResult' }, audit: 'allowlist.revoke',
    handler: async (ctx, s) => s.operator.revokeAllowlistEntry(cmd(ctx)),
  });

  operatorRead({
    operationId: 'listMintRequests', method: 'get', path: '/registry/bdar/v1/admin/mint-requests', tag: TAGS.operatorIssuance,
    summary: 'List mint requests awaiting approval', parameters: [params.instrumentIdQuery], responses: { 200: 'MintRequestList' },
    handler: async (ctx, s) => ok(await s.operator.listMintRequests({ query: ctx.query })),
  });
  operatorCommand({
    operationId: 'approveMintRequest', method: 'post', path: '/registry/bdar/v1/admin/mint-requests/{mintRequestId}/approve', tag: TAGS.operatorIssuance,
    summary: 'Approve a mint request', description: 'Runs every mint check again and mints (or offers) the tokens.',
    parameters: [contractIdParam('mintRequestId', 'mint request')], body: 'EmptyRequest', bodyOptional: true,
    responses: { 200: 'MintApprovalResult' }, audit: 'mintRequest.approve',
    handler: async (ctx, s) => s.operator.approveMintRequest({ contractId: ctx.params.mintRequestId, ...cmd(ctx) }),
  });
  operatorCommand({
    operationId: 'rejectMintRequest', method: 'post', path: '/registry/bdar/v1/admin/mint-requests/{mintRequestId}/reject', tag: TAGS.operatorIssuance,
    summary: 'Reject a mint request', parameters: [contractIdParam('mintRequestId', 'mint request')], body: 'ReasonRequest',
    responses: { 200: 'TransactionResult' }, audit: 'mintRequest.reject',
    handler: async (ctx, s) => s.operator.rejectMintRequest({ contractId: ctx.params.mintRequestId, ...cmd(ctx) }),
  });

  for (const [name, method, description] of [
    ['expire-transfer-instructions', 'expireTransferInstructions', 'Releases locked holdings of transfer instructions whose executeBefore has passed.'],
    ['cancel-expired-allocations', 'cancelExpiredAllocations', 'Cancels allocations past their expiry and releases the funds to the authorizer.'],
    ['expire-preapprovals', 'expirePreapprovals', 'Archives transfer preapprovals past their expiry.'],
  ]) {
    operatorCommand({
      operationId: method, method: 'post', path: `/registry/bdar/v1/admin/housekeeping/${name}`, tag: TAGS.operatorHousekeeping,
      summary: description.split(' ').slice(0, 4).join(' '), description, body: 'HousekeepingRequest', bodyOptional: true,
      responses: { 200: 'HousekeepingReport' }, audit: `housekeeping.${method}`,
      handler: async (ctx, s) => s.operator[method](cmd(ctx)),
    });
  }

  add({
    operationId: 'listAuditEvents', method: 'get', path: '/registry/bdar/v1/admin/audit-events', tag: TAGS.audit, auth: 'apiKey',
    scopes: [Scopes.AUDIT_READ], rateLimit: 'operator', summary: 'List audit events',
    parameters: [
      { name: 'from', in: 'query', required: false, schema: { type: 'string', format: 'date-time' } },
      { name: 'to', in: 'query', required: false, schema: { type: 'string', format: 'date-time' } },
      { name: 'action', in: 'query', required: false, schema: { type: 'string', maxLength: 128 } },
      { name: 'apiKeyId', in: 'query', required: false, schema: { type: 'string', pattern: '^[a-z0-9]{16}$' } },
      { name: 'limit', in: 'query', required: false, schema: { type: 'integer', minimum: 1, maximum: 1000, default: 100 } },
    ],
    responses: { 200: 'AuditEventList' }, errors: [400, 401, 403, 429],
    handler: async (ctx, s) => ok({
      items: await s.audit.list({
        from: ctx.query.from ? new Date(ctx.query.from) : undefined,
        to: ctx.query.to ? new Date(ctx.query.to) : undefined,
        action: ctx.query.action, apiKeyId: ctx.query.apiKeyId, limit: ctx.query.limit ?? 100,
      }),
    }),
  });

  // ===================================================================== API keys

  const keyRoute = (route) => add({ auth: 'apiKey', scopes: [Scopes.KEYS_MANAGE], rateLimit: 'keys', errors: [400, 401, 403, 404, 409, 415, 429], ...route });
  keyRoute({
    operationId: 'createApiKey', method: 'post', path: '/admin/v1/api-keys', tag: TAGS.keys, idempotent: true,
    summary: 'Create an API key', description: 'Returns the plaintext key once. A caller can only grant scopes and parties it holds itself.',
    body: 'ApiKeyCreateRequest', responses: { 201: 'ApiKeySecretResponse' }, audit: 'apiKey.create.request',
    handler: async (ctx, s) => {
      requireGrantable(ctx.auth, ctx.body);
      return created(await s.apiKeys.create(ctx.body, `key:${ctx.auth.keyId}`));
    },
  });
  keyRoute({
    operationId: 'listApiKeys', method: 'get', path: '/admin/v1/api-keys', tag: TAGS.keys, summary: 'List API keys',
    parameters: [
      { name: 'status', in: 'query', required: false, schema: { type: 'string', enum: ['active', 'revoked'] } },
      { name: 'clientName', in: 'query', required: false, schema: { type: 'string', maxLength: 128 } },
    ],
    responses: { 200: 'ApiKeyList' },
    handler: async (ctx, s) => ok({ items: await s.apiKeys.list(ctx.query) }),
  });
  keyRoute({
    operationId: 'getApiKey', method: 'get', path: '/admin/v1/api-keys/{keyId}', tag: TAGS.keys, summary: 'Get an API key',
    parameters: [params.keyId], responses: { 200: 'ApiKey' },
    handler: async (ctx, s) => ok(await s.apiKeys.get(ctx.params.keyId)),
  });
  keyRoute({
    operationId: 'updateApiKey', method: 'patch', path: '/admin/v1/api-keys/{keyId}', tag: TAGS.keys, summary: 'Update an API key',
    description: 'Changes description, scopes, parties, tier or expiry. The secret does not change.',
    parameters: [params.keyId], body: 'ApiKeyUpdateRequest', responses: { 200: 'ApiKey' }, audit: 'apiKey.update.request',
    handler: async (ctx, s) => {
      requireGrantable(ctx.auth, ctx.body);
      if (ctx.params.keyId === ctx.auth.keyId) throw apiError('FORBIDDEN_SCOPE', 'A key cannot change its own scopes or parties');
      return ok(await s.apiKeys.update(ctx.params.keyId, ctx.body, `key:${ctx.auth.keyId}`));
    },
  });
  keyRoute({
    operationId: 'rotateApiKey', method: 'post', path: '/admin/v1/api-keys/{keyId}/rotate', tag: TAGS.keys, idempotent: true,
    summary: 'Rotate an API key', description: 'Issues a new secret for the same key id. The old secret keeps working for overlapHours (default 24).',
    parameters: [params.keyId], body: 'ApiKeyRotateRequest', bodyOptional: true, responses: { 200: 'ApiKeySecretResponse' }, audit: 'apiKey.rotate.request',
    handler: async (ctx, s) => ok(await s.apiKeys.rotate(ctx.params.keyId, ctx.body ?? {}, `key:${ctx.auth.keyId}`)),
  });
  keyRoute({
    operationId: 'revokeApiKey', method: 'post', path: '/admin/v1/api-keys/{keyId}/revoke', tag: TAGS.keys,
    summary: 'Revoke an API key', description: 'Permanent. Takes effect on every instance within API_KEY_CACHE_TTL_MS.',
    parameters: [params.keyId], body: 'ReasonRequest', responses: { 200: 'ApiKey' }, audit: 'apiKey.revoke.request',
    handler: async (ctx, s) => {
      if (ctx.params.keyId === ctx.auth.keyId) throw apiError('CONFLICT', 'A key cannot revoke itself');
      return ok(await s.apiKeys.revoke(ctx.params.keyId, ctx.body, `key:${ctx.auth.keyId}`));
    },
  });

  // Every idempotent route documents the header.
  for (const route of routes) {
    if (route.idempotent) route.parameters = [...(route.parameters ?? []), params.idempotencyKey];
  }
  return routes;
}

export { TAGS };
