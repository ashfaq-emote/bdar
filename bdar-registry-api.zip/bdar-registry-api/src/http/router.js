/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Turns the route table into an Express router.
 *
 * Middleware order for an authenticated route, and why:
 *   1. authenticate          who is calling (401 before anything else is revealed)
 *   2. rateLimit             per key limits need the key id, so they come after authentication
 *   3. requireScopes         may this key call this operation (403)
 *   4. requireJsonBody       415 for a body that is not JSON
 *   5. requireIdempotencyKey state changing operations need the header (400)
 *   6. validate              path, query and body against the schemas (400)
 *   7. handler               through the idempotency service and the audit trail
 *
 * A public route (ping, health) only has rateLimit (by IP) and the handler.
 */

import { Router } from 'express';
import { apiError } from '../lib/errors.js';
import {
  authenticate, rateLimit, requireIdempotencyKey, requireJsonBody, requireScopes,
} from '../security/middleware.js';

export const toExpressPath = (path) => path.replace(/\{([A-Za-z0-9_]+)\}/g, ':$1');

/** The resource id an audit event refers to: the first path parameter, if any. */
const resourceIdOf = (params) => Object.values(params ?? {})[0] ?? null;

/**
 * @param {{ routes: object[], services: object, apiKeyService: object, rateLimiter: object, audit: object,
 *           idempotency: object, validator: object, logger: object }} deps
 */
export function createRouter({ routes, services, apiKeyService, rateLimiter, audit, idempotency, validator, logger }) {
  const router = Router();
  const methodsByPath = new Map();

  for (const route of routes) {
    const expressPath = toExpressPath(route.path);
    methodsByPath.set(expressPath, [...(methodsByPath.get(expressPath) ?? []), route.method.toUpperCase()]);
    const validate = validator.compileRoute(route);
    const chain = [];

    if (route.auth === 'apiKey') chain.push(authenticate({ apiKeyService, rateLimiter, audit, logger }));
    chain.push(rateLimit({ rateLimiter, policy: route.rateLimit }));
    if (route.auth === 'apiKey') chain.push(requireScopes(route.scopes));
    if (route.body) chain.push(requireJsonBody());
    if (route.idempotent) chain.push(requireIdempotencyKey());

    chain.push(async function routeHandler(req, res) {
      req.operationId = route.operationId;
      const ctx = {
        operationId: route.operationId,
        params: { ...req.params },
        query: { ...req.query },
        body: req.body,
        auth: req.auth,
        requestId: req.id,
        idempotencyKey: req.idempotencyKey,
        ip: req.ip,
        userAgent: req.headers['user-agent'],
      };

      const auditEvent = (outcome, httpStatus, extra = {}) => route.audit && audit.record({
        requestId: ctx.requestId,
        apiKeyId: ctx.auth?.keyId,
        clientName: ctx.auth?.clientName,
        action: route.audit,
        resourceType: route.tag,
        resourceId: resourceIdOf(ctx.params),
        outcome,
        httpStatus,
        sourceIp: ctx.ip,
        userAgent: ctx.userAgent,
        ...extra,
        details: { operationId: route.operationId, params: ctx.params, body: ctx.body, ...(extra.details ?? {}) },
      });

      try {
        validate(ctx);
        let result;
        if (route.idempotent) {
          result = await idempotency.run(
            { apiKeyId: ctx.auth.keyId, idempotencyKey: ctx.idempotencyKey, request: { operationId: route.operationId, params: ctx.params, body: ctx.body } },
            () => route.handler(ctx, services),
          );
          if (result.replayed) res.setHeader('Idempotent-Replayed', 'true');
        } else {
          result = await route.handler(ctx, services);
        }
        const ledgerUpdateId = result.body?.transaction?.updateId ?? result.body?.updateId;
        await auditEvent('success', result.status, { ledgerUpdateId, details: { replayed: Boolean(result.replayed) } });
        res.status(result.status).json(result.body);
      } catch (error) {
        const status = error.status ?? 500;
        await auditEvent(status === 403 ? 'denied' : 'failure', status, { details: { code: error.code ?? 'INTERNAL_ERROR' } });
        throw error;
      }
    });

    router[route.method](expressPath, ...chain);
  }

  // A known path with an unsupported method is 405, not 404.
  for (const [path, methods] of methodsByPath) {
    router.all(path, (req, res, next) => next(apiError('METHOD_NOT_ALLOWED', undefined, { headers: { Allow: methods.join(', ') } })));
  }
  return router;
}
