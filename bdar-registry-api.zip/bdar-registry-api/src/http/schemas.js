/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * JSON schemas for requests and responses.
 *
 * One source of truth: the same schemas validate requests at runtime (Ajv) and are
 * published in the OpenAPI document. They use the OpenAPI 3.0 dialect of JSON Schema
 * (for example `nullable: true`).
 *
 * Request schemas for Broadridge endpoints set `additionalProperties: false`, so an
 * unexpected field is a 400 rather than being silently ignored (OWASP API3, mass
 * assignment). Token standard request schemas allow extra fields, because the
 * standard defines the choice arguments by the Daml JSON encoding and wallets may
 * send fields this registry does not use.
 */

import { ALL_SCOPES } from '../security/scopes.js';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

export const ref = (name) => ({ $ref: `#/components/schemas/${name}` });
const str = (extra = {}) => ({ type: 'string', ...extra });
const bool = (extra = {}) => ({ type: 'boolean', ...extra });
const int = (extra = {}) => ({ type: 'integer', ...extra });
const arr = (items, extra = {}) => ({ type: 'array', items, ...extra });
/** OpenAPI 3.0 has no null type. A $ref cannot carry siblings, so wrap it in allOf. */
const nullable = (schema) => (schema.$ref ? { allOf: [schema], nullable: true } : { ...schema, nullable: true });
/** OpenAPI 3.0 does not allow an empty `required` list, so it is left out when empty. */
const withRequired = (required) => (required.length > 0 ? { required } : {});
const strict = (properties, required = [], extra = {}) => ({ type: 'object', additionalProperties: false, properties, ...withRequired(required), ...extra });
const open = (properties, required = [], extra = {}) => ({ type: 'object', properties, ...withRequired(required), ...extra });
const page = (itemName) => open({ items: arr(ref(itemName)), nextPageToken: str({ description: 'Pass as pageToken to get the next page. Absent on the last page.' }) }, ['items']);
const list = (itemName) => open({ items: arr(ref(itemName)) }, ['items']);
const withDescription = (schema, description) => ({ ...schema, description });

const PARTY = str({ minLength: 3, maxLength: 255, pattern: '^[A-Za-z0-9._:\\-]+::[0-9A-Fa-f]+$', description: 'A Canton party id (hint::fingerprint).', example: 'PartyA::1220a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90' });
const CONTRACT_ID = str({ minLength: 2, maxLength: 512, pattern: '^[0-9A-Fa-f]+$', description: 'A Daml contract id.', example: '00b7c1e0f6d5a4b3c2d1e0f9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8' });
const DECIMAL = str({ pattern: '^[0-9]{1,28}(\\.[0-9]{1,10})?$', description: 'A non negative decimal with up to 10 decimal places, as a string.', example: '10000000.00' });
const TIMESTAMP = str({ format: 'date-time', example: '2026-09-15T14:00:00Z' });
const INSTRUMENT_ID = str({ minLength: 1, maxLength: 128, pattern: '^[A-Za-z0-9._:/\\-]+$', example: '912828CN5' });
const REASON = str({ minLength: 1, maxLength: 1000, pattern: '\\S' });
const REFERENCE = str({ minLength: 1, maxLength: 256, pattern: '\\S' });
const META_VALUES = { type: 'object', additionalProperties: str({ maxLength: 4096 }), maxProperties: 64 };
const IDEMPOTENT_NOTE = 'Send an Idempotency-Key header. A retry with the same key and body returns the first response.';

// ---------------------------------------------------------------------------
// Component schemas
// ---------------------------------------------------------------------------

export const schemas = {
  Party: PARTY,

  Error: open({
    error: str({ description: 'Human readable message. Do not parse it; use code.' }),
    code: str({ description: 'Stable error code.', example: 'VALIDATION_FAILED' }),
    status: int({ example: 400 }),
    requestId: str({ description: 'Quote this when you contact Broadridge support.' }),
    details: arr({ type: 'object' }),
    ledgerError: open({
      code: str(), errorId: str({ description: 'Broadridge registry error id, for example broadridge.com/bdar/account-frozen.' }),
      cause: str(), correlationId: str(),
    }),
  }, ['error'], { description: 'Error body. Compatible with the token standard ErrorResponse, which only requires error.' }),

  Metadata: open({ values: META_VALUES }, ['values'], { description: 'Daml Metadata record.' }),

  Account: open({
    owner: nullable(PARTY),
    provider: nullable(PARTY),
    id: str({ maxLength: 256, description: 'Account id. Empty for a basic account. cip-112/mint and cip-112/burn are the mint and burn accounts.' }),
  }, [], { description: 'A CIP-112 account. A basic account has an owner, no provider and an empty id.' }),

  StrictAccount: strict({
    owner: PARTY,
    provider: nullable(PARTY),
    id: str({ maxLength: 256 }),
  }, ['owner'], { description: 'A regular account (owner required).' }),

  InstrumentRef: open({ admin: PARTY, id: INSTRUMENT_ID }, ['admin', 'id']),

  // ----------------------------------------------------------- token standard

  SupportedApis: { type: 'object', additionalProperties: int({ format: 'int32' }), description: 'Map of token standard API name to supported minor version.' },

  GetRegistryInfoResponse: open({ adminId: PARTY, supportedApis: ref('SupportedApis') }, ['adminId', 'supportedApis']),

  Instrument: open({
    id: str(), name: str(), symbol: str(), totalSupply: str(), totalSupplyAsOf: TIMESTAMP,
    decimals: int({ minimum: 0, maximum: 10 }), paused: bool(),
    pauseInfo: open({ reason: str(), until: TIMESTAMP }),
    supportedApis: ref('SupportedApis'),
    showAccountInputFields: bool({ deprecated: true }),
    accountInputFieldsToShow: arr(str({ enum: ['provider', 'accountId'] }), { uniqueItems: true }),
  }, ['id', 'name', 'symbol', 'decimals', 'supportedApis']),

  ListInstrumentsResponse: open({ instruments: arr(ref('Instrument')), nextPageToken: str() }, ['instruments']),

  DisclosedContract: open({
    templateId: str(), contractId: str(), createdEventBlob: str(), synchronizerId: str(),
    debugPackageName: str(), debugPayload: { type: 'object' }, debugCreatedAt: TIMESTAMP,
  }, ['templateId', 'contractId', 'createdEventBlob', 'synchronizerId']),

  ChoiceContext: open({
    choiceContextData: { type: 'object', description: 'Pass as extraArgs.context of the choice.' },
    disclosedContracts: arr(ref('DisclosedContract')),
  }, ['choiceContextData', 'disclosedContracts']),

  TransferFactoryWithChoiceContext: open({
    factoryId: CONTRACT_ID,
    transferKind: str({ enum: ['self', 'direct', 'offer'] }),
    choiceContext: ref('ChoiceContext'),
  }, ['factoryId', 'transferKind', 'choiceContext']),

  FactoryWithChoiceContext: open({ factoryId: CONTRACT_ID, choiceContext: ref('ChoiceContext') }, ['factoryId', 'choiceContext']),

  GetChoiceContextRequest: open({
    meta: META_VALUES,
    excludeDebugFields: bool({ default: false }),
  }, [], { description: 'Request for the context of a choice on an existing contract.' }),

  TransferV1: open({
    sender: PARTY, receiver: PARTY, amount: DECIMAL, instrumentId: ref('InstrumentRef'),
    requestedAt: TIMESTAMP, executeBefore: TIMESTAMP, inputHoldingCids: arr(CONTRACT_ID, { maxItems: 100 }), meta: ref('Metadata'),
  }, ['sender', 'receiver', 'amount', 'instrumentId', 'requestedAt', 'executeBefore']),

  TransferV2: open({
    sender: ref('Account'), receiver: ref('Account'), amount: DECIMAL, instrumentId: ref('InstrumentRef'),
    requestedAt: TIMESTAMP, executeBefore: TIMESTAMP, inputHoldingCids: arr(CONTRACT_ID, { maxItems: 100 }), meta: ref('Metadata'),
  }, ['sender', 'receiver', 'amount', 'instrumentId', 'requestedAt', 'executeBefore']),

  TransferFactoryRequestV1: open({
    choiceArguments: open({ expectedAdmin: PARTY, transfer: ref('TransferV1'), extraArgs: { type: 'object' } }, ['expectedAdmin', 'transfer']),
    excludeDebugFields: bool({ default: false }),
  }, ['choiceArguments'], { description: 'Arguments of TransferFactory_Transfer (V1), Daml JSON encoded, with empty extraArgs.' }),

  TransferFactoryRequestV2: open({
    choiceArguments: open({ transfer: ref('TransferV2'), actors: arr(PARTY, { maxItems: 20 }), extraArgs: { type: 'object' } }, ['transfer']),
    excludeDebugFields: bool({ default: false }),
  }, ['choiceArguments'], { description: 'Arguments of TransferFactory_Transfer (V2), Daml JSON encoded, with empty extraArgs.' }),

  TransferLegSide: open({
    transferLegId: str({ maxLength: 256 }), side: str({ enum: ['SenderSide', 'ReceiverSide'] }), otherside: ref('Account'),
    amount: DECIMAL, instrumentId: INSTRUMENT_ID, meta: ref('Metadata'),
  }, ['transferLegId', 'side', 'otherside', 'amount', 'instrumentId']),

  SettlementInfoV2: open({
    executors: arr(PARTY, { minItems: 1, maxItems: 20 }), id: str({ maxLength: 256 }), cid: nullable(CONTRACT_ID), meta: ref('Metadata'),
  }, ['executors', 'id']),

  AllocationSpecificationV2: open({
    admin: PARTY, authorizer: ref('Account'), transferLegSides: arr(ref('TransferLegSide'), { minItems: 1, maxItems: 100 }),
    settlementDeadline: nullable(TIMESTAMP), nextIterationFunding: nullable({ type: 'object', additionalProperties: DECIMAL }),
    committed: bool(), meta: ref('Metadata'),
  }, ['admin', 'authorizer', 'transferLegSides']),

  AllocationFactoryRequestV1: open({
    choiceArguments: open({
      expectedAdmin: PARTY,
      allocation: open({
        settlement: open({ executor: PARTY, settlementRef: { type: 'object' }, requestedAt: TIMESTAMP, allocateBefore: TIMESTAMP, settleBefore: TIMESTAMP, meta: ref('Metadata') }, ['executor']),
        transferLegId: str({ maxLength: 256 }),
        transferLeg: open({ sender: PARTY, receiver: PARTY, amount: DECIMAL, instrumentId: ref('InstrumentRef'), meta: ref('Metadata') }, ['sender', 'receiver', 'amount', 'instrumentId']),
      }, ['settlement', 'transferLegId', 'transferLeg']),
      requestedAt: TIMESTAMP, inputHoldingCids: arr(CONTRACT_ID, { maxItems: 100 }), extraArgs: { type: 'object' },
    }, ['expectedAdmin', 'allocation']),
    excludeDebugFields: bool({ default: false }),
  }, ['choiceArguments']),

  AllocationFactoryRequestV2: open({
    choiceArguments: open({
      settlement: ref('SettlementInfoV2'), allocation: ref('AllocationSpecificationV2'), requestedAt: TIMESTAMP,
      inputHoldingCids: arr(CONTRACT_ID, { maxItems: 100 }), extraArgs: { type: 'object' }, actors: arr(PARTY, { maxItems: 20 }),
    }, ['settlement', 'allocation']),
    excludeDebugFields: bool({ default: false }),
  }, ['choiceArguments']),

  SettlementFactoryRequest: open({
    choiceArguments: open({
      settlement: ref('SettlementInfoV2'),
      transferLegs: arr(open({
        transferLegId: str({ maxLength: 256 }), sender: ref('Account'), receiver: ref('Account'), amount: DECIMAL, instrumentId: INSTRUMENT_ID, meta: ref('Metadata'),
      }, ['transferLegId', 'sender', 'receiver', 'amount', 'instrumentId']), { maxItems: 200 }),
      allocations: arr(open({
        allocationCid: CONTRACT_ID, extraTransferLegSides: arr(ref('TransferLegSide'), { maxItems: 100 }),
        nextIterationFunding: nullable({ type: 'object', additionalProperties: DECIMAL }),
      }, ['allocationCid']), { maxItems: 1000 }),
      actors: arr(PARTY, { maxItems: 20 }),
      extraArgs: { type: 'object' },
    }, ['settlement', 'transferLegs', 'allocations']),
    excludeDebugFields: bool({ default: false }),
  }, ['choiceArguments']),

  // -------------------------------------------------------- Broadridge: issuance

  IssuanceFactoryRequest: strict({
    choiceArguments: strict({
      issuer: PARTY,
      details: strict({
        instrumentId: INSTRUMENT_ID, receiver: ref('Account'), amount: DECIMAL, reference: REFERENCE,
        requestedAt: TIMESTAMP, executeBefore: TIMESTAMP,
      }, ['instrumentId', 'receiver', 'amount', 'reference', 'requestedAt', 'executeBefore']),
      extraArgs: { type: 'object' },
    }, ['issuer', 'details']),
    excludeDebugFields: bool({ default: false }),
  }, ['choiceArguments']),

  IssuanceFactoryResponse: open({
    factoryId: CONTRACT_ID,
    factoryTemplateId: str({ description: 'Template id to use in the ExerciseCommand.' }),
    mintOutcome: str({ enum: ['AWAITING_APPROVAL', 'DIRECT', 'OFFER'], description: 'What the mint will do if it succeeds now.' }),
    choiceContext: ref('ChoiceContext'),
  }, ['factoryId', 'mintOutcome', 'choiceContext']),

  // ----------------------------------------------------- Broadridge: instruments

  InstrumentPolicies: strict({
    issuers: arr(PARTY, { minItems: 1, maxItems: 50, uniqueItems: true }),
    accountPolicy: str({ enum: ['IMPLICIT_BASIC', 'EXPLICIT'] }),
    eligibility: strict({
      allowlist: nullable(strict({ appliesTo: arr(str({ enum: ['HOLD', 'SEND', 'MINT', 'REDEEM'] }), { minItems: 1, uniqueItems: true }) }, ['appliesTo'])),
      credential: nullable(strict({
        enabled: bool(),
        trustedIssuers: arr(PARTY, { maxItems: 50 }),
        subject: str({ enum: ['OWNER', 'OWNER_AND_PROVIDER'] }),
        requirements: arr(strict({ registryAction: str({ enum: ['HOLD', 'SEND', 'MINT', 'REDEEM'] }), credentialAction: str({ minLength: 1, maxLength: 128 }) }, ['registryAction', 'credentialAction']), { maxItems: 20 }),
      }, ['enabled', 'trustedIssuers', 'subject', 'requirements'])),
    }, ['allowlist', 'credential']),
    supply: strict({ maxOutstandingSupply: nullable(DECIMAL), maxMintPerRequest: nullable(DECIMAL), mintApprovalRequired: bool() }, ['maxOutstandingSupply', 'maxMintPerRequest', 'mintApprovalRequired']),
    redemptionPolicy: str({ enum: ['DISABLED', 'IMMEDIATE', 'ISSUER_APPROVAL'] }),
    settlement: strict({
      maxTransferTtlSeconds: int({ minimum: 1, maximum: 31622400 }),
      maxAllocationTtlSeconds: int({ minimum: 1, maximum: 31622400 }),
      allowCommittedAllocations: bool(), allowIteratedSettlement: bool(), allowMintAndBurnAllocations: bool(),
    }, ['maxTransferTtlSeconds', 'maxAllocationTtlSeconds', 'allowCommittedAllocations', 'allowIteratedSettlement', 'allowMintAndBurnAllocations']),
    controls: strict({ clawbackEnabled: bool() }, ['clawbackEnabled']),
  }, ['issuers', 'accountPolicy', 'eligibility', 'supply', 'redemptionPolicy', 'settlement', 'controls']),

  BdarInstrument: open({
    instrumentId: INSTRUMENT_ID, contractId: CONTRACT_ID, admin: PARTY, name: str(), symbol: str(), decimals: int(),
    issuers: arr(PARTY), standards: str({ enum: ['V1_AND_V2', 'V2_ONLY'] }), accountPolicy: str({ enum: ['IMPLICIT_BASIC', 'EXPLICIT'] }),
    eligibility: { type: 'object' }, supply: { type: 'object' }, redemptionPolicy: str({ enum: ['DISABLED', 'IMMEDIATE', 'ISSUER_APPROVAL'] }),
    settlement: { type: 'object' }, controls: { type: 'object' },
    pause: nullable(open({ reason: str(), pausedUntil: nullable(TIMESTAMP) })),
    status: str({ enum: ['ACTIVE', 'RETIRED'] }), meta: META_VALUES, createdAt: TIMESTAMP,
  }, ['instrumentId', 'contractId', 'name', 'symbol', 'decimals', 'issuers', 'standards', 'status']),

  BdarInstrumentPage: page('BdarInstrument'),

  // -------------------------------------------------- Broadridge: party queries

  Lock: open({ holders: arr(PARTY), expiresAt: nullable(TIMESTAMP), expiresAfterSeconds: nullable(int()), context: nullable(str()) }),
  Holding: open({
    contractId: CONTRACT_ID, account: ref('Account'), instrumentId: ref('InstrumentRef'), amount: DECIMAL,
    lock: nullable(ref('Lock')), meta: META_VALUES, createdAt: TIMESTAMP,
  }, ['contractId', 'account', 'instrumentId', 'amount']),
  HoldingPage: page('Holding'),
  Balance: open({
    account: ref('Account'), instrumentId: ref('InstrumentRef'), total: DECIMAL, locked: DECIMAL, available: DECIMAL, holdingCount: int(),
  }, ['account', 'instrumentId', 'total', 'locked', 'available']),
  BalanceList: open({ asOf: TIMESTAMP, items: arr(ref('Balance')) }, ['items']),
  TransferInstruction: open({
    contractId: CONTRACT_ID, kind: str({ enum: ['TRANSFER', 'MINT', 'REDEMPTION'] }), status: str({ enum: ['PENDING_SENDER', 'PENDING_RECEIVER'] }),
    transfer: { type: 'object' }, approvals: arr(PARTY), lockedHoldingCids: arr(CONTRACT_ID), issuers: arr(PARTY),
    originalInstructionCid: nullable(CONTRACT_ID), createdAt: TIMESTAMP,
  }, ['contractId', 'kind', 'status', 'transfer']),
  TransferInstructionPage: page('TransferInstruction'),
  AllocationInstruction: open({
    contractId: CONTRACT_ID, settlement: { type: 'object' }, allocation: { type: 'object' }, requestedAt: TIMESTAMP,
    inputHoldingCids: arr(CONTRACT_ID), approvals: arr(PARTY), rules: { type: 'object' }, allocateBefore: nullable(TIMESTAMP),
  }, ['contractId', 'settlement', 'allocation']),
  AllocationInstructionPage: page('AllocationInstruction'),
  Allocation: open({
    contractId: CONTRACT_ID, standard: str({ enum: ['V1_AND_V2', 'V2_ONLY'] }), settlement: { type: 'object' }, allocation: { type: 'object' },
    lockedHoldingCids: arr(CONTRACT_ID), authorizers: arr(PARTY), withdrawers: arr(PARTY), createdAt: TIMESTAMP, expiresAt: TIMESTAMP,
    allocateBefore: nullable(TIMESTAMP), numIterations: int(), originalAllocationCid: nullable(CONTRACT_ID),
  }, ['contractId', 'settlement', 'allocation']),
  AllocationPage: page('Allocation'),
  PartyRule: strict({ canInitiate: bool(), mustApprove: bool() }, ['canInitiate', 'mustApprove']),
  AccountRules: strict({ owner: ref('PartyRule'), provider: nullable(ref('PartyRule')) }, ['owner']),
  BdarAccount: open({
    contractId: CONTRACT_ID, account: ref('Account'), accountKey: str(), rules: ref('AccountRules'), status: str({ enum: ['ACTIVE', 'FROZEN'] }),
    frozenReason: nullable(str()), purpose: str({ enum: ['CLIENT', 'RECOVERY'] }), termsReference: str(), meta: META_VALUES, createdAt: TIMESTAMP,
  }, ['contractId', 'account', 'accountKey', 'rules', 'status', 'purpose']),
  BdarAccountPage: page('BdarAccount'),
  AccountChange: {
    oneOf: [
      strict({ type: str({ enum: ['OPEN'] }), rules: ref('AccountRules'), purpose: str({ enum: ['CLIENT', 'RECOVERY'], description: 'Defaults to CLIENT.' }), termsReference: REFERENCE }, ['type', 'rules', 'termsReference']),
      strict({ type: str({ enum: ['CHANGE_RULES'] }), newRules: ref('AccountRules') }, ['type', 'newRules']),
      strict({ type: str({ enum: ['SET_PREAPPROVAL'] }), instrumentIds: nullable(arr(INSTRUMENT_ID, { maxItems: 100 })), expiresAt: nullable(TIMESTAMP) }, ['type']),
      strict({ type: str({ enum: ['CLOSE'] }) }, ['type']),
    ],
    description: 'The account change a request asks for.',
  },
  AccountRequest: open({
    contractId: CONTRACT_ID, account: ref('Account'), change: { type: 'object' }, approvals: arr(PARTY), missingApprovals: arr(PARTY),
    reference: str(), createdAt: TIMESTAMP,
  }, ['contractId', 'account', 'change', 'approvals']),
  AccountRequestPage: page('AccountRequest'),
  AccountRequestList: list('AccountRequest'),
  Preapproval: open({ contractId: CONTRACT_ID, account: ref('Account'), instrumentIds: nullable(arr(INSTRUMENT_ID)), expiresAt: nullable(TIMESTAMP), createdAt: TIMESTAMP }, ['contractId', 'account']),
  PreapprovalPage: page('Preapproval'),
  ClawbackRecord: open({
    contractId: CONTRACT_ID, account: ref('Account'), instrumentId: INSTRUMENT_ID, amount: DECIMAL, outcome: str({ enum: ['BURN', 'REASSIGN'] }),
    recoveryAccount: nullable(ref('Account')), reason: str(), acknowledged: bool(), createdAt: TIMESTAMP,
  }, ['contractId', 'account', 'instrumentId', 'amount', 'outcome']),
  ClawbackRecordPage: page('ClawbackRecord'),
  MintRequest: open({
    contractId: CONTRACT_ID, issuer: PARTY, instrumentId: INSTRUMENT_ID, receiver: ref('Account'), amount: DECIMAL, reference: str(),
    requestedAt: TIMESTAMP, executeBefore: TIMESTAMP, createdAt: TIMESTAMP,
  }, ['contractId', 'issuer', 'instrumentId', 'receiver', 'amount']),
  MintRequestPage: page('MintRequest'),
  MintRequestList: list('MintRequest'),

  AccountRequestValidationRequest: strict({
    account: ref('StrictAccount'),
    change: ref('AccountChange'),
    approvals: arr(PARTY, { minItems: 1, maxItems: 2, uniqueItems: true, description: 'Parties that sign the request now. Defaults to the first account party this key may act for.' }),
    reference: REFERENCE,
  }, ['account', 'change', 'reference']),

  AccountRequestValidationResponse: open({
    valid: bool(),
    problems: arr(open({ code: str(), message: str() })),
    warnings: arr(open({ code: str(), message: str() })),
    accountKey: str(),
    existingAccountCid: nullable(CONTRACT_ID),
    missingApprovals: arr(PARTY),
    createCommand: nullable({ type: 'object', description: 'A CreateCommand for BdarAccountRequest, ready for /submissions/prepare.' }),
    actAs: arr(PARTY),
  }, ['valid', 'problems', 'warnings']),

  // ------------------------------------------------- Broadridge: submissions

  PrepareRequest: strict({
    actAs: arr(PARTY, { minItems: 1, maxItems: 10, uniqueItems: true }),
    readAs: arr(PARTY, { maxItems: 10, uniqueItems: true }),
    commandId: str({ pattern: '^[A-Za-z0-9._:\\-]{8,128}$' }),
    commands: arr({ type: 'object', description: 'JSON Ledger API command: { "ExerciseCommand": {...} } or { "CreateCommand": {...} }.' }, { minItems: 1, maxItems: 20 }),
    disclosedContracts: arr(ref('DisclosedContract'), { maxItems: 2000 }),
    synchronizerId: str({ maxLength: 512 }),
  }, ['actAs', 'commands']),

  PrepareResponse: open({
    commandId: str(),
    preparedTransaction: str({ description: 'Base64 encoded prepared transaction. Decode and inspect it before signing.' }),
    preparedTransactionHash: str({ description: 'Base64 encoded hash to sign with the party key.' }),
    hashingSchemeVersion: str(),
  }, ['commandId', 'preparedTransaction', 'preparedTransactionHash', 'hashingSchemeVersion']),

  ExecuteRequest: strict({
    preparedTransaction: str({ minLength: 1, maxLength: 10000000 }),
    hashingSchemeVersion: str({ minLength: 1, maxLength: 64 }),
    partySignatures: strict({
      signatures: arr(strict({
        party: PARTY,
        signatures: arr(strict({
          format: str({ maxLength: 64 }), signature: str({ maxLength: 4096 }), signedBy: str({ maxLength: 512 }), signingAlgorithmSpec: str({ maxLength: 64 }),
        }, ['format', 'signature', 'signedBy', 'signingAlgorithmSpec']), { minItems: 1, maxItems: 10 }),
      }, ['party', 'signatures']), { minItems: 1, maxItems: 10 }),
    }, ['signatures']),
  }, ['preparedTransaction', 'hashingSchemeVersion', 'partySignatures']),

  ExecuteResponse: open({ submissionId: str(), updateId: str(), completionOffset: { oneOf: [int(), str()] } }, ['submissionId', 'updateId']),

  // ---------------------------------------------------- Broadridge: operator

  LedgerTransaction: open({
    commandId: str(), updateId: str(), offset: { oneOf: [int(), str()] },
    created: arr(open({ contractId: CONTRACT_ID, template: str() })),
    archived: arr(open({ contractId: CONTRACT_ID, template: str() })),
    exerciseResult: { description: 'Daml JSON encoded choice result.' },
  }),

  BootstrapRequest: strict({ registryName: str({ minLength: 1, maxLength: 256 }), credentialChecksEnabled: bool({ default: true }) }),
  BootstrapResponse: open({ alreadyBootstrapped: bool(), missingBefore: arr(str()), created: arr({ type: 'object' }) }, ['alreadyBootstrapped']),

  RegistryConfig: open({ contractId: CONTRACT_ID, admin: PARTY, registryName: str(), credentialChecksEnabled: bool(), meta: META_VALUES }),
  CredentialChecksRequest: strict({ enabled: bool() }, ['enabled']),
  RegistryConfigResult: open({ registryConfig: ref('RegistryConfig'), transaction: ref('LedgerTransaction') }),

  InstrumentDisplayRequest: strict({ name: str({ minLength: 1, maxLength: 256 }), symbol: str({ minLength: 1, maxLength: 32 }), meta: META_VALUES }, [], { minProperties: 1 }),
  PauseRequest: strict({ reason: REASON, pausedUntil: nullable(TIMESTAMP) }, ['reason']),
  InstrumentResult: open({ instrument: nullable(ref('BdarInstrument')), transaction: ref('LedgerTransaction') }),

  ReasonRequest: strict({ reason: REASON }, ['reason']),
  EmptyRequest: strict({}),
  AccountFreezeRequest: strict({ account: ref('StrictAccount'), reason: REASON }, ['account', 'reason']),
  AccountUnfreezeRequest: strict({ account: ref('StrictAccount') }, ['account']),
  AccountResult: open({ account: ref('BdarAccount'), transaction: ref('LedgerTransaction') }),
  AccountRequestAcceptResult: open({ accountKey: str(), transaction: ref('LedgerTransaction') }),
  ClawbackRequest: strict({
    account: ref('StrictAccount'), instrumentId: INSTRUMENT_ID,
    holdingCids: arr(CONTRACT_ID, { maxItems: 500, uniqueItems: true, description: 'Holdings to seize. Omit to seize every unlocked holding of the instrument.' }),
    outcome: str({ enum: ['BURN', 'REASSIGN'] }), recoveryAccount: ref('StrictAccount'), reason: REASON,
  }, ['account', 'instrumentId', 'outcome', 'reason'], { description: 'recoveryAccount is required when outcome is REASSIGN.' }),
  ClawbackResult: open({ holdingCids: arr(CONTRACT_ID), transaction: ref('LedgerTransaction') }),
  AllowlistEntry: open({ contractId: CONTRACT_ID, party: PARTY, instrumentId: INSTRUMENT_ID, validUntil: nullable(TIMESTAMP), reference: str(), createdAt: TIMESTAMP }),
  AllowlistEntryList: list('AllowlistEntry'),
  AllowlistAddRequest: strict({ party: PARTY, instrumentId: INSTRUMENT_ID, validUntil: nullable(TIMESTAMP), reference: REFERENCE }, ['party', 'instrumentId', 'reference']),
  AllowlistRevokeRequest: strict({ party: PARTY, instrumentId: INSTRUMENT_ID, reason: REASON }, ['party', 'instrumentId', 'reason']),
  BdarAccountList: list('BdarAccount'),
  TransactionResult: open({ transaction: ref('LedgerTransaction') }),
  MintApprovalResult: open({ mintResult: { type: 'object', nullable: true }, transaction: ref('LedgerTransaction') }),
  HousekeepingRequest: strict({ limit: int({ minimum: 1, maximum: 500, default: 50 }) }),
  HousekeepingReport: open({
    candidates: int(), processed: int(), remaining: int(),
    succeeded: arr(open({ contractId: CONTRACT_ID, updateId: str() })),
    failed: arr(open({ contractId: CONTRACT_ID, code: str(), error: str() })),
  }),
  AuditEvent: open({
    id: int(), occurredAt: TIMESTAMP, requestId: str(), apiKeyId: nullable(str()), clientName: nullable(str()), action: str(),
    resourceType: nullable(str()), resourceId: nullable(str()), outcome: str({ enum: ['success', 'failure', 'denied'] }),
    httpStatus: nullable(int()), ledgerUpdateId: nullable(str()), sourceIp: nullable(str()), details: { type: 'object' },
  }),
  AuditEventList: list('AuditEvent'),

  // --------------------------------------------------------------- API keys

  ApiKey: open({
    keyId: str({ pattern: '^[a-z0-9]{16}$' }), clientName: str(), description: str(), environment: str({ enum: ['dev', 'test', 'uat', 'live'] }),
    scopes: arr(str({ enum: ALL_SCOPES })), allowedParties: arr(str()), rateLimitTier: str(), status: str({ enum: ['active', 'revoked'] }),
    createdAt: TIMESTAMP, createdBy: str(), updatedAt: TIMESTAMP, expiresAt: nullable(TIMESTAMP), lastUsedAt: nullable(TIMESTAMP),
    previousSecretExpiresAt: nullable(TIMESTAMP), revokedAt: nullable(TIMESTAMP), revokeReason: nullable(str()),
  }, ['keyId', 'clientName', 'scopes', 'allowedParties', 'status']),
  ApiKeyList: list('ApiKey'),
  ApiKeyCreateRequest: strict({
    clientName: str({ minLength: 1, maxLength: 128, pattern: '^[A-Za-z0-9 ._\\-]+$' }),
    description: str({ maxLength: 1000 }),
    scopes: arr(str({ enum: ALL_SCOPES }), { minItems: 1, uniqueItems: true }),
    allowedParties: arr({ anyOf: [PARTY, str({ enum: ['*'] })] }, { maxItems: 200, uniqueItems: true }),
    rateLimitTier: str({ maxLength: 32 }),
    expiresAt: nullable(TIMESTAMP),
  }, ['clientName', 'scopes']),
  ApiKeyUpdateRequest: strict({
    description: str({ maxLength: 1000 }),
    scopes: arr(str({ enum: ALL_SCOPES }), { minItems: 1, uniqueItems: true }),
    allowedParties: arr({ anyOf: [PARTY, str({ enum: ['*'] })] }, { maxItems: 200, uniqueItems: true }),
    rateLimitTier: str({ maxLength: 32 }),
    expiresAt: nullable(TIMESTAMP),
  }, [], { minProperties: 1 }),
  ApiKeyRotateRequest: strict({ overlapHours: int({ minimum: 0, maximum: 720 }) }),
  ApiKeySecretResponse: open({
    apiKey: str({ description: 'The plaintext key. Shown once. Store it in a secret manager now.', example: 'bdar_live_k3h9x2m4p8q1w7e5_<64 hex>_<8 hex>' }),
    key: ref('ApiKey'),
  }, ['apiKey', 'key']),
  WhoAmI: open({ keyId: str(), clientName: str(), scopes: arr(str()), allowedParties: arr(str()), rateLimitTier: str(), usingPreviousSecret: bool() }),

  // ------------------------------------------------------------------ system

  Ping: open({ status: str({ enum: ['ok'] }), time: TIMESTAMP }, ['status']),
  Liveness: open({ status: str({ enum: ['ok'] }) }, ['status']),
  Readiness: open({ status: str({ enum: ['ready', 'not-ready', 'shutting-down'] }), checks: { type: 'object', additionalProperties: str() } }, ['status']),
  HealthDetailed: open({
    status: str({ enum: ['up', 'degraded', 'down'] }), version: str(), environment: str(), nodeVersion: str(), startedAt: TIMESTAMP,
    uptimeSeconds: int(), memory: { type: 'object' }, settings: { type: 'object' }, checks: arr({ type: 'object' }),
  }, ['status']),
};

// The create request is the display fields plus every policy field, in one flat object.
schemas.InstrumentCreateRequest = strict(
  {
    instrumentId: INSTRUMENT_ID,
    name: str({ minLength: 1, maxLength: 256 }),
    symbol: str({ minLength: 1, maxLength: 32 }),
    decimals: int({ minimum: 0, maximum: 10 }),
    standards: str({ enum: ['V1_AND_V2', 'V2_ONLY'] }),
    meta: META_VALUES,
    ...schemas.InstrumentPolicies.properties,
  },
  ['instrumentId', 'name', 'symbol', 'decimals', 'standards', ...schemas.InstrumentPolicies.required],
);

// ---------------------------------------------------------------------------
// Parameters
// ---------------------------------------------------------------------------

export const params = {
  instrumentId: { name: 'instrumentId', in: 'path', required: true, schema: INSTRUMENT_ID },
  contractIdPath: (name, description) => ({ name, in: 'path', required: true, description, schema: CONTRACT_ID }),
  party: { name: 'party', in: 'path', required: true, description: 'The party whose contracts to list. The API key must be allowed to act for it.', schema: PARTY },
  keyId: { name: 'keyId', in: 'path', required: true, schema: str({ pattern: '^[a-z0-9]{16}$' }) },
  pageSize: { name: 'pageSize', in: 'query', required: false, schema: int({ minimum: 1, maximum: 500 }) },
  metadataPageSize: { name: 'pageSize', in: 'query', required: false, schema: int({ minimum: 1, maximum: 100, default: 25 }) },
  pageToken: { name: 'pageToken', in: 'query', required: false, schema: str({ maxLength: 512 }) },
  instrumentIdQuery: { name: 'instrumentId', in: 'query', required: false, schema: INSTRUMENT_ID },
  partyQuery: { name: 'party', in: 'query', required: false, schema: PARTY },
  idempotencyKey: {
    name: 'Idempotency-Key', in: 'header', required: true, description: IDEMPOTENT_NOTE,
    schema: str({ pattern: '^[A-Za-z0-9._:\\-]{8,128}$', example: 'freeze-2026-09-15-0001' }),
  },
};

export { IDEMPOTENT_NOTE, withDescription };
