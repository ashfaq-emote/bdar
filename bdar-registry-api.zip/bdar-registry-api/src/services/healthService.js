/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Ping and health checks.
 *
 *   GET /ping           no authentication. Proves the process answers HTTP. No dependency calls.
 *   GET /health/live    no authentication. Liveness probe: the event loop is not stuck.
 *   GET /health/ready   no authentication. Readiness probe: the ledger and the database answer.
 *   GET /health         operator:read. Detailed status of every dependency and non secret settings.
 *
 * Why the split: a load balancer or Kubernetes calls live and ready every few seconds,
 * so they must be cheap and must not reveal internals (OWASP API8). The detailed view
 * needs a key.
 *
 * Readiness results are cached for two seconds so that frequent probes cannot turn
 * into load on the ledger.
 */

import { TtlCache, noopLogger } from '../lib/util.js';

const withTimeout = (promise, ms, what) => Promise.race([
  promise,
  new Promise((_, reject) => setTimeout(() => reject(new Error(`${what} did not answer within ${ms} ms`)), ms).unref?.()),
]);

async function check(name, fn, timeoutMs) {
  const started = Date.now();
  try {
    const detail = await withTimeout(Promise.resolve().then(fn), timeoutMs, name);
    return { name, status: 'up', latencyMs: Date.now() - started, ...(detail && typeof detail === 'object' ? { detail } : {}) };
  } catch (error) {
    return { name, status: 'down', latencyMs: Date.now() - started, error: error.message };
  }
}

/**
 * @param {{ ledger: object, apiKeyRepository: object, rateLimitStore?: object, reader: object, config: object,
 *           version: string, startedAt?: Date, logger?: object, now?: () => Date }} deps
 */
export function createHealthService({ ledger, apiKeyRepository, rateLimitStore, reader, config, version, startedAt = new Date(), logger = noopLogger, now = () => new Date() }) {
  const cache = new TtlCache({ ttlMs: 2000, maxEntries: 4 });
  let shuttingDown = false;

  async function runChecks() {
    const checks = await Promise.all([
      check('ledger', async () => {
        const [info, offset] = await Promise.all([ledger.version(), ledger.ledgerEnd()]);
        return { version: info?.version, ledgerEnd: offset };
      }, 5000),
      check('database', async () => {
        await apiKeyRepository.ping();
        return { kind: apiKeyRepository.kind };
      }, 3000),
    ]);
    const rateLimiter = {
      name: 'rateLimitStore',
      status: rateLimitStore?.kind === 'memory-fallback' ? 'degraded' : 'up',
      detail: { kind: rateLimitStore?.kind ?? 'none', enabled: config.rateLimit.enabled },
    };
    const registry = await check('registry', async () => {
      const registryConfig = await reader.singleton('registryConfig');
      return { bootstrapped: true, registryConfigCid: registryConfig.contractId };
    }, 5000);
    if (registry.status === 'down') {
      // A registry that is not bootstrapped yet can still serve the bootstrap call.
      registry.status = 'warn';
    }
    return [...checks, rateLimiter, registry];
  }

  return {
    markShuttingDown() {
      shuttingDown = true;
    },

    ping() {
      return { status: 'ok', time: now().toISOString() };
    },

    live() {
      return { status: 'ok' };
    },

    /** Only up/down per dependency; no versions, hosts or error text. */
    async ready() {
      if (shuttingDown) return { ready: false, body: { status: 'shutting-down' } };
      const checks = await cache.getOrLoad('checks', runChecks);
      const required = checks.filter((c) => c.name === 'ledger' || c.name === 'database');
      const ready = required.every((c) => c.status === 'up');
      if (!ready) logger.warn({ checks }, 'readiness check failed');
      return {
        ready,
        body: { status: ready ? 'ready' : 'not-ready', checks: Object.fromEntries(checks.map((c) => [c.name, c.status])) },
      };
    },

    async detailed() {
      const checks = await runChecks();
      const status = checks.some((c) => (c.name === 'ledger' || c.name === 'database') && c.status === 'down') ? 'down'
        : checks.some((c) => c.status !== 'up') ? 'degraded' : 'up';
      const memory = process.memoryUsage();
      return {
        status,
        version,
        environment: config.apiEnvironment,
        nodeVersion: process.version,
        startedAt: startedAt.toISOString(),
        uptimeSeconds: Math.round((now().getTime() - startedAt.getTime()) / 1000),
        memory: { rssBytes: memory.rss, heapUsedBytes: memory.heapUsed },
        settings: {
          adminParty: config.registry.adminParty,
          ledgerAuthMode: config.ledger.authMode,
          rateLimitEnabled: config.rateLimit.enabled,
          contextCacheTtlMs: config.registry.contextCacheTtlMs,
          apiKeyCacheTtlMs: config.apiKeys.cacheTtlMs,
          openApiPublic: config.server.openApiPublic,
        },
        checks,
      };
    },
  };
}
