/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * The token standard registry endpoints (CIP-56 V1 and CIP-112 V2):
 *
 *   GET  /registry/metadata/v1/info
 *   GET  /registry/metadata/v1/instruments
 *   GET  /registry/metadata/v1/instruments/{instrumentId}
 *   POST /registry/transfer-instruction/v{1,2}/transfer-factory
 *   POST /registry/transfer-instruction/v{1,2}/{id}/choice-contexts/{accept|reject|withdraw}
 *   POST /registry/allocation-instruction/v{1,2}/allocation-factory
 *   POST /registry/allocation-instruction/v2/{id}/choice-contexts/{accept|withdraw}
 *   POST /registry/allocations/v1/{id}/choice-contexts/{execute-transfer|withdraw|cancel}
 *   POST /registry/allocation/v2/settlement-factory
 *   POST /registry/allocations/v2/{id}/choice-contexts/{withdraw|cancel}
 *
 * Every context endpoint follows the same four steps:
 *   1. Read the choice arguments (or the target contract) and check they belong to this registry.
 *   2. Party binding: the API key must be allowed to act for a party that can exercise the choice.
 *   3. Work out the instruments, accounts, parties and holdings the choice touches.
 *   4. Ask the context builder for exactly those proofs.
 */

import { apiError } from '../lib/errors.js';
import { decodeCursor, encodeCursor, unique } from '../lib/util.js';
import { requireAnyParty } from '../security/scopes.js';
import {
  accountKey, accountParties, basicAccount, isBurnAccount, isRegularAccount, isTemplate, normalizeAccount, sameAccount, tagOf,
} from '../registry/daml.js';
import {
  allocationCore, instrumentToMetadata, lockedHoldingsOfInstruction, registrySupportedApis,
} from '../registry/mappers.js';

/** Instrument ids used by a list of V2 transfer leg sides plus next iteration funding. */
const instrumentIdsOfSpec = (allocation) => unique([
  ...(allocation.transferLegSides ?? []).map((leg) => leg.instrumentId),
  ...Object.keys(allocation.nextIterationFunding ?? {}),
]);

/**
 * transferKind as the token standard defines it:
 *   self    sender and receiver are the same account (merge or split)
 *   direct  the registry credits the receiver in the same transaction
 *   offer   the receiver (or an issuer, for a redemption) must accept later
 */
export function transferKindOf({ sender, receiver, instrument, preapproval, actors }) {
  if (sameAccount(sender, receiver)) return 'self';
  if (isBurnAccount(receiver)) {
    return tagOf(instrument.payload.redemptionPolicy) === 'BdarRedeemImmediately' ? 'direct' : 'offer';
  }
  if (preapproval) return 'direct';
  const receiverParties = accountParties(receiver);
  if (Array.isArray(actors) && receiverParties.length > 0 && receiverParties.every((party) => actors.includes(party))) {
    return 'direct';
  }
  return 'offer';
}

/**
 * @param {{ reader: object, contextBuilder: object, adminParty: string, maxSettlementAllocations: number, now?: () => Date }} deps
 */
export function createTokenStandardService({ reader, contextBuilder, adminParty, maxSettlementAllocations = 50, now = () => new Date() }) {
  function requireAdmin(value, field) {
    if (value !== adminParty) {
      throw apiError('WRONG_ADMIN', undefined, { details: [{ field, expected: adminParty }] });
    }
  }

  async function requireInstrument(instrumentId) {
    const instrument = await reader.instrument(instrumentId);
    if (!instrument) throw apiError('INSTRUMENT_NOT_FOUND', undefined, { details: [{ instrumentId }] });
    return instrument;
  }

  /** Load a registry contract by id and check its template and admin. */
  async function requireContract(contractId, templateNames, adminOf) {
    const contract = await reader.contract(contractId);
    const matches = contract && templateNames.some((name) => isTemplate(contract.templateId, name));
    if (!matches || adminOf(contract.payload) !== adminParty) {
      throw apiError('CONTRACT_NOT_FOUND', undefined, { details: [{ contractId }] });
    }
    return contract;
  }

  function requireV1Standard(instrument) {
    if (tagOf(instrument.payload.standards) === 'BdarSupportsV2Only') {
      throw apiError('VALIDATION_FAILED', `Instrument ${instrument.payload.instrumentId} supports CIP-112 (V2) calls only`, {
        details: [{ instrumentId: instrument.payload.instrumentId, standards: 'V2_ONLY' }],
      });
    }
  }

  return {
    async getRegistryInfo() {
      return { adminId: adminParty, supportedApis: registrySupportedApis() };
    },

    async listInstruments({ pageSize = 25, pageToken } = {}) {
      const size = Math.min(Math.max(Number(pageSize) || 25, 1), 100);
      const after = pageToken === undefined ? undefined : decodeCursor(pageToken)?.after;
      if (pageToken !== undefined && typeof after !== 'string') {
        throw apiError('VALIDATION_FAILED', undefined, { details: [{ field: 'pageToken', message: 'is not a valid page token' }] });
      }
      const instruments = (await reader.instruments())
        .sort((a, b) => a.payload.instrumentId.localeCompare(b.payload.instrumentId))
        .filter((contract) => after === undefined || contract.payload.instrumentId > after);
      const page = instruments.slice(0, size);
      const asOf = now().toISOString();
      const items = await Promise.all(page.map(async (contract) => instrumentToMetadata(contract, await reader.supply(contract.payload.instrumentId), asOf)));
      const result = { instruments: items };
      if (instruments.length > size) result.nextPageToken = encodeCursor({ after: page.at(-1).payload.instrumentId });
      return result;
    },

    async getInstrument(instrumentId) {
      const contract = await requireInstrument(instrumentId);
      return instrumentToMetadata(contract, await reader.supply(instrumentId), now().toISOString());
    },

    // ---------------------------------------------------------------- transfers

    /** POST /registry/transfer-instruction/v{version}/transfer-factory */
    async getTransferFactory({ version, body, auth }) {
      const args = body.choiceArguments;
      let transfer;
      let actors;
      if (version === 1) {
        requireAdmin(args.expectedAdmin, 'choiceArguments.expectedAdmin');
        transfer = { ...args.transfer, sender: basicAccount(args.transfer.sender), receiver: basicAccount(args.transfer.receiver) };
        actors = [args.transfer.sender];
      } else {
        transfer = { ...args.transfer, sender: normalizeAccount(args.transfer.sender), receiver: normalizeAccount(args.transfer.receiver) };
        actors = args.actors;
      }
      requireAdmin(transfer.instrumentId.admin, 'choiceArguments.transfer.instrumentId.admin');
      if (!isRegularAccount(transfer.sender)) {
        throw apiError('VALIDATION_FAILED', 'The sender must be a regular account. Use the issuance endpoint to mint', {
          details: [{ field: 'choiceArguments.transfer.sender' }],
        });
      }
      requireAnyParty(auth, accountParties(transfer.sender));
      const instrument = await requireInstrument(transfer.instrumentId.id);
      if (version === 1) requireV1Standard(instrument);

      const { choiceContext, facts } = await contextBuilder.build({
        instrumentIds: [transfer.instrumentId.id],
        accounts: [transfer.sender, transfer.receiver],
        factories: ['transferFactory'],
        excludeDebugFields: body.excludeDebugFields,
      });
      const transferKind = transferKindOf({
        sender: transfer.sender,
        receiver: transfer.receiver,
        instrument,
        preapproval: facts.preapprovals.get(accountKey(transfer.receiver)),
        actors,
      });
      return { factoryId: facts.factories.get('transferFactory').contractId, transferKind, choiceContext };
    },

    /** POST /registry/transfer-instruction/v{version}/{id}/choice-contexts/{action} */
    async getTransferInstructionContext({ contractId, action, body, auth }) {
      const contract = await requireContract(contractId, ['transferInstruction'], (p) => p.admin);
      const instruction = contract.payload;
      const sender = normalizeAccount(instruction.transfer.sender);
      const receiver = normalizeAccount(instruction.transfer.receiver);
      const issuers = instruction.issuers ?? [];
      requireAnyParty(auth, [...accountParties(sender), ...accountParties(receiver), ...issuers]);
      // Mint offers and redemptions involve the issuers, who may need credentials.
      const involvesIssuers = !isRegularAccount(sender) || isBurnAccount(receiver);
      const { choiceContext } = await contextBuilder.build({
        instrumentIds: [instruction.transfer.instrumentId.id],
        accounts: [sender, receiver],
        parties: involvesIssuers && action !== 'reject' ? issuers : [],
        // The receiver (or issuer) cannot see the sender's locked holdings but accept
        // and reject archive them, so they are disclosed.
        holdingCids: lockedHoldingsOfInstruction(instruction),
        excludeDebugFields: body.excludeDebugFields,
      });
      return choiceContext;
    },

    // -------------------------------------------------------------- allocations

    /** POST /registry/allocation-instruction/v{version}/allocation-factory */
    async getAllocationFactory({ version, body, auth }) {
      const args = body.choiceArguments;
      let instrumentIds;
      let accounts;
      let parties = [];
      if (version === 1) {
        requireAdmin(args.expectedAdmin, 'choiceArguments.expectedAdmin');
        const leg = args.allocation.transferLeg;
        requireAdmin(leg.instrumentId.admin, 'choiceArguments.allocation.transferLeg.instrumentId.admin');
        requireAnyParty(auth, [leg.sender]);
        instrumentIds = [leg.instrumentId.id];
        accounts = [basicAccount(leg.sender)];
        requireV1Standard(await requireInstrument(leg.instrumentId.id));
      } else {
        const allocation = args.allocation;
        requireAdmin(allocation.admin, 'choiceArguments.allocation.admin');
        const authorizer = normalizeAccount(allocation.authorizer);
        const actors = args.actors ?? [];
        // A mint or burn allocation has no account parties; its actors are issuers.
        requireAnyParty(auth, isRegularAccount(authorizer) ? accountParties(authorizer) : actors);
        instrumentIds = instrumentIdsOfSpec(allocation);
        accounts = [authorizer];
        parties = isRegularAccount(authorizer) ? [] : actors;
      }
      const { choiceContext, facts } = await contextBuilder.build({
        instrumentIds, accounts, parties, factories: ['allocationFactory'], excludeDebugFields: body.excludeDebugFields,
      });
      return { factoryId: facts.factories.get('allocationFactory').contractId, choiceContext };
    },

    /** POST /registry/allocation-instruction/v2/{id}/choice-contexts/{accept|withdraw} */
    async getAllocationInstructionContext({ contractId, body, auth }) {
      const contract = await requireContract(contractId, ['allocationInstruction'], (p) => p.allocation.admin);
      const allocation = contract.payload.allocation;
      const authorizer = normalizeAccount(allocation.authorizer);
      requireAnyParty(auth, accountParties(authorizer));
      const { choiceContext } = await contextBuilder.build({
        instrumentIds: instrumentIdsOfSpec(allocation),
        accounts: [authorizer],
        excludeDebugFields: body.excludeDebugFields,
      });
      return choiceContext;
    },

    /** POST /registry/allocations/v{version}/{id}/choice-contexts/{execute-transfer|withdraw|cancel} */
    async getAllocationContext({ version, contractId, action, body, auth }) {
      const templates = version === 1 ? ['allocationV1'] : ['allocation', 'allocationV1'];
      const contract = await requireContract(contractId, templates, (p) => (p.core ?? p).allocation.admin);
      const core = allocationCore(contract);
      const authorizer = normalizeAccount(core.allocation.authorizer);
      const othersides = (core.allocation.transferLegSides ?? []).map((leg) => normalizeAccount(leg.otherside));
      const executors = core.settlement.executors ?? [];
      const allowed = {
        withdraw: [...core.withdrawers, ...accountParties(authorizer)],
        cancel: [...executors, ...accountParties(authorizer)],
        'execute-transfer': [...executors, ...accountParties(authorizer), ...othersides.flatMap(accountParties)],
      }[action];
      requireAnyParty(auth, allowed);
      const { choiceContext } = await contextBuilder.build({
        instrumentIds: instrumentIdsOfSpec(core.allocation),
        accounts: action === 'execute-transfer' ? [authorizer, ...othersides] : [authorizer],
        parties: isRegularAccount(authorizer) ? [] : core.authorizers,
        holdingCids: core.lockedHoldingCids ?? [],
        includeV1Factories: action === 'execute-transfer',
        excludeDebugFields: body.excludeDebugFields,
      });
      return choiceContext;
    },

    /** POST /registry/allocation/v2/settlement-factory */
    async getSettlementFactory({ body, auth }) {
      const args = body.choiceArguments;
      const executors = args.settlement.executors ?? [];
      requireAnyParty(auth, executors);
      const allocationRefs = args.allocations ?? [];
      if (allocationRefs.length > maxSettlementAllocations) {
        throw apiError('VALIDATION_FAILED', `A settlement may use at most ${maxSettlementAllocations} allocations`, {
          details: [{ field: 'choiceArguments.allocations', maximum: maxSettlementAllocations }],
        });
      }
      const instrumentIds = new Set();
      const accounts = [];
      const holdingCids = [];
      const parties = [];
      for (const leg of args.transferLegs ?? []) {
        instrumentIds.add(leg.instrumentId);
        accounts.push(normalizeAccount(leg.sender), normalizeAccount(leg.receiver));
      }
      for (const ref of allocationRefs) {
        const contract = await requireContract(ref.allocationCid, ['allocation', 'allocationV1'], (p) => (p.core ?? p).allocation.admin);
        const core = allocationCore(contract);
        if (!executors.every((party) => core.settlement.executors.includes(party))) {
          throw apiError('FORBIDDEN_PARTY', 'The allocation names different settlement executors', { details: [{ contractId: ref.allocationCid }] });
        }
        instrumentIdsOfSpec(core.allocation).forEach((id) => instrumentIds.add(id));
        (ref.extraTransferLegSides ?? []).forEach((leg) => instrumentIds.add(leg.instrumentId));
        Object.keys(ref.nextIterationFunding ?? {}).forEach((id) => instrumentIds.add(id));
        const authorizer = normalizeAccount(core.allocation.authorizer);
        accounts.push(authorizer);
        if (!isRegularAccount(authorizer)) parties.push(...core.authorizers);
        holdingCids.push(...(core.lockedHoldingCids ?? []));
      }
      const { choiceContext, facts } = await contextBuilder.build({
        instrumentIds: [...instrumentIds],
        accounts,
        parties: unique(parties),
        holdingCids,
        factories: ['settlementFactory'],
        excludeDebugFields: body.excludeDebugFields,
      });
      return { factoryId: facts.factories.get('settlementFactory').contractId, choiceContext };
    },
  };
}
