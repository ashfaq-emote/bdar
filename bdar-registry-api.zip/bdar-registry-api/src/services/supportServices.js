/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Audit trail and idempotency.
 */

import { apiError } from '../lib/errors.js';
import { canonicalJson, noopLogger, sha256Hex } from '../lib/util.js';

/** Keys whose values are always removed from audit details. */
const SENSITIVE_KEYS = /^(api[-_]?key|secret|password|token|authorization|pepper|partySignatures|signature|preparedTransaction)$/i;

function scrub(value, depth = 0) {
  if (depth > 6 || value === null || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.slice(0, 50).map((item) => scrub(item, depth + 1));
  return Object.fromEntries(
    Object.entries(value).map(([key, child]) => [key, SENSITIVE_KEYS.test(key) ? '[redacted]' : scrub(child, depth + 1)]),
  );
}

/**
 * Audit service. Writing an audit event must never break the request, so failures
 * are logged at error level and swallowed. Alert on those log lines.
 */
export function createAuditService({ repository, logger = noopLogger }) {
  return {
    async record(event) {
      try {
        await repository.insert({ ...event, details: scrub(event.details ?? {}) });
      } catch (error) {
        logger.error({ err: error, action: event.action }, 'failed to write audit event');
      }
    },
    list(filter) {
      return repository.list(filter);
    },
  };
}

/**
 * Idempotency for state changing requests.
 *
 * The client sends `Idempotency-Key: <unique value>`. The first request with that key
 * runs and its response is stored. A retry with the same key and the same body gets
 * the stored response without running again. The same key with a different body is
 * refused with 409, and so is a retry while the first request is still running.
 */
export function createIdempotencyService({ repository, ttlHours = 24, now = () => new Date() }) {
  return {
    /**
     * @param {{ apiKeyId: string, idempotencyKey: string, request: unknown }} scope
     * @param {() => Promise<{ status: number, body: unknown }>} work
     * @returns {Promise<{ status: number, body: unknown, replayed: boolean }>}
     */
    async run({ apiKeyId, idempotencyKey, request }, work) {
      const requestHash = sha256Hex(canonicalJson(request));
      const expiresAt = new Date(now().getTime() + ttlHours * 3600000);
      const { created, record } = await repository.begin({ apiKeyId, idempotencyKey, requestHash, expiresAt });
      if (!created) {
        if (record.requestHash !== requestHash) throw apiError('IDEMPOTENCY_KEY_REUSED');
        if (record.state !== 'completed') throw apiError('IDEMPOTENCY_IN_PROGRESS');
        return { status: record.responseStatus, body: record.responseBody, replayed: true };
      }
      try {
        const result = await work();
        await repository.complete({ apiKeyId, idempotencyKey, responseStatus: result.status, responseBody: result.body });
        return { ...result, replayed: false };
      } catch (error) {
        // A failed request can be retried with the same key. Ledger level duplicates are
        // still prevented because the ledger command id is derived from the key.
        await repository.abandon({ apiKeyId, idempotencyKey });
        throw error;
      }
    },
  };
}
