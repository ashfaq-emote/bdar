/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Prepare and execute transactions for externally signed parties.
 *
 *   POST /registry/bdar/v1/submissions/prepare   build a transaction; the client signs its hash
 *   POST /registry/bdar/v1/submissions/execute   submit the signed transaction and wait
 *
 * Why this exists: many wallets and custodians hold party keys outside the
 * participant node (external parties). They cannot submit through a ledger user.
 * The interactive submission service lets them sign a hash instead.
 *
 * Why it is locked down (OWASP API5 and API6): this endpoint relays commands to the
 * ledger, so it only accepts the registry interactions on the list below, only for
 * parties the API key may act for, and never for the registry admin party.
 */

import { randomUUID } from 'node:crypto';
import { apiError } from '../lib/errors.js';
import { sha256Hex } from '../lib/util.js';
import { toApiError } from '../ledger/ledgerClient.js';
import { requireAllParties } from '../security/scopes.js';
import { qualifiedName } from '../registry/daml.js';

/** Exercise commands the API will prepare, by "Module:Entity" and choice. */
export const ALLOWED_EXERCISES = Object.freeze({
  'Splice.Api.Token.TransferInstructionV1:TransferFactory': ['TransferFactory_Transfer'],
  'Splice.Api.Token.TransferInstructionV2:TransferFactory': ['TransferFactory_Transfer'],
  'Splice.Api.Token.TransferInstructionV1:TransferInstruction': ['TransferInstruction_Accept', 'TransferInstruction_Reject', 'TransferInstruction_Withdraw'],
  'Splice.Api.Token.TransferInstructionV2:TransferInstruction': ['TransferInstruction_Accept', 'TransferInstruction_Reject', 'TransferInstruction_Withdraw'],
  'Splice.Api.Token.AllocationInstructionV1:AllocationFactory': ['AllocationFactory_Allocate'],
  'Splice.Api.Token.AllocationInstructionV2:AllocationFactory': ['AllocationFactory_Allocate'],
  'Splice.Api.Token.AllocationInstructionV2:AllocationInstruction': ['AllocationInstruction_Accept', 'AllocationInstruction_Withdraw'],
  'Splice.Api.Token.AllocationV1:Allocation': ['Allocation_ExecuteTransfer', 'Allocation_Withdraw', 'Allocation_Cancel'],
  'Splice.Api.Token.AllocationV2:Allocation': ['Allocation_Withdraw', 'Allocation_Cancel'],
  'Splice.Api.Token.AllocationV2:SettlementFactory': ['SettlementFactory_SettleBatch'],
  'Broadridge.DigitalAssetRegistry.Issuance:BdarIssuanceFactory': ['BdarIssuanceFactory_RequestMint'],
  'Broadridge.DigitalAssetRegistry.Issuance:BdarMintRequest': ['BdarMintRequest_Withdraw'],
  'Broadridge.DigitalAssetRegistry.Account:BdarAccountRequest': ['BdarAccountRequest_Approve', 'BdarAccountRequest_Withdraw'],
  'Broadridge.DigitalAssetRegistry.Account:BdarTransferPreapproval': ['BdarTransferPreapproval_Cancel'],
  'Broadridge.DigitalAssetRegistry.Account:BdarClawbackRecord': ['BdarClawbackRecord_Acknowledge'],
});

/** Create commands the API will prepare. */
export const ALLOWED_CREATES = Object.freeze(['Broadridge.DigitalAssetRegistry.Account:BdarAccountRequest']);

export const MAX_COMMANDS = 20;

/** Package names a `#package-name:` reference may use. */
function allowedPackageName(templateId, bdarPackageName) {
  if (!templateId.startsWith('#')) return true; // package id reference; the ledger checks the package
  const packageName = templateId.slice(1).split(':')[0];
  return packageName === bdarPackageName || /^splice-api-token-[a-z0-9-]+$/.test(packageName);
}

/**
 * @param {{ ledger: object, reader: object, adminParty: string, packageName: string, logger?: object }} deps
 */
export function createSubmissionService({ ledger, reader, adminParty, packageName }) {
  /** Check one command against the allow list. Returns the command unchanged. */
  async function checkCommand(command, index, actAs) {
    const field = `commands[${index}]`;
    if (command.ExerciseCommand) {
      const { templateId, contractId, choice } = command.ExerciseCommand;
      const allowedChoices = ALLOWED_EXERCISES[qualifiedName(templateId)];
      if (!allowedChoices || !allowedChoices.includes(choice) || !allowedPackageName(templateId, packageName)) {
        throw apiError('TEMPLATE_NOT_ALLOWED', undefined, { details: [{ field, templateId, choice }] });
      }
      // The target must be a contract of this registry (visible to the admin party).
      if (!(await reader.contract(contractId))) {
        throw apiError('CONTRACT_NOT_FOUND', undefined, { details: [{ field, contractId }] });
      }
      return;
    }
    if (command.CreateCommand) {
      const { templateId, createArguments } = command.CreateCommand;
      if (!ALLOWED_CREATES.includes(qualifiedName(templateId)) || !allowedPackageName(templateId, packageName)) {
        throw apiError('TEMPLATE_NOT_ALLOWED', undefined, { details: [{ field, templateId }] });
      }
      if (createArguments?.admin !== adminParty) {
        throw apiError('WRONG_ADMIN', undefined, { details: [{ field: `${field}.CreateCommand.createArguments.admin` }] });
      }
      const approvals = createArguments.approvals ?? [];
      if (!approvals.every((party) => actAs.includes(party))) {
        throw apiError('FORBIDDEN_PARTY', 'Every approval of a new account request must be in actAs', { details: [{ field }] });
      }
      return;
    }
    throw apiError('TEMPLATE_NOT_ALLOWED', 'Only ExerciseCommand and CreateCommand are supported', { details: [{ field }] });
  }

  function requireNotAdmin(parties) {
    if (parties.includes(adminParty)) {
      throw apiError('FORBIDDEN_PARTY', 'The registry admin party cannot be used through this endpoint');
    }
  }

  return {
    async prepare({ body, auth }) {
      const actAs = body.actAs;
      const readAs = body.readAs ?? [];
      requireNotAdmin([...actAs, ...readAs]);
      requireAllParties(auth, actAs);
      if (readAs.length > 0) requireAllParties(auth, readAs);
      if (body.commands.length === 0 || body.commands.length > MAX_COMMANDS) {
        throw apiError('VALIDATION_FAILED', `Between 1 and ${MAX_COMMANDS} commands are allowed`);
      }
      for (const [index, command] of body.commands.entries()) await checkCommand(command, index, actAs);

      const commandId = body.commandId ?? `bdar-api-${randomUUID()}`;
      try {
        const prepared = await ledger.prepare({
          actAs, readAs, commandId, commands: body.commands,
          disclosedContracts: body.disclosedContracts ?? [], synchronizerId: body.synchronizerId,
        });
        return {
          commandId,
          preparedTransaction: prepared.preparedTransaction,
          preparedTransactionHash: prepared.preparedTransactionHash,
          hashingSchemeVersion: prepared.hashingSchemeVersion,
        };
      } catch (error) {
        throw toApiError(error);
      }
    },

    async execute({ body, auth, idempotencyKey }) {
      const signers = body.partySignatures.signatures.map((entry) => entry.party);
      requireNotAdmin(signers);
      requireAllParties(auth, signers);
      // The ledger de-duplicates on submissionId; derive it from the idempotency key so
      // a client retry can never execute the same prepared transaction twice.
      const submissionId = `bdar-api-${sha256Hex(`${auth.keyId}:${idempotencyKey}`).slice(0, 48)}`;
      try {
        const result = await ledger.executeAndWait({
          preparedTransaction: body.preparedTransaction,
          partySignatures: body.partySignatures,
          submissionId,
          hashingSchemeVersion: body.hashingSchemeVersion,
        });
        return { submissionId, updateId: result.updateId, completionOffset: result.completionOffset };
      } catch (error) {
        throw toApiError(error);
      } finally {
        reader.invalidate();
      }
    },
  };
}
