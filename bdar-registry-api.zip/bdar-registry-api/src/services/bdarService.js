/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Broadridge extension endpoints for wallets, issuers and settlement apps:
 *
 *   POST /registry/bdar/v1/issuance-factory                  context for BdarIssuanceFactory_RequestMint
 *   GET  /registry/bdar/v1/instruments[/{instrumentId}]      full instrument policies and supply
 *   GET  /registry/bdar/v1/parties/{party}/...               holdings, balances, instructions, allocations, accounts ...
 *   GET  /registry/bdar/v1/accounts?owner&provider&id        one account
 *   POST /registry/bdar/v1/account-requests/validate         check an account request before creating it
 *
 * Party scoped reads (OWASP API1, broken object level authorization): the party in
 * the path must be one of the API key's allowed parties, and every item returned is
 * filtered to contracts where that party has a role.
 */

import { apiError } from '../lib/errors.js';
import { decodeCursor, encodeCursor } from '../lib/util.js';
import { canActFor, requireAnyParty } from '../security/scopes.js';
import {
  accountKey, accountParties, isRegularAccount, normalizeAccount,
} from '../registry/daml.js';
import {
  accountChangeToDaml, accountRequestToApi, accountRulesProblems, accountToApi, allocationCore, allocationInstructionToApi,
  allocationToApi, balancesOf, clawbackRecordToApi, holdingToApi, instrumentToApi, isLocked, mintRequestToApi,
  preapprovalToApi, transferInstructionToApi,
} from '../registry/mappers.js';

export const PAGE_SIZE_DEFAULT = 100;
export const PAGE_SIZE_MAX = 500;

/** Cursor pagination over a list sorted by contract id. */
export function paginate(items, { pageSize, pageToken }) {
  const size = Math.min(Math.max(Number(pageSize) || PAGE_SIZE_DEFAULT, 1), PAGE_SIZE_MAX);
  let after;
  if (pageToken !== undefined) {
    after = decodeCursor(pageToken)?.after;
    if (typeof after !== 'string') {
      throw apiError('VALIDATION_FAILED', undefined, { details: [{ field: 'pageToken', message: 'is not a valid page token' }] });
    }
  }
  const sorted = [...items].sort((a, b) => a.contractId.localeCompare(b.contractId));
  const remaining = after === undefined ? sorted : sorted.filter((item) => item.contractId > after);
  const page = remaining.slice(0, size);
  return {
    items: page,
    ...(remaining.length > size ? { nextPageToken: encodeCursor({ after: page.at(-1).contractId }) } : {}),
  };
}

const hasParty = (account, party) => accountParties(normalizeAccount(account)).includes(party);

/**
 * Filters and mappers of the party scoped collections.
 * `filter(contract, party, query)` decides if the party may see an item.
 */
const PARTY_COLLECTIONS = {
  holdings: {
    template: 'holding',
    filter: (c, party, q, now) => hasParty(c.payload.account, party)
      && (!q.instrumentId || c.payload.instrumentId === q.instrumentId)
      && (q.locked === undefined || isLocked(c, now) === (q.locked === 'true')),
    map: holdingToApi,
  },
  'transfer-instructions': {
    template: 'transferInstruction',
    filter: (c, party, q) => {
      const t = c.payload.transfer;
      const roles = {
        sender: hasParty(t.sender, party),
        receiver: hasParty(t.receiver, party),
        issuer: (c.payload.issuers ?? []).includes(party),
      };
      const matchesRole = q.role ? roles[q.role] : roles.sender || roles.receiver || roles.issuer;
      return matchesRole && (!q.instrumentId || t.instrumentId.id === q.instrumentId);
    },
    map: transferInstructionToApi,
  },
  'allocation-instructions': {
    template: 'allocationInstruction',
    filter: (c, party) => hasParty(c.payload.allocation.authorizer, party),
    map: allocationInstructionToApi,
  },
  allocations: {
    templates: ['allocation', 'allocationV1'],
    filter: (c, party, q) => {
      const core = allocationCore(c);
      const roles = {
        authorizer: hasParty(core.allocation.authorizer, party) || core.authorizers.includes(party),
        executor: core.settlement.executors.includes(party),
      };
      return q.role ? roles[q.role] : roles.authorizer || roles.executor;
    },
    map: allocationToApi,
  },
  accounts: { template: 'account', filter: (c, party) => hasParty(c.payload.account, party), map: accountToApi },
  'account-requests': { template: 'accountRequest', filter: (c, party) => hasParty(c.payload.account, party), map: accountRequestToApi },
  preapprovals: { template: 'preapproval', filter: (c, party) => hasParty(c.payload.account, party), map: preapprovalToApi },
  'clawback-records': { template: 'clawbackRecord', filter: (c, party) => hasParty(c.payload.account, party), map: clawbackRecordToApi },
  'mint-requests': { template: 'mintRequest', filter: (c, party) => c.payload.issuer === party, map: mintRequestToApi },
};

export const PARTY_COLLECTION_NAMES = Object.freeze(Object.keys(PARTY_COLLECTIONS));

/**
 * @param {{ reader: object, contextBuilder: object, identifiers: object, adminParty: string, now?: () => Date }} deps
 */
export function createBdarService({ reader, contextBuilder, identifiers, adminParty, now = () => new Date() }) {
  async function contractsOf(collection) {
    const names = collection.templates ?? [collection.template];
    const lists = await Promise.all(names.map((name) => reader.template(name)));
    return lists.flat();
  }

  async function requireInstrument(instrumentId) {
    const instrument = await reader.instrument(instrumentId);
    if (!instrument) throw apiError('INSTRUMENT_NOT_FOUND', undefined, { details: [{ instrumentId }] });
    return instrument;
  }

  return {
    // ---------------------------------------------------------------- issuance

    /** POST /registry/bdar/v1/issuance-factory */
    async getIssuanceFactory({ body, auth }) {
      const { issuer, details } = body.choiceArguments;
      requireAnyParty(auth, [issuer]);
      const instrument = await requireInstrument(details.instrumentId);
      if (!instrument.payload.issuers.includes(issuer)) {
        throw apiError('NOT_ISSUER', undefined, { details: [{ issuer, instrumentId: details.instrumentId }] });
      }
      const receiver = normalizeAccount(details.receiver);
      if (!isRegularAccount(receiver)) {
        throw apiError('VALIDATION_FAILED', 'The receiver must be a regular account', { details: [{ field: 'choiceArguments.details.receiver' }] });
      }
      const { choiceContext, facts } = await contextBuilder.build({
        instrumentIds: [details.instrumentId],
        accounts: [receiver],
        parties: [issuer],
        factories: ['issuanceFactory'],
        excludeDebugFields: body.excludeDebugFields,
      });
      let mintOutcome = 'OFFER';
      if (instrument.payload.supplyPolicy.mintApprovalRequired) mintOutcome = 'AWAITING_APPROVAL';
      else if (facts.preapprovals.has(accountKey(receiver))) mintOutcome = 'DIRECT';
      return {
        factoryId: facts.factories.get('issuanceFactory').contractId,
        factoryTemplateId: identifiers.templates.issuanceFactory,
        mintOutcome,
        choiceContext,
      };
    },

    // ------------------------------------------------------------- instruments

    async listInstruments({ pageSize, pageToken }) {
      const instruments = await reader.instruments();
      const page = paginate(instruments, { pageSize, pageToken });
      const items = await Promise.all(page.items.map(async (c) => instrumentToApi(c, await reader.supply(c.payload.instrumentId))));
      return { items, ...(page.nextPageToken ? { nextPageToken: page.nextPageToken } : {}) };
    },

    async getInstrument(instrumentId) {
      const contract = await requireInstrument(instrumentId);
      return instrumentToApi(contract, await reader.supply(instrumentId));
    },

    // ---------------------------------------------------------- party queries

    /** GET /registry/bdar/v1/parties/{party}/{collection} */
    async listForParty({ party, collection, query, auth }) {
      if (!canActFor(auth, party)) throw apiError('FORBIDDEN_PARTY');
      const definition = PARTY_COLLECTIONS[collection];
      if (!definition) throw apiError('ROUTE_NOT_FOUND');
      const at = now();
      const visible = (await contractsOf(definition)).filter((contract) => definition.filter(contract, party, query, at));
      const page = paginate(visible, query);
      return { items: page.items.map(definition.map), ...(page.nextPageToken ? { nextPageToken: page.nextPageToken } : {}) };
    },

    /** GET /registry/bdar/v1/parties/{party}/balances */
    async balancesForParty({ party, query, auth }) {
      if (!canActFor(auth, party)) throw apiError('FORBIDDEN_PARTY');
      const holdings = (await reader.template('holding'))
        .filter((c) => hasParty(c.payload.account, party) && (!query.instrumentId || c.payload.instrumentId === query.instrumentId));
      return { asOf: now().toISOString(), items: balancesOf(holdings, now()) };
    },

    // ---------------------------------------------------------------- accounts

    /** GET /registry/bdar/v1/accounts?owner=&provider=&id= */
    async getAccount({ query, auth }) {
      const account = normalizeAccount({ owner: query.owner, provider: query.provider ?? null, id: query.id ?? '' });
      requireAnyParty(auth, accountParties(account));
      const key = accountKey(account);
      const contract = (await reader.template('account')).find((c) => c.payload.admin === adminParty && accountKey(c.payload.account) === key);
      if (!contract) {
        const implicit = (await reader.instruments())
          .filter((c) => c.payload.accountPolicy === 'BdarImplicitBasicAccounts')
          .map((c) => c.payload.instrumentId);
        const basic = !account.provider && account.id === '';
        throw apiError('ACCOUNT_NOT_FOUND', undefined, {
          details: [{ accountKey: key, implicitBasicAccountUsableFor: basic ? implicit : [] }],
        });
      }
      return accountToApi(contract);
    },

    /**
     * POST /registry/bdar/v1/account-requests/validate
     * Checks a proposed BdarAccountRequest the same way the operator will when it
     * accepts it, and returns the create command to prepare and sign.
     */
    async validateAccountRequest({ body, auth }) {
      const account = normalizeAccount(body.account);
      const parties = accountParties(account);
      requireAnyParty(auth, parties);
      const change = body.change;
      const problems = [];
      const warnings = [];
      const problem = (code, message) => problems.push({ code, message });

      if (!isRegularAccount(account)) problem('INVALID_ACCOUNT', 'the account must have an owner');
      const approvals = body.approvals ?? parties.filter((party) => canActFor(auth, party)).slice(0, 1);
      if (approvals.length === 0) problem('NO_APPROVALS', 'at least one account party must approve the request');
      for (const party of approvals) {
        if (!parties.includes(party)) problem('APPROVER_NOT_ACCOUNT_PARTY', `${party} is not a party of the account`);
      }
      if (!body.reference || body.reference.trim() === '') problem('REFERENCE_REQUIRED', 'reference must not be empty');

      const key = accountKey(account);
      const [accounts, requests, preapprovals] = await Promise.all([
        reader.template('account'), reader.template('accountRequest'), reader.template('preapproval'),
      ]);
      const existing = accounts.find((c) => c.payload.admin === adminParty && accountKey(c.payload.account) === key);
      const pendingSame = requests.filter((c) => accountKey(c.payload.account) === key && c.payload.change.tag === changeTag(change.type));

      switch (change.type) {
        case 'OPEN':
          if (existing) problem('ACCOUNT_ALREADY_EXISTS', 'an active account already exists for this owner, provider and id');
          accountRulesProblems(account, change.rules).forEach((message) => problem('ACCOUNT_RULES_INVALID', message));
          if (!change.termsReference) problem('TERMS_REFERENCE_REQUIRED', 'termsReference must not be empty');
          break;
        case 'CHANGE_RULES':
          if (!existing) problem('ACCOUNT_NOT_FOUND', 'there is no account to change');
          accountRulesProblems(account, change.newRules).forEach((message) => problem('ACCOUNT_RULES_INVALID', message));
          break;
        case 'SET_PREAPPROVAL': {
          for (const instrumentId of change.instrumentIds ?? []) {
            if (!(await reader.instrument(instrumentId))) problem('INSTRUMENT_NOT_FOUND', `instrument ${instrumentId} does not exist`);
          }
          if (change.expiresAt && new Date(change.expiresAt) <= now()) problem('EXPIRY_IN_PAST', 'expiresAt must be in the future');
          if (preapprovals.some((c) => accountKey(c.payload.account) === key)) {
            warnings.push({ code: 'PREAPPROVAL_EXISTS', message: 'the account already has a preapproval; cancel it first to avoid ambiguity' });
          }
          break;
        }
        case 'CLOSE':
          if (!existing) problem('ACCOUNT_NOT_FOUND', 'there is no account to close');
          break;
        default:
          problem('UNKNOWN_CHANGE', 'unknown change type');
      }
      if (pendingSame.length > 0) {
        warnings.push({ code: 'PENDING_REQUEST_EXISTS', message: 'a request with the same change is already pending', contractIds: pendingSame.map((c) => c.contractId) });
      }

      const valid = problems.length === 0;
      return {
        valid,
        problems,
        warnings,
        accountKey: key,
        existingAccountCid: existing?.contractId ?? null,
        missingApprovals: parties.filter((party) => !approvals.includes(party)),
        createCommand: valid
          ? {
            CreateCommand: {
              templateId: identifiers.templates.accountRequest,
              createArguments: {
                admin: adminParty, account, change: accountChangeToDaml(change), approvals, reference: body.reference,
              },
            },
          }
          : null,
        actAs: approvals,
      };
    },
  };
}

function changeTag(type) {
  return { OPEN: 'BdarOpenAccount', CHANGE_RULES: 'BdarChangeAccountRules', SET_PREAPPROVAL: 'BdarSetTransferPreapproval', CLOSE: 'BdarCloseAccount' }[type];
}
