/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * Operator commands: Broadridge operations staff (or their tooling) change registry
 * state as the registry admin party.
 *
 *   bootstrap                         create the registry config, event log and factories
 *   instruments                       create, update policies, update display, pause, resume, retire
 *   registry config                   switch credential checks on or off
 *   account requests                  accept or reject
 *   accounts                          freeze, unfreeze, claw back
 *   allowlist                         add or revoke entries
 *   mint requests                     approve or reject
 *   housekeeping                      expire transfer instructions, cancel expired allocations, expire preapprovals
 *
 * Every command:
 *   - runs through the idempotency service in the HTTP layer (Idempotency-Key header),
 *   - uses a ledger command id derived from the API key and the idempotency key, so the
 *     ledger itself rejects a duplicate even if the idempotency record was lost,
 *   - is written to the audit trail by the HTTP layer,
 *   - clears the contract reader cache afterwards.
 */

import { apiError } from '../lib/errors.js';
import { sha256Hex } from '../lib/util.js';
import { toApiError } from '../ledger/ledgerClient.js';
import {
  accountKey, emptyMetadata, isRegularAccount, normalizeAccount, qualifiedName, tagOf, variant,
} from '../registry/daml.js';
import {
  accountRequestToApi, accountToApi, allocationCore, allowlistEntryToApi, instrumentProblems, instrumentToApi, instrumentToDaml,
  isLocked, mintRequestToApi, policiesToDaml, registryConfigToApi,
} from '../registry/mappers.js';

/** Ledger command id for an operator command. Same inputs always give the same id. */
export function operatorCommandId(keyId, idempotencyKey, operation, suffix = '') {
  return `bdar-api-${sha256Hex(`${keyId}:${idempotencyKey}:${operation}:${suffix}`).slice(0, 48)}`;
}

/** A short, stable summary of a ledger transaction. */
export function summarizeTransaction(transaction) {
  const events = transaction?.events ?? [];
  const created = [];
  const archived = [];
  let exerciseResult;
  for (const event of events) {
    if (event.CreatedEvent) created.push({ contractId: event.CreatedEvent.contractId, template: qualifiedName(event.CreatedEvent.templateId) });
    if (event.ArchivedEvent) archived.push({ contractId: event.ArchivedEvent.contractId, template: qualifiedName(event.ArchivedEvent.templateId) });
    if (event.ExercisedEvent) {
      if (event.ExercisedEvent.consuming) archived.push({ contractId: event.ExercisedEvent.contractId, template: qualifiedName(event.ExercisedEvent.templateId) });
      if (exerciseResult === undefined) exerciseResult = event.ExercisedEvent.exerciseResult;
    }
  }
  return {
    updateId: transaction?.updateId,
    offset: transaction?.offset,
    created,
    archived,
    ...(exerciseResult !== undefined ? { exerciseResult } : {}),
  };
}

const extraArgs = (choiceContext) => ({ context: choiceContext.choiceContextData, meta: emptyMetadata() });

/**
 * @param {{ ledger: object, reader: object, contextBuilder: object, identifiers: object, config: object, now?: () => Date, logger?: object }} deps
 */
export function createOperatorService({ ledger, reader, contextBuilder, identifiers, config, now = () => new Date() }) {
  const admin = config.registry.adminParty;
  const T = identifiers.templates;

  async function submit({ auth, idempotencyKey, operation, suffix, commands, disclosedContracts = [] }) {
    const commandId = operatorCommandId(auth.keyId, idempotencyKey, operation, suffix);
    try {
      const transaction = await ledger.submitAndWaitForTransaction({ actAs: [admin], commandId, commands, disclosedContracts });
      return { commandId, ...summarizeTransaction(transaction) };
    } catch (error) {
      throw toApiError(error);
    } finally {
      reader.invalidate();
    }
  }

  const exercise = (templateId, contractId, choice, choiceArgument = {}) => ({ ExerciseCommand: { templateId, contractId, choice, choiceArgument } });
  const create = (templateId, createArguments) => ({ CreateCommand: { templateId, createArguments } });

  async function requireInstrument(instrumentId) {
    const contract = await reader.instrument(instrumentId);
    if (!contract) throw apiError('INSTRUMENT_NOT_FOUND', undefined, { details: [{ instrumentId }] });
    return contract;
  }

  async function requireOf(templateName, contractId, adminOf = (p) => p.admin) {
    const contract = await reader.contract(contractId);
    if (!contract || qualifiedName(contract.templateId) !== qualifiedName(T[templateName]) || adminOf(contract.payload) !== admin) {
      throw apiError('CONTRACT_NOT_FOUND', undefined, { details: [{ contractId }] });
    }
    return contract;
  }

  async function requireAccount(account) {
    const key = accountKey(normalizeAccount(account));
    const contract = (await reader.template('account')).find((c) => c.payload.admin === admin && accountKey(c.payload.account) === key);
    if (!contract) throw apiError('ACCOUNT_NOT_FOUND', undefined, { details: [{ accountKey: key }] });
    return contract;
  }

  async function instrumentResult(instrumentId, transaction) {
    const contract = await reader.instrument(instrumentId);
    return { status: 200, body: { instrument: contract ? instrumentToApi(contract, await reader.supply(instrumentId)) : null, transaction } };
  }

  /** Run a housekeeping choice on many contracts, one transaction each, and report per contract. */
  async function sweep({ auth, idempotencyKey, operation, contracts, limit, buildCommand }) {
    const selected = contracts.slice(0, limit);
    const succeeded = [];
    const failed = [];
    for (const contract of selected) {
      try {
        const { command, disclosedContracts } = await buildCommand(contract);
        const result = await submit({ auth, idempotencyKey, operation, suffix: contract.contractId, commands: [command], disclosedContracts });
        succeeded.push({ contractId: contract.contractId, updateId: result.updateId });
      } catch (error) {
        failed.push({ contractId: contract.contractId, code: error.code ?? 'INTERNAL_ERROR', error: error.message });
      }
    }
    return { candidates: contracts.length, processed: selected.length, succeeded, failed, remaining: Math.max(contracts.length - selected.length, 0) };
  }

  return {
    // ----------------------------------------------------------------- bootstrap

    async bootstrap({ body, auth, idempotencyKey }) {
      const singletons = ['registryConfig', 'eventLog', 'transferFactory', 'allocationFactory', 'settlementFactory', 'issuanceFactory'];
      const existing = {};
      for (const name of singletons) {
        existing[name] = (await reader.template(name)).find((c) => c.payload.admin === admin);
      }
      const missing = singletons.filter((name) => !existing[name]);
      if (missing.length === 0) return { status: 200, body: { alreadyBootstrapped: true, created: [] } };
      const commands = missing.map((name) => (name === 'registryConfig'
        ? create(T.registryConfig, {
          admin,
          registryName: body.registryName ?? config.registry.registryName,
          credentialChecksEnabled: body.credentialChecksEnabled ?? true,
          meta: emptyMetadata(),
        })
        : create(T[name], { admin })));
      const result = await submit({ auth, idempotencyKey, operation: 'bootstrap', commands });
      return { status: 201, body: { alreadyBootstrapped: false, missingBefore: missing, ...result } };
    },

    async getRegistryConfig() {
      return registryConfigToApi(await reader.singleton('registryConfig'));
    },

    async setCredentialChecks({ body, auth, idempotencyKey }) {
      const configContract = await reader.singleton('registryConfig');
      const result = await submit({
        auth, idempotencyKey, operation: 'registry-config.credential-checks',
        commands: [exercise(T.registryConfig, configContract.contractId, 'BdarRegistryConfig_SetCredentialChecks', { enabled: body.enabled })],
      });
      return { status: 200, body: { registryConfig: registryConfigToApi(await reader.singleton('registryConfig')), transaction: result } };
    },

    // --------------------------------------------------------------- instruments

    async createInstrument({ body, auth, idempotencyKey }) {
      const problems = instrumentProblems(body);
      if (problems.length > 0) throw apiError('VALIDATION_FAILED', undefined, { details: problems });
      if (await reader.instrument(body.instrumentId)) {
        throw apiError('INSTRUMENT_ALREADY_EXISTS', undefined, { details: [{ instrumentId: body.instrumentId }] });
      }
      const configContract = await reader.singleton('registryConfig');
      const result = await submit({
        auth, idempotencyKey, operation: 'instrument.create',
        commands: [exercise(T.registryConfig, configContract.contractId, 'BdarRegistryConfig_CreateInstrument', { instrument: instrumentToDaml(body, admin) })],
      });
      const created = await reader.instrument(body.instrumentId);
      return { status: 201, body: { instrument: created ? instrumentToApi(created, await reader.supply(body.instrumentId)) : null, transaction: result } };
    },

    async updateInstrumentPolicies({ instrumentId, body, auth, idempotencyKey }) {
      const problems = instrumentProblems(body);
      if (problems.length > 0) throw apiError('VALIDATION_FAILED', undefined, { details: problems });
      const contract = await requireInstrument(instrumentId);
      const p = policiesToDaml(body);
      const result = await submit({
        auth, idempotencyKey, operation: `instrument.policies:${instrumentId}`,
        commands: [exercise(T.instrument, contract.contractId, 'BdarInstrument_UpdatePolicies', {
          newIssuers: body.issuers,
          newAccountPolicy: p.accountPolicy,
          newEligibilityPolicy: p.eligibilityPolicy,
          newSupplyPolicy: p.supplyPolicy,
          newRedemptionPolicy: p.redemptionPolicy,
          newSettlementPolicy: p.settlementPolicy,
          newControlPolicy: p.controlPolicy,
        })],
      });
      return instrumentResult(instrumentId, result);
    },

    async updateInstrumentDisplay({ instrumentId, body, auth, idempotencyKey }) {
      const contract = await requireInstrument(instrumentId);
      const current = contract.payload;
      const result = await submit({
        auth, idempotencyKey, operation: `instrument.display:${instrumentId}`,
        commands: [exercise(T.instrument, contract.contractId, 'BdarInstrument_UpdateDisplay', {
          newName: body.name ?? current.name,
          newSymbol: body.symbol ?? current.symbol,
          newMeta: body.meta ? { values: body.meta } : current.meta,
        })],
      });
      return instrumentResult(instrumentId, result);
    },

    async pauseInstrument({ instrumentId, body, auth, idempotencyKey }) {
      const contract = await requireInstrument(instrumentId);
      if (tagOf(contract.payload.status) === 'BdarInstrumentRetired') throw apiError('CONFLICT', 'The instrument is retired');
      const result = await submit({
        auth, idempotencyKey, operation: `instrument.pause:${instrumentId}`,
        commands: [exercise(T.instrument, contract.contractId, 'BdarInstrument_Pause', {
          pauseInfo: { reason: body.reason, pausedUntil: body.pausedUntil ?? null },
        })],
      });
      return instrumentResult(instrumentId, result);
    },

    async resumeInstrument({ instrumentId, auth, idempotencyKey }) {
      const contract = await requireInstrument(instrumentId);
      if (!contract.payload.pause) throw apiError('CONFLICT', 'The instrument is not paused');
      const result = await submit({
        auth, idempotencyKey, operation: `instrument.resume:${instrumentId}`,
        commands: [exercise(T.instrument, contract.contractId, 'BdarInstrument_Resume', {})],
      });
      return instrumentResult(instrumentId, result);
    },

    async retireInstrument({ instrumentId, auth, idempotencyKey }) {
      const contract = await requireInstrument(instrumentId);
      if (tagOf(contract.payload.status) === 'BdarInstrumentRetired') throw apiError('CONFLICT', 'The instrument is already retired');
      const result = await submit({
        auth, idempotencyKey, operation: `instrument.retire:${instrumentId}`,
        commands: [exercise(T.instrument, contract.contractId, 'BdarInstrument_Retire', {})],
      });
      return instrumentResult(instrumentId, result);
    },

    // ---------------------------------------------------------- account requests

    async listAccountRequests({ query }) {
      const items = (await reader.template('accountRequest'))
        .filter((c) => c.payload.admin === admin)
        .filter((c) => !query.party || [c.payload.account.owner, c.payload.account.provider].includes(query.party))
        .map(accountRequestToApi);
      return { items };
    },

    async acceptAccountRequest({ contractId, auth, idempotencyKey }) {
      const contract = await requireOf('accountRequest', contractId);
      const request = contract.payload;
      const account = normalizeAccount(request.account);
      const parties = [account.owner, account.provider].filter(Boolean);
      if (!parties.every((party) => request.approvals.includes(party))) {
        throw apiError('ACCOUNT_REQUEST_INCOMPLETE', undefined, { details: [{ missingApprovals: parties.filter((p) => !request.approvals.includes(p)) }] });
      }
      const key = accountKey(account);
      const existing = (await reader.template('account')).find((c) => c.payload.admin === admin && accountKey(c.payload.account) === key);
      const changeType = tagOf(request.change);
      if (changeType === 'BdarOpenAccount' && existing) {
        throw apiError('ACCOUNT_ALREADY_EXISTS', undefined, { details: [{ accountKey: key, contractId: existing.contractId }] });
      }
      if (['BdarChangeAccountRules', 'BdarCloseAccount'].includes(changeType) && !existing) {
        throw apiError('ACCOUNT_NOT_FOUND', undefined, { details: [{ accountKey: key }] });
      }
      const result = await submit({
        auth, idempotencyKey, operation: `account-request.accept:${contractId}`,
        commands: [exercise(T.accountRequest, contractId, 'BdarAccountRequest_Accept', {
          existingAccountCid: ['BdarChangeAccountRules', 'BdarCloseAccount'].includes(changeType) ? existing.contractId : null,
        })],
      });
      return { status: 200, body: { accountKey: key, transaction: result } };
    },

    async rejectAccountRequest({ contractId, body, auth, idempotencyKey }) {
      await requireOf('accountRequest', contractId);
      const result = await submit({
        auth, idempotencyKey, operation: `account-request.reject:${contractId}`,
        commands: [exercise(T.accountRequest, contractId, 'BdarAccountRequest_Reject', { reason: body.reason })],
      });
      return { status: 200, body: { transaction: result } };
    },

    // ------------------------------------------------------------------ accounts

    async listAccounts({ query }) {
      const items = (await reader.template('account'))
        .filter((c) => c.payload.admin === admin)
        .filter((c) => !query.party || [c.payload.account.owner, c.payload.account.provider].includes(query.party))
        .filter((c) => !query.status || (query.status === 'FROZEN') === (tagOf(c.payload.status) === 'BdarAccountFrozen'))
        .map(accountToApi);
      return { items };
    },

    async freezeAccount({ body, auth, idempotencyKey }) {
      const contract = await requireAccount(body.account);
      const result = await submit({
        auth, idempotencyKey, operation: `account.freeze:${accountKey(body.account)}`,
        commands: [exercise(T.account, contract.contractId, 'BdarAccount_Freeze', { reason: body.reason })],
      });
      return { status: 200, body: { account: accountToApi(await requireAccount(body.account)), transaction: result } };
    },

    async unfreezeAccount({ body, auth, idempotencyKey }) {
      const contract = await requireAccount(body.account);
      if (tagOf(contract.payload.status) !== 'BdarAccountFrozen') throw apiError('CONFLICT', 'The account is not frozen');
      const result = await submit({
        auth, idempotencyKey, operation: `account.unfreeze:${accountKey(body.account)}`,
        commands: [exercise(T.account, contract.contractId, 'BdarAccount_Unfreeze', {})],
      });
      return { status: 200, body: { account: accountToApi(await requireAccount(body.account)), transaction: result } };
    },

    /**
     * Claw back value from an account. Without holdingCids, every unlocked holding of
     * the instrument in the account is seized.
     */
    async clawback({ body, auth, idempotencyKey }) {
      const accountContract = await requireAccount(body.account);
      const instrument = await requireInstrument(body.instrumentId);
      if (!instrument.payload.controlPolicy.clawbackEnabled) {
        throw apiError('CONFLICT', 'Clawback is not enabled for this instrument');
      }
      const key = accountKey(body.account);
      const at = now();
      let holdingCids = body.holdingCids;
      if (!holdingCids || holdingCids.length === 0) {
        holdingCids = (await reader.template('holding'))
          .filter((c) => c.payload.admin === admin && accountKey(c.payload.account) === key)
          .filter((c) => c.payload.instrumentId === body.instrumentId && !isLocked(c, at))
          .map((c) => c.contractId);
      }
      if (holdingCids.length === 0) throw apiError('CONFLICT', 'The account has no unlocked holdings of this instrument');
      let outcome = variant('BdarBurnClawback', {});
      if (body.outcome === 'REASSIGN') {
        if (!body.recoveryAccount) {
          throw apiError('VALIDATION_FAILED', undefined, { details: [{ field: 'recoveryAccount', message: 'is required when outcome is REASSIGN' }] });
        }
        const recovery = await requireAccount(body.recoveryAccount);
        if (tagOf(recovery.payload.purpose) !== 'BdarRecoveryAccount') {
          throw apiError('VALIDATION_FAILED', 'The recovery account must have purpose RECOVERY', { details: [{ field: 'recoveryAccount' }] });
        }
        outcome = variant('BdarReassignClawback', { recoveryAccountCid: recovery.contractId });
      }
      const { choiceContext } = await contextBuilder.build({ instrumentIds: [body.instrumentId], excludeDebugFields: true });
      const result = await submit({
        auth, idempotencyKey, operation: `account.clawback:${key}`,
        commands: [exercise(T.account, accountContract.contractId, 'BdarAccount_Clawback', {
          instrumentId: body.instrumentId, holdingCids, outcome, reason: body.reason, extraArgs: extraArgs(choiceContext),
        })],
      });
      return { status: 200, body: { holdingCids, transaction: result } };
    },

    // ----------------------------------------------------------------- allowlist

    async listAllowlist({ query }) {
      const items = (await reader.template('allowlistEntry'))
        .filter((c) => c.payload.admin === admin)
        .filter((c) => !query.instrumentId || c.payload.instrumentId === query.instrumentId)
        .filter((c) => !query.party || c.payload.party === query.party)
        .map(allowlistEntryToApi);
      return { items };
    },

    async addAllowlistEntry({ body, auth, idempotencyKey }) {
      await requireInstrument(body.instrumentId);
      const exists = (await reader.template('allowlistEntry'))
        .some((c) => c.payload.admin === admin && c.payload.party === body.party && c.payload.instrumentId === body.instrumentId);
      if (exists) throw apiError('ALLOWLIST_ENTRY_EXISTS', undefined, { details: [{ party: body.party, instrumentId: body.instrumentId }] });
      const result = await submit({
        auth, idempotencyKey, operation: `allowlist.add:${body.party}|${body.instrumentId}`,
        commands: [create(T.allowlistEntry, {
          admin, party: body.party, instrumentId: body.instrumentId, validUntil: body.validUntil ?? null, reference: body.reference,
        })],
      });
      return { status: 201, body: { transaction: result } };
    },

    async revokeAllowlistEntry({ body, auth, idempotencyKey }) {
      const entries = (await reader.template('allowlistEntry'))
        .filter((c) => c.payload.admin === admin && c.payload.party === body.party && c.payload.instrumentId === body.instrumentId);
      if (entries.length === 0) throw apiError('NOT_FOUND', 'No allowlist entry exists for this party and instrument');
      const result = await submit({
        auth, idempotencyKey, operation: `allowlist.revoke:${body.party}|${body.instrumentId}`,
        commands: entries.map((entry) => exercise(T.allowlistEntry, entry.contractId, 'BdarAllowlistEntry_Revoke', { reason: body.reason })),
      });
      return { status: 200, body: { revoked: entries.length, transaction: result } };
    },

    // ------------------------------------------------------------- mint requests

    async listMintRequests({ query }) {
      const items = (await reader.template('mintRequest'))
        .filter((c) => c.payload.admin === admin)
        .filter((c) => !query.instrumentId || c.payload.details.instrumentId === query.instrumentId)
        .map(mintRequestToApi);
      return { items };
    },

    async approveMintRequest({ contractId, auth, idempotencyKey }) {
      const contract = await requireOf('mintRequest', contractId);
      const { issuer, details } = contract.payload;
      const { choiceContext } = await contextBuilder.build({
        instrumentIds: [details.instrumentId], accounts: [details.receiver], parties: [issuer], excludeDebugFields: true,
      });
      const result = await submit({
        auth, idempotencyKey, operation: `mint-request.approve:${contractId}`,
        commands: [exercise(T.mintRequest, contractId, 'BdarMintRequest_Approve', { extraArgs: extraArgs(choiceContext) })],
        disclosedContracts: choiceContext.disclosedContracts,
      });
      return { status: 200, body: { mintResult: result.exerciseResult ?? null, transaction: result } };
    },

    async rejectMintRequest({ contractId, body, auth, idempotencyKey }) {
      await requireOf('mintRequest', contractId);
      const result = await submit({
        auth, idempotencyKey, operation: `mint-request.reject:${contractId}`,
        commands: [exercise(T.mintRequest, contractId, 'BdarMintRequest_Reject', { reason: body.reason })],
      });
      return { status: 200, body: { transaction: result } };
    },

    // -------------------------------------------------------------- housekeeping

    async expireTransferInstructions({ body, auth, idempotencyKey }) {
      const at = now();
      const due = (await reader.template('transferInstruction'))
        .filter((c) => c.payload.admin === admin && new Date(c.payload.transfer.executeBefore) <= at);
      const report = await sweep({
        auth, idempotencyKey, operation: 'housekeeping.expire-transfer-instructions', contracts: due, limit: body.limit ?? 50,
        buildCommand: async (contract) => {
          const { choiceContext } = await contextBuilder.build({ instrumentIds: [contract.payload.transfer.instrumentId.id], excludeDebugFields: true });
          return { command: exercise(T.transferInstruction, contract.contractId, 'BdarTransferInstruction_Expire', { extraArgs: extraArgs(choiceContext) }) };
        },
      });
      return { status: 200, body: report };
    },

    async cancelExpiredAllocations({ body, auth, idempotencyKey }) {
      const at = now();
      const lists = await Promise.all([reader.template('allocation'), reader.template('allocationV1')]);
      const due = lists.flat().filter((c) => {
        const core = allocationCore(c);
        return core.allocation.admin === admin && new Date(core.expiresAt) <= at;
      });
      const report = await sweep({
        auth, idempotencyKey, operation: 'housekeeping.cancel-expired-allocations', contracts: due, limit: body.limit ?? 50,
        buildCommand: async (contract) => {
          const core = allocationCore(contract);
          const authorizer = normalizeAccount(core.allocation.authorizer);
          const { choiceContext } = await contextBuilder.build({
            instrumentIds: [...new Set(core.allocation.transferLegSides.map((leg) => leg.instrumentId))],
            accounts: isRegularAccount(authorizer) ? [authorizer] : [],
            excludeDebugFields: true,
          });
          return {
            command: exercise(identifiers.interfaces.allocationV2, contract.contractId, 'Allocation_Cancel', { actors: [admin], extraArgs: extraArgs(choiceContext) }),
          };
        },
      });
      return { status: 200, body: report };
    },

    async expirePreapprovals({ body, auth, idempotencyKey }) {
      const at = now();
      const due = (await reader.template('preapproval'))
        .filter((c) => c.payload.admin === admin && c.payload.expiresAt && new Date(c.payload.expiresAt) <= at);
      const report = await sweep({
        auth, idempotencyKey, operation: 'housekeeping.expire-preapprovals', contracts: due, limit: body.limit ?? 50,
        buildCommand: async (contract) => ({ command: exercise(T.preapproval, contract.contractId, 'BdarTransferPreapproval_Expire', {}) }),
      });
      return { status: 200, body: report };
    },
  };
}
