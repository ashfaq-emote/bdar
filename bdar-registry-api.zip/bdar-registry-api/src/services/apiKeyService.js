/*
 * Copyright (c) 2026 Broadridge Financial Solutions, Inc. All rights reserved.
 *
 * BROADRIDGE PROPRIETARY AND CONFIDENTIAL.
 * Broadridge Digital Asset Registry (BDAR) Registry API.
 * This file is part of proprietary Broadridge software. It may not be copied,
 * modified, distributed or used, in whole or in part, without the prior written
 * permission of Broadridge Financial Solutions, Inc.
 *
 * SPDX-License-Identifier: LicenseRef-Broadridge-Proprietary
 */

/**
 * API key lifecycle: create, verify, list, update, rotate, revoke.
 *
 * The plaintext key is returned exactly once, when it is created or rotated. After
 * that only the key id and metadata can be read back.
 */

import { apiError } from '../lib/errors.js';
import { TtlCache, newId, noopLogger } from '../lib/util.js';
import { formatApiKey, generateApiKey, generateSecret, hashSecret, parseApiKey, secretMatches } from '../security/apiKeyFormat.js';
import { validateKeyScopes } from '../security/scopes.js';

const LAST_USED_WRITE_INTERVAL_MS = 60000;

/**
 * @param {{ repository: object, config: object, audit?: object, logger?: object, now?: () => Date }} deps
 */
export function createApiKeyService({ repository, config, audit, logger = noopLogger, now = () => new Date() }) {
  const pepper = config.apiKeys.pepper;
  const environment = config.apiEnvironment;
  const cache = new TtlCache({ ttlMs: config.apiKeys.cacheTtlMs, maxEntries: 10000, now: () => now().getTime() });
  const lastUsedWrites = new Map();
  // A fixed dummy hash, compared when a key id is unknown, so timing does not reveal which key ids exist.
  const dummyHash = hashSecret(pepper, '0000000000000000', '0'.repeat(64));

  function toPublic(record) {
    return {
      keyId: record.keyId,
      clientName: record.clientName,
      description: record.description,
      environment: record.environment,
      scopes: [...record.scopes],
      allowedParties: [...record.allowedParties],
      rateLimitTier: record.rateLimitTier,
      status: record.status,
      createdAt: record.createdAt.toISOString(),
      createdBy: record.createdBy,
      updatedAt: record.updatedAt.toISOString(),
      expiresAt: record.expiresAt ? record.expiresAt.toISOString() : null,
      lastUsedAt: record.lastUsedAt ? record.lastUsedAt.toISOString() : null,
      previousSecretExpiresAt: record.previousSecretExpiresAt ? record.previousSecretExpiresAt.toISOString() : null,
      revokedAt: record.revokedAt ? record.revokedAt.toISOString() : null,
      revokeReason: record.revokeReason ?? null,
    };
  }

  function validateInput(input, { partial = false } = {}) {
    const problems = [];
    if (!partial || input.scopes !== undefined || input.allowedParties !== undefined) {
      problems.push(...validateKeyScopes(input.scopes, input.allowedParties));
    }
    if (input.rateLimitTier !== undefined && !Object.hasOwn(config.rateLimit.tiers, input.rateLimitTier)) {
      problems.push(`rateLimitTier must be one of ${Object.keys(config.rateLimit.tiers).join(', ')}`);
    }
    if (input.expiresAt !== undefined && input.expiresAt !== null && new Date(input.expiresAt) <= now()) {
      problems.push('expiresAt must be in the future');
    }
    if (problems.length > 0) {
      throw apiError('VALIDATION_FAILED', undefined, { details: problems.map((message) => ({ message })) });
    }
  }

  async function markUsed(record, ip) {
    const last = lastUsedWrites.get(record.keyId) ?? 0;
    if (now().getTime() - last < LAST_USED_WRITE_INTERVAL_MS) return;
    lastUsedWrites.set(record.keyId, now().getTime());
    try {
      await repository.markUsed(record.keyId, now(), ip);
    } catch (error) {
      logger.warn({ err: error, keyId: record.keyId }, 'could not record API key usage');
    }
  }

  return {
    /**
     * Check a presented key. Never throws for a bad key: returns { ok: false, reason }.
     * The reason is for logs and audit only; clients always get the same 401.
     */
    async verify(apiKey, { ip } = {}) {
      const parsed = parseApiKey(apiKey);
      if (!parsed) return { ok: false, reason: 'malformed' };
      if (parsed.environment !== environment) return { ok: false, reason: 'wrong-environment', keyId: parsed.keyId };

      const record = await cache.getOrLoad(parsed.keyId, async () => (await repository.findByKeyId(parsed.keyId)) ?? null);
      if (!record) {
        secretMatches(pepper, parsed.keyId, parsed.secret, dummyHash);
        return { ok: false, reason: 'unknown-key', keyId: parsed.keyId };
      }
      const current = now();
      const matchesCurrent = secretMatches(pepper, parsed.keyId, parsed.secret, record.secretHash);
      const matchesPrevious = !matchesCurrent
        && record.previousSecretHash
        && record.previousSecretExpiresAt > current
        && secretMatches(pepper, parsed.keyId, parsed.secret, record.previousSecretHash);
      if (!matchesCurrent && !matchesPrevious) return { ok: false, reason: 'wrong-secret', keyId: parsed.keyId };
      if (record.status !== 'active') return { ok: false, reason: 'revoked', keyId: parsed.keyId };
      if (record.expiresAt && record.expiresAt <= current) return { ok: false, reason: 'expired', keyId: parsed.keyId };

      await markUsed(record, ip);
      return {
        ok: true,
        auth: Object.freeze({
          keyId: record.keyId,
          clientName: record.clientName,
          scopes: Object.freeze([...record.scopes]),
          allowedParties: Object.freeze([...record.allowedParties]),
          rateLimitTier: record.rateLimitTier,
          usingPreviousSecret: Boolean(matchesPrevious),
        }),
      };
    },

    /** Create a key. Returns the plaintext key once, plus the public record. */
    async create(input, actor) {
      validateInput(input);
      const { keyId, secret, apiKey } = generateApiKey(environment);
      const timestamp = now();
      const record = {
        id: newId(),
        keyId,
        environment,
        secretHash: hashSecret(pepper, keyId, secret),
        previousSecretHash: null,
        previousSecretExpiresAt: null,
        clientName: input.clientName,
        description: input.description ?? '',
        scopes: [...new Set(input.scopes)],
        allowedParties: [...new Set(input.allowedParties ?? [])],
        rateLimitTier: input.rateLimitTier ?? 'standard',
        status: 'active',
        createdAt: timestamp,
        createdBy: actor,
        updatedAt: timestamp,
        expiresAt: input.expiresAt ? new Date(input.expiresAt) : null,
        lastUsedAt: null,
        revokedAt: null,
        revokedBy: null,
        revokeReason: null,
      };
      await repository.insert(record);
      await audit?.record({ action: 'apiKey.create', outcome: 'success', resourceType: 'apiKey', resourceId: keyId, details: { clientName: record.clientName, scopes: record.scopes, actor } });
      return { apiKey, key: toPublic(record) };
    },

    async list({ status, clientName } = {}) {
      return (await repository.list({ status, clientName })).map(toPublic);
    },

    async get(keyId) {
      const record = await repository.findByKeyId(keyId);
      if (!record) throw apiError('API_KEY_NOT_FOUND');
      return toPublic(record);
    },

    async update(keyId, changes, actor) {
      const record = await repository.findByKeyId(keyId);
      if (!record) throw apiError('API_KEY_NOT_FOUND');
      const merged = {
        scopes: changes.scopes ?? record.scopes,
        allowedParties: changes.allowedParties ?? record.allowedParties,
        rateLimitTier: changes.rateLimitTier,
        expiresAt: changes.expiresAt,
      };
      validateInput(merged, { partial: true });
      const updated = await repository.update(keyId, {
        ...(changes.description !== undefined ? { description: changes.description } : {}),
        ...(changes.scopes !== undefined ? { scopes: [...new Set(changes.scopes)] } : {}),
        ...(changes.allowedParties !== undefined ? { allowedParties: [...new Set(changes.allowedParties)] } : {}),
        ...(changes.rateLimitTier !== undefined ? { rateLimitTier: changes.rateLimitTier } : {}),
        ...(changes.expiresAt !== undefined ? { expiresAt: changes.expiresAt ? new Date(changes.expiresAt) : null } : {}),
        updatedAt: now(),
      });
      cache.delete(keyId);
      await audit?.record({ action: 'apiKey.update', outcome: 'success', resourceType: 'apiKey', resourceId: keyId, details: { changes: Object.keys(changes), actor } });
      return toPublic(updated);
    },

    /**
     * Issue a new secret for the same key id. The old secret keeps working for
     * `overlapHours` so clients can switch without downtime.
     */
    async rotate(keyId, { overlapHours = config.apiKeys.rotationOverlapHours } = {}, actor) {
      const record = await repository.findByKeyId(keyId);
      if (!record || record.status !== 'active') throw apiError('API_KEY_NOT_FOUND');
      const secret = generateSecret();
      const apiKey = formatApiKey(environment, keyId, secret);
      const timestamp = now();
      const updated = await repository.update(keyId, {
        previousSecretHash: overlapHours > 0 ? record.secretHash : null,
        previousSecretExpiresAt: overlapHours > 0 ? new Date(timestamp.getTime() + overlapHours * 3600000) : null,
        secretHash: hashSecret(pepper, keyId, secret),
        updatedAt: timestamp,
      });
      cache.delete(keyId);
      await audit?.record({ action: 'apiKey.rotate', outcome: 'success', resourceType: 'apiKey', resourceId: keyId, details: { overlapHours, actor } });
      return { apiKey, key: toPublic(updated) };
    },

    async revoke(keyId, { reason }, actor) {
      const record = await repository.findByKeyId(keyId);
      if (!record) throw apiError('API_KEY_NOT_FOUND');
      const timestamp = now();
      const updated = await repository.update(keyId, {
        status: 'revoked',
        previousSecretHash: null,
        previousSecretExpiresAt: null,
        revokedAt: timestamp,
        revokedBy: actor,
        revokeReason: reason,
        updatedAt: timestamp,
      });
      cache.delete(keyId);
      await audit?.record({ action: 'apiKey.revoke', outcome: 'success', resourceType: 'apiKey', resourceId: keyId, details: { reason, actor } });
      return toPublic(updated);
    },

    /** Forget cached key records (used after changes made by another instance or the CLI). */
    clearCache() {
      cache.clear();
    },
  };
}
